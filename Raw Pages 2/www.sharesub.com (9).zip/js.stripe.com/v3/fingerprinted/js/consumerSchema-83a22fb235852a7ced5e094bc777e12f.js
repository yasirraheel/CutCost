"use strict";
(window.webpackChunkStripeJSinner = window.webpackChunkStripeJSinner || []).push([
    [7774], {
        11192: function(e, i, a) {
            a.r(i), a.d(i, {
                joinParams: function() {
                    return f
                },
                outgoingSchema: function() {
                    return D
                }
            });
            var n = a(50078),
                t = a(68243),
                _ = a(12689),
                l = a(42929),
                s = a(51121),
                r = a(64247),
                o = a(13453),
                d = (0, n.Yj)(),
                m = (0, n.ai)(),
                g = (0, n.zM)(),
                p = (0, t.G)(),
                h = (0, n.lq)((0, n.Yj)()),
                u = (0, n.lq)((0, n.ai)()),
                k = (0, n.lq)((0, n.zM)()),
                c = {
                    type: h,
                    code: h,
                    decline_code: h,
                    doc_url: h,
                    extra_fields: (0, n.lq)(p),
                    message: h,
                    param: h,
                    payment_intent: (0, n.lq)(p),
                    payment_method: (0, n.lq)(p),
                    setup_intent: (0, n.lq)(p),
                    status: u,
                    shouldRetry: k
                },
                v = {
                    "link.hashed_email_lookup.not_found": {
                        loggedParams: {
                            email_source: h
                        }
                    },
                    "link.consumer_session.create.success": {
                        validation: _.D,
                        loggedParams: {
                            default_integration: h,
                            elements_assignment_id: h,
                            elements_session_id: h,
                            email_source: h,
                            has_saved_payment_methods: k,
                            in_link_auth_partnerships: k,
                            request_id: h,
                            used_hashed_email_address: k
                        }
                    },
                    "link.consumer_session.create.error": {
                        validation: _.D,
                        loggedParams: {
                            default_integration: h,
                            email_source: h,
                            error: p,
                            in_link_auth_partnerships: k,
                            link_auth_intent_status: h,
                            request_id: h,
                            used_hashed_email_address: k
                        }
                    },
                    "link.consumer_session.start_verification.success": {
                        validation: _.D,
                        loggedParams: {
                            default_integration: h,
                            document_hidden: k,
                            elements_assignment_id: h,
                            elements_session_id: h,
                            in_link_auth_partnerships: k,
                            in_link_in_split_card_elements_ga_cohort: h,
                            is_resend_sms_code: k,
                            link_auth_intent: k,
                            link_in_prb: h,
                            network_connection_type: h,
                            partial_cookie: k,
                            request_id: h,
                            verification_type: h
                        }
                    },
                    "link.consumer_session.start_verification.error": {
                        validation: _.D,
                        loggedParams: {
                            default_integration: h,
                            error: p,
                            in_link_auth_partnerships: k,
                            is_resend_sms_code: k,
                            link_auth_intent: k,
                            request_id: h,
                            verification_type: h
                        }
                    },
                    "link.consumer_session.confirm_verification.success": {
                        validation: _.D,
                        loggedParams: {
                            default_integration: h,
                            elements_assignment_id: h,
                            elements_session_id: h,
                            in_link_auth_partnerships: k,
                            in_link_in_split_card_elements_ga_cohort: h,
                            link_auth_intent: k,
                            link_in_prb: h,
                            partial_cookie: k,
                            request_id: h,
                            verification_type: h
                        }
                    },
                    "link.consumer_session.confirm_verification.error": {
                        validation: _.D,
                        loggedParams: {
                            error: (0, n.lq)(p),
                            request_id: h,
                            default_integration: h,
                            partial_cookie: k,
                            link_auth_intent: k,
                            verification_type: h,
                            is_distinctly_link_enabled: k
                        }
                    },
                    "link.consumer_session.verification.auto_restarted": {
                        validation: _.D,
                        loggedParams: {
                            default_integration: h,
                            verification_type: h,
                            is_distinctly_link_enabled: k
                        }
                    },
                    "link.smart_default_verification.start": {
                        validation: _.D,
                        loggedParams: {
                            in_link_auth_partnerships: k,
                            requires_phone_match: k,
                            verification_type: h
                        }
                    },
                    "link.consumer_experiment.exposure.error": {
                        validation: _.D,
                        loggedParams: {
                            experiment_name: d,
                            error_reason: d
                        }
                    },
                    "link.consumer_session.log_out.success": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.consumer_session.log_out.error": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.consumer_session.lookup_skipped_init_hint": {
                        validation: _.D,
                        loggedParams: {
                            email_source: h
                        }
                    },
                    "link.consumer_account.sign_up.success": {
                        validation: _.D,
                        loggedParams: {
                            buyer_detected_country: h,
                            consent_action: h,
                            country: h,
                            default_integration: h,
                            in_link_auth_partnerships: k,
                            pe_link_default_opt_in_behavior: h,
                            pe_link_opt_in_checkbox_manually_checked: k,
                            pe_link_opt_in_checkbox_shown: k,
                            request_id: h,
                            request_surface: h
                        }
                    },
                    "link.consumer_account.sign_up.error": {
                        validation: _.D,
                        loggedParams: {
                            error: p,
                            default_integration: h,
                            request_id: h,
                            payment_form: h
                        }
                    },
                    "link.consumer_account.sign_up.skipped_existing_consumer": {
                        loggedParams: {
                            payment_form: d
                        }
                    },
                    "link.payment_details.create.success": {
                        validation: _.D,
                        loggedParams: {
                            request_id: h,
                            payment_details_id: h,
                            payment_details_type: h,
                            default_integration: h
                        }
                    },
                    "link.payment_details.create.error": {
                        validation: _.D,
                        loggedParams: {
                            error: (0, n.lq)((0, l.I)(c)),
                            request_id: h,
                            default_integration: h,
                            payment_form: h
                        }
                    },
                    "link.payment_details.list.success": {
                        validation: _.D,
                        loggedParams: {
                            request_id: h,
                            payment_details_count: u,
                            payment_method_types: (0, n.lq)(p),
                            default_integration: h,
                            has_repairable_bank_account: k
                        }
                    },
                    "link.payment_details.list.error": {
                        validation: _.D,
                        loggedParams: {
                            default_integration: h,
                            error: p,
                            request_id: h
                        }
                    },
                    "link.payment_details.delete.success": {
                        validation: _.D,
                        loggedParams: {
                            payment_details_id: h,
                            request_id: h
                        }
                    },
                    "link.payment_details.delete.error": {
                        validation: _.D,
                        loggedParams: {
                            error: p,
                            payment_details_id: h,
                            request_id: h
                        }
                    },
                    "link.payment_details.update.success": {
                        validation: _.D,
                        loggedParams: {
                            payment_details_id: h,
                            request_id: h,
                            fields_sent: h,
                            cvc_present: k
                        }
                    },
                    "link.payment_details.update.error": {
                        validation: _.D,
                        loggedParams: {
                            error: p,
                            payment_details_id: h,
                            request_id: h,
                            fields_sent: h,
                            cvc_present: k
                        }
                    },
                    "link.shipping_address.create.success": {
                        validation: _.D,
                        loggedParams: {
                            request_id: h,
                            shipping_address_id: h,
                            default_integration: h
                        }
                    },
                    "link.shipping_address.create.error": {
                        validation: _.D,
                        loggedParams: {
                            error: p,
                            request_id: h,
                            default_integration: h
                        }
                    },
                    "link.shipping_address.list.success": {
                        validation: _.D,
                        loggedParams: {
                            default_integration: h,
                            elements_assignment_id: h,
                            elements_session_id: h,
                            in_link_auth_partnerships: k,
                            in_link_in_split_card_elements_ga_cohort: h,
                            link_in_prb: h,
                            request_id: h,
                            shipping_addresses_count: u
                        }
                    },
                    "link.shipping_address.list.error": {
                        validation: _.D,
                        loggedParams: {
                            default_integration: h,
                            error: p,
                            request_id: h
                        }
                    },
                    "link.shipping_address.delete.success": {
                        validation: _.D,
                        loggedParams: {
                            in_link_auth_partnerships: h,
                            request_id: h,
                            shipping_address_id: h
                        }
                    },
                    "link.shipping_address.delete.error": {
                        validation: _.D,
                        loggedParams: {
                            error: p,
                            request_id: h,
                            shipping_address_id: h
                        }
                    },
                    "link.shipping_address.update.success": {
                        validation: _.D,
                        loggedParams: {
                            request_id: h,
                            shipping_address_id: h,
                            default_integration: h
                        }
                    },
                    "link.shipping_address.update.error": {
                        validation: _.D,
                        loggedParams: {
                            error: p,
                            request_id: h,
                            default_integration: h
                        }
                    },
                    "link.refresh_login.start": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.refresh_login.success": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.refresh_login.error": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "list_card_payment_status.success": {
                        validation: _.D,
                        loggedParams: {
                            cardToken: d,
                            element_id: h,
                            in_link_auth_partnerships: k,
                            requestId: d,
                            status: (0, l.I)({
                                authorized: k,
                                charge: h,
                                error: (0, l.I)({
                                    code: h,
                                    decline_code: h,
                                    message: h,
                                    param: h
                                })
                            })
                        }
                    },
                    "list_card_payment_status.server_error": {
                        validation: _.D,
                        loggedParams: {
                            cardToken: d,
                            element_id: h,
                            error: (0, l.I)({
                                code: h,
                                doc_url: h,
                                extra_fields: (0, l.I)({
                                    name: d
                                }),
                                message: h,
                                param: h,
                                status: u,
                                type: d
                            }),
                            in_link_auth_partnerships: h,
                            requestId: h
                        }
                    },
                    "list_card_payment_status.unknown_error": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            err: (0, l.I)({
                                name: d
                            })
                        }
                    },
                    "list_card_payment_status.network_error": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "list_card_payment_status.fetch_error": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.clear_lookup_cache": {
                        validation: _.D,
                        loggedParams: {
                            previous_enabled_merchant_payment_methods: (0, s.Y)(d),
                            enabled_merchant_payment_methods: (0, s.Y)(d)
                        }
                    },
                    "link.autofill_modal.decommission": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.autofill_modal.decommissioned.show": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.autofill_modal.decommissioned.launch": {
                        validation: _.D,
                        loggedParams: {
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.autofill_modal.decommissioned.logout": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.autofill_modal.decommissioned.on": {
                        validation: _.D,
                        loggedParams: {
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.email_otp.send_code_to_email_clicked": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            email_otp_requires_additional_info: g,
                            email_otp_verify_phone_despite_sms_otp: g,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.email_otp.resend_code": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            email_otp_requires_additional_info: g,
                            email_otp_verify_phone_despite_sms_otp: g,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.email_otp.phone_verification.opened": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.email_otp.phone_verification.back_clicked": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.email_otp.phone_verification.success": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.sms_otp.send_code_to_sms_clicked": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.sms_otp.resend_code_clicked": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_partnerships.mount_started": {
                        validation: _.D,
                        loggedParams: {
                            in_link_auth_partnerships: k,
                            partner_experiment_variant: d,
                            partner_session_id: d
                        }
                    },
                    "link.auth_partnerships.pending_mount_in_flight": {
                        validation: _.D,
                        loggedParams: {
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.auth_partnerships.mount_conflict": {
                        validation: _.D,
                        loggedParams: {
                            in_link_auth_partnerships: g,
                            reason: d
                        }
                    },
                    "link.auth_partnerships.render_delay_timeout": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: g
                        }
                    },
                    "link.auth_partnerships.default_email_delay_timeout": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: g
                        }
                    },
                    "link.auth_partnerships.info_retrieved_late": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            hasLinkAuthIntent: g,
                            hasLinkAuthToken: g,
                            in_link_auth_partnerships: g
                        }
                    },
                    "link.auth_partnerships.info_retrieved": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            hasIntent: g,
                            hasToken: g,
                            in_link_auth_partnerships: g,
                            is_initial_retrieve: g,
                            since_create: m,
                            since_mount: m,
                            since_retrieve_started: m,
                            since_sjs_load: m,
                            since_stripe_create: m
                        }
                    },
                    "link.auth_partnerships.info_retrieve_failed": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            hasLinkAuthIntent: g,
                            hasLinkAuthToken: g,
                            in_link_auth_partnerships: g,
                            is_initial: d,
                            reason: d
                        }
                    },
                    "link.auth_partnerships.info_retrieve.not_found_on_initial": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.auth_partnerships.info_retrieve.ineligible": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: g,
                            is_initial: d
                        }
                    },
                    "link.auth_partnerships.login_with_link_auth_intent": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: g
                        }
                    },
                    "link.auth_partnerships.login_with_link_auth_intent.skipped": {
                        validation: _.D,
                        loggedParams: {
                            can_trigger_link_auth_login: g,
                            element_id: h,
                            has_consumer_session_for_link_auth_intent: g,
                            in_link_auth_partnerships: g,
                            is_eligible_for_link_auth: g,
                            is_otp_target_visible: g,
                            is_payment_element_initialized: g,
                            is_touched: g,
                            link_auth_initialized: g,
                            start_verification_request_status: d
                        }
                    },
                    "link.auth_partnerships.login_with_link_auth_token": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: g
                        }
                    },
                    "link.auth_partnerships.frame_id_missing": {
                        validation: _.D,
                        loggedParams: {
                            action: d
                        }
                    },
                    "link.auth_partnerships.frame_init_failed": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_partnerships.frame_init_exception": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_partnerships.frame.error": {
                        validation: _.D,
                        loggedParams: {
                            error_message: d,
                            error_type: d,
                            handshake_attempts: u,
                            in_link_auth_partnerships: g
                        }
                    },
                    "link.auth_partnerships.frame.mounted": {
                        validation: _.D,
                        loggedParams: {
                            in_link_auth_partnerships: g
                        }
                    },
                    "link.auth_partnerships.frame.loaded": {
                        validation: _.D,
                        loggedParams: {
                            in_link_auth_partnerships: g
                        }
                    },
                    "link.auth_partnerships.frame.max_handshake_attempts": {
                        validation: _.D,
                        loggedParams: {
                            attempts: m,
                            in_link_auth_partnerships: g
                        }
                    },
                    "link.auth_partnerships.frame.handshake_sent": {
                        validation: _.D,
                        loggedParams: {
                            in_link_auth_partnerships: g,
                            partner: h
                        }
                    },
                    "link.auth_partnerships.frame.handshake_started": {
                        validation: _.D,
                        loggedParams: {
                            in_link_auth_partnerships: g
                        }
                    },
                    "link.auth_partnerships.frame.partner_status_received": {
                        validation: _.D,
                        loggedParams: {
                            handshake_attempts: m,
                            has_link_auth_intent: g,
                            has_link_auth_token: g,
                            in_link_auth_partnerships: g,
                            metadata: (0, l.I)({
                                iab_session_id: d,
                                test_arm: d
                            }),
                            partner: d
                        }
                    },
                    "link.auth_partnerships.frame.partner_status_received.empty": {
                        validation: _.D,
                        loggedParams: {
                            handshake_attempts: m,
                            has_link_auth_intent: g,
                            has_link_auth_token: g,
                            in_link_auth_partnerships: g,
                            metadata: (0, l.I)({
                                iab_session_id: d,
                                test_arm: d
                            }),
                            partner: d
                        }
                    },
                    "link.auth_partnerships.frame.init_started": {
                        validation: _.D,
                        loggedParams: {
                            in_link_auth_partnerships: g
                        }
                    },
                    "link.auth_partnerships.frame.consumer_connected_event_sent": {
                        validation: _.D,
                        loggedParams: {
                            in_link_auth_partnerships: g,
                            partner: d
                        }
                    },
                    "link.auth_partnerships.frame.payment_signal_event_sent": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_partnerships.frame.new_controller": {
                        validation: _.D,
                        loggedParams: {
                            controller_count: m,
                            in_link_auth_partnerships: g
                        }
                    },
                    "link.auth_partnerships.frame_v2.handshake_started": {
                        validation: _.D,
                        loggedParams: {
                            in_link_auth_partnerships: g
                        }
                    },
                    "link.auth_partnerships.frame_v2.handshake_sent": {
                        validation: _.D,
                        loggedParams: {
                            in_link_auth_partnerships: d
                        }
                    },
                    "link.auth_partnerships.frame_v2.handshake_success": {
                        validation: _.D,
                        loggedParams: {
                            duration_ms: d,
                            has_link_auth_intent: d,
                            has_link_auth_token: d,
                            in_link_auth_partnerships: d,
                            partner_session_id: d
                        }
                    },
                    "link.auth_partnerships.frame_v2.handshake_error": {
                        validation: _.D,
                        loggedParams: {
                            duration_ms: m,
                            error: d,
                            in_link_auth_partnerships: g
                        }
                    },
                    "link.auth_partnerships.frame_v2.message_handler_missing": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_partnerships.frame_v2.consumer_connected_event_sent": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_partnerships.frame_v2.payment_signal_event_sent": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_partnerships.partner_experiment_data": {
                        validation: _.D,
                        loggedParams: {
                            iab_session_id: d,
                            in_link_auth_partnerships: g,
                            test_arm: d,
                            debug_metadata: h
                        }
                    },
                    "link.auth_partnerships.partner_debug_data": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_partnerships.partner_debug_data_log_error": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_partnerships.unfiltered_partner_experiment_data": {
                        validation: _.D,
                        loggedParams: {
                            iab_session_id: h,
                            in_link_auth_partnerships: k,
                            test_arm: h,
                            debug_metadata: h
                        }
                    },
                    "link.auth_partnerships.partner_data_validation_error": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_partnerships.auth_element_wrapper.timeout": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: g
                        }
                    },
                    "lae.hashed_email.triggered_login": {
                        loggedParams: {}
                    },
                    "link.auth_partnerships.disabled_for_holdback": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_partnerships.session_eligible": {
                        validation: _.D,
                        loggedParams: {
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.auth_partnerships.partner_eligible_flag_set_error": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_partnerships.ece.login_with_lai": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_partnerships.ece.login_with_lat": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_partnerships.ece.lat_fetch_error": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_partnerships.ece.disabled_reasons": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_partnerships.ece.hidden_for_partner_holdback": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.cookie.ignored": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.otp.closed": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: k,
                            is_recollecting_phone: g
                        }
                    },
                    "link.otp.opened": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: h
                        }
                    },
                    "link.otp.focused": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.otp.type.start": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            elements_assignment_id: h,
                            elements_session_id: h,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.autofill_prompt.otp.rendered": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: k,
                            show_meta_consent_disclaimer: g
                        }
                    },
                    "link.logged_in": {
                        validation: _.D,
                        loggedParams: {
                            default_integration: h,
                            recollect_cvc: k,
                            recollect_billing: k,
                            recollect_expiry: k,
                            recollect_name: k,
                            num_saved_payment_details: u,
                            num_saved_shipping_addresses: u,
                            has_customer_email: k,
                            has_lae_default_values_email: k,
                            has_lape_default_values_email: k,
                            payment_details_id: h
                        }
                    },
                    "link.start_login_with_auth_session_client_secret": {
                        validation: _.D,
                        loggedParams: {
                            partial_cookie: k,
                            default_integration: h
                        }
                    },
                    "link.logged_in_with_auth_session_client_secret": {
                        validation: _.D,
                        loggedParams: {
                            default_integration: h,
                            recollect_cvc: k,
                            recollect_billing: k,
                            recollect_expiry: k,
                            recollect_name: k,
                            num_saved_payment_details: u,
                            num_saved_shipping_addresses: u,
                            has_customer_email: k,
                            has_lae_default_values_email: k,
                            has_lape_default_values_email: k,
                            payment_details_id: h
                        }
                    },
                    "link.logged_in_with_link_store_state": {
                        validation: _.D,
                        loggedParams: {
                            default_integration: h,
                            recollect_cvc: k,
                            recollect_billing: k,
                            recollect_expiry: k,
                            recollect_name: k,
                            num_saved_payment_details: u,
                            num_saved_shipping_addresses: u,
                            has_customer_email: k,
                            has_lae_default_values_email: k,
                            has_lape_default_values_email: k,
                            payment_details_id: h
                        }
                    },
                    "link.not_logged_in_with_auth_session_client_secret": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_session_client_secret_login_timed_out_with_valid_credentials": {
                        validation: _.D,
                        loggedParams: {
                            element: h,
                            timeout: u,
                            timeout_elapsed_time: u
                        }
                    },
                    "link.auth_session_client_secret_login.would_hit_non_guacamole_timeout": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.auth_session_client_secret_login.guacamole_timeout_takeover_not_enabled": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.disabled_after_takeover_fallback": {
                        loggedParams: {
                            hasFallbackEmail: g,
                            isPartialCookie: g
                        }
                    },
                    "link.logged_in_with_link_auth_token_client_secret": {
                        validation: _.D,
                        loggedParams: {
                            default_integration: h,
                            recollect_cvc: k,
                            recollect_billing: k,
                            recollect_expiry: k,
                            recollect_name: k,
                            num_saved_payment_details: u,
                            num_saved_shipping_addresses: u,
                            has_customer_email: k,
                            has_lae_default_values_email: k,
                            has_lape_default_values_email: k,
                            payment_details_id: h
                        }
                    },
                    "link.logged_in_with_consumer_info": {
                        validation: _.D,
                        loggedParams: {
                            default_integration: h,
                            recollect_cvc: k,
                            recollect_billing: k,
                            recollect_expiry: k,
                            recollect_name: k,
                            num_saved_payment_details: u,
                            num_saved_shipping_addresses: u,
                            has_customer_email: k,
                            has_lae_default_values_email: k,
                            has_lape_default_values_email: k,
                            payment_details_id: h
                        }
                    },
                    "link.email.entered": {
                        validation: _.D,
                        loggedParams: {
                            debounced_email_matches_consumer_session_email: d,
                            found_using_partial_cookie: d,
                            has_consumer_session: d,
                            is_consumer_loaded: d,
                            link_view: d,
                            link_view_auth_status: d
                        }
                    },
                    "link.cookie_email_mismatch": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.name_field_shown": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k,
                            mounted_link_authentication: g
                        }
                    },
                    "link.opt_in.shown": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            elements_assignment_id: h,
                            elements_session_id: h,
                            in_link_auth_partnerships: k,
                            in_link_in_split_card_elements_ga_cohort: h,
                            link_default_opt_in_behavior: d,
                            link_in_prb: h,
                            mounted_link_authentication: g
                        }
                    },
                    "link.opt_in.hidden": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: k,
                            link_default_opt_in_behavior: d,
                            mounted_link_authentication: g
                        }
                    },
                    "link.opt_in.checked": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: k,
                            mounted_link_authentication: g
                        }
                    },
                    "link.opt_in.unchecked": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k,
                            mounted_link_authentication: g
                        }
                    },
                    "link.opt_in.optional_doi_unchecked": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.opt_in.more_info": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.invalid_sign_up": {
                        validation: _.D,
                        loggedParams: {
                            optInFlow: h,
                            missingEmail: k,
                            missingPhone: k,
                            linkOptInConsentShown: k,
                            isLinkOptInTouched: k,
                            linkOptInBehavior: h
                        }
                    },
                    "link.sign_up_success": {
                        validation: _.D,
                        loggedParams: {
                            missingEmail: k,
                            missingPhone: k,
                            linkOptInConsentShown: k,
                            isLinkOptInTouched: k,
                            linkOptInBehavior: h
                        }
                    },
                    "link.backup_pm.viewed": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k,
                            selected_payment_detail_type: d
                        }
                    },
                    "link.backup_pm.more_info": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k,
                            selected_payment_detail_type: d
                        }
                    },
                    "link.backup_pm.menu": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.backup_pm.disabled": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k,
                            selected_payment_detail_type: d
                        }
                    },
                    "link.backup_pm.enabled": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k,
                            selected_payment_detail_type: d
                        }
                    },
                    "link.backup_pm.no_backup_id": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.sign_up.disabled_on_pageload": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d
                        }
                    },
                    "link.sign_up.disabled_by_billing_country": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h
                        }
                    },
                    "link.sign_up.enabled_by_billing_country": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            elements_assignment_id: h,
                            elements_session_id: h,
                            in_link_auth_partnerships: k,
                            in_link_in_split_card_elements_ga_cohort: h,
                            link_in_prb: k
                        }
                    },
                    "link.sign_up.email_changed_from_default_value": {
                        loggedParams: {
                            element_id: h
                        }
                    },
                    "link.sign_up.phone_changed_from_default_value": {
                        loggedParams: {
                            element_id: h
                        }
                    },
                    "link.sign_up.name_changed_from_default_value": {
                        loggedParams: {
                            element_id: h
                        }
                    },
                    "link.financial_incentive.shown": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.financial_incentive.hidden": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.financial_incentive.confirmation.error": {
                        validation: _.D,
                        loggedParams: {
                            paymentDetailsId: h,
                            res: (0, n.lq)(p)
                        }
                    },
                    "link.financial_incentive.amount_mismatch": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.incentive_promo.shown": {
                        validation: _.D,
                        loggedParams: {
                            financial_incentive: d,
                            render_context: d
                        }
                    },
                    "link.incentive_promo.hidden": {
                        validation: _.D,
                        loggedParams: {
                            financial_incentive: d,
                            render_context: d
                        }
                    },
                    "link.instant_debits.bank_tab.shown": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            elements_assignment_id: h,
                            elements_session_id: h,
                            in_link_auth_partnerships: k,
                            link_in_prb: h,
                            link_mode: d,
                            link_with_incentives: g
                        }
                    },
                    "link.instant_debits.bank_tab.selected": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.instant_debits.bank_tab.unselected": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.instant_debits.incentive_promo.shown": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            elements_assignment_id: h,
                            elements_session_id: h,
                            financial_incentive: m,
                            in_link_auth_partnerships: k,
                            payment_method_type: d,
                            render_context: d
                        }
                    },
                    "link.instant_debits.incentive_promo.hidden": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            financial_incentive: m,
                            in_link_auth_partnerships: k,
                            payment_method_type: d,
                            render_context: d
                        }
                    },
                    "link.instant_debits.hidden_on_client": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d
                        }
                    },
                    "link.instant_debits.protection_promo.shown": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.purchase_protection.modal.open": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d
                        }
                    },
                    "link.purchase_protection.opt_in.rendered": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: h
                        }
                    },
                    "link.purchase_protection.autofill_prompt.rendered": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: h
                        }
                    },
                    "link.purchase_protection.banner.rendered": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.purchase_protection.banner.expanded": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: h
                        }
                    },
                    "link.purchase_protection.add_new_pm.rendered": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.instant_debits.purchase_protection.banner.shown": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.instant_debits.purchase_protection.banner.clicked": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.instant_debits.purchase_protection.banner.readonly.clicked": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.instant_debits.ibp_accordion_logos.shown": {
                        loggedParams: {}
                    },
                    "link.instant_debits.ibp_accordion_logos.insufficient_institutions": {
                        loggedParams: {
                            count: m
                        }
                    },
                    "link.default_integration": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            elements_assignment_id: h,
                            elements_session_id: h,
                            in_link_auth_partnerships: k,
                            in_link_in_split_card_elements_ga_cohort: h,
                            link_in_prb: h
                        }
                    },
                    "link.default_integration.timeout": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            hasSessionForDefaultEmail: g,
                            in_link_auth_partnerships: k,
                            in_link_in_split_card_elements_ga_cohort: h,
                            link_in_prb: h,
                            shouldBlockRenderUntilExperimentExposure: h,
                            shouldBlockRenderUntilLinkModalLoad: h
                        }
                    },
                    "link.default_integration.email_entered": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k,
                            source: d
                        }
                    },
                    "link.default_integration.email_change": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.default_integration.autofill_open": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.default_integration.autofill_close": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k
                        }
                    },
                    "link.default_integration.email_enter_start": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            elements_assignment_id: h,
                            elements_session_id: h,
                            in_link_auth_partnerships: k,
                            source: d
                        }
                    },
                    "link.default_integration.phone_number_enter_start": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: k,
                            source: d
                        }
                    },
                    "link.default_integration.card_form_change": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            elements_assignment_id: h,
                            elements_session_id: h,
                            in_link_auth_partnerships: k,
                            in_link_in_split_card_elements_ga_cohort: h,
                            link_in_prb: k
                        }
                    },
                    "link.default_integration.treatment_autofill_message": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.default_integration.secure_opt_in_message": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.payment_element.integration_type": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            elements_assignment_id: h,
                            elements_session_id: h,
                            in_link_auth_partnerships: k,
                            in_link_in_split_card_elements_ga_cohort: h,
                            link_in_prb: h,
                            request_surface: d
                        }
                    },
                    "link.passthrough_mode": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.payment_details.share.success": {
                        validation: _.D,
                        loggedParams: {
                            merchantId: h,
                            paymentDetailsId: h,
                            selected_payment_method_type: h
                        }
                    },
                    "link.payment_details.share.error": {
                        validation: _.D,
                        loggedParams: {
                            error: p,
                            selected_payment_method_type: d
                        }
                    },
                    "link.maybe_format_phone_number.error": {
                        loggedParams: {
                            error: (0, l.I)({
                                message: h,
                                name: h
                            })
                        }
                    },
                    "link.consumer_lookup_response_id": {
                        validation: _.D,
                        loggedParams: {
                            elements_assignment_id: h,
                            elements_session_id: h,
                            in_link_auth_partnerships: k,
                            lae_dl_otp: h,
                            link_backup_pm_default_on: h,
                            link_condensed_ece_personalization: h,
                            link_ece_default_values_personalization: h,
                            link_ece_default_values_personalization_v2: h,
                            wanderlust_benchmarking: h
                        }
                    },
                    "link.customer_and_cookie_email_dont_match": {
                        validation: _.D,
                        loggedParams: {
                            default_integration: h,
                            partial_cookie: k
                        }
                    },
                    "link.paying_with_link_selector_conflicts_with_payment_method_data": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            has_spm_and_not_link_authenticated: g,
                            is_in_lae_autofill_opt_out: g,
                            is_logged_in: g,
                            is_paying_with_link_payment_method_selector: g,
                            is_showing_logged_in_ui: g,
                            selected_payment_method: d
                        }
                    },
                    "link.create_payment_data.not_showing_logged_in_ui": {
                        validation: _.D,
                        loggedParams: {
                            is_session_verified: g,
                            is_new_signup: g,
                            consumer_loaded: g,
                            has_started_login: g,
                            selected_payment_form: h
                        }
                    },
                    "link.create_payment_data.no_selected_payment_form": {
                        validation: _.D,
                        loggedParams: {
                            is_logged_in: g,
                            is_showing_logged_in_ui: g
                        }
                    },
                    "link.create_payment_data.invalid_payment_form": {
                        validation: _.D,
                        loggedParams: {
                            is_logged_in: g,
                            is_showing_logged_in_ui: g,
                            selected_payment_form: d
                        }
                    },
                    "link.create_payment_data.no_selected_payment_details": {
                        validation: _.D,
                        loggedParams: {
                            payment_view: d
                        }
                    },
                    "link.create_payment_data.invalid_card_recollection": {
                        validation: _.D,
                        loggedParams: {
                            selected_payment_form: d,
                            payment_method_type: d,
                            payment_details_type: d
                        }
                    },
                    "link.create_payment_data.invalid_update_state": {
                        validation: _.D,
                        loggedParams: {
                            has_updating_saved_payment: g,
                            selected_payment_form: d,
                            payment_method_type: d
                        }
                    },
                    "link.get_http_cookie_race_outcome": {
                        validation: _.D,
                        loggedParams: {
                            raceWon: d
                        }
                    },
                    "link.set_http_cookie": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.set_http_cookie.success": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.set_http_cookie.error": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.remove_http_cookie": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.remove_http_cookie.success": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.remove_http_cookie.error": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.mismatch_billing_details": {
                        validation: _.D,
                        loggedParams: {
                            has_merchant_city: g,
                            has_merchant_country: g,
                            has_merchant_line1: g,
                            has_merchant_line2: g,
                            has_merchant_postal_code: g,
                            has_merchant_state: g,
                            in_link_auth_partnerships: k,
                            mismatch_country: g,
                            mismatch_postal_code: g
                        }
                    },
                    "link.disabled_reasons": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            elements_assignment_id: h,
                            elements_session_id: h,
                            in_link_auth_partnerships: k,
                            in_link_in_split_card_elements_ga_cohort: h,
                            link_in_prb: k,
                            reasons: d
                        }
                    },
                    "link.hidden_reasons": {
                        validation: _.D,
                        loggedParams: {
                            buttonType: d,
                            element_id: d,
                            focusedCardElementField: h,
                            in_link_auth_partnerships: k,
                            insufficientHeight: g,
                            insufficientWidth: g,
                            measurements: (0, l.I)({
                                availableWidth: m,
                                buttonWidth: m,
                                height: m,
                                inputWidth: u,
                                outerHeight: u
                            }),
                            reason: d
                        }
                    },
                    "link.enabled": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            elements_assignment_id: h,
                            elements_session_id: h,
                            in_link_auth_partnerships: k,
                            mode: d
                        }
                    },
                    "link.consumer_session_login.link_availability_changed": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.webauthn.login_button.clicked": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            in_link_auth_partnerships: h,
                            verification_session_id: d
                        }
                    },
                    "link.webauthn.login_button.rendered": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: h
                        }
                    },
                    "link.global_holdback.lookup_error": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.global_holdback.lookup_success": {
                        validation: _.D,
                        loggedParams: {
                            elements_assignment_id: h,
                            elements_session_id: h,
                            in_link_auth_partnerships: k,
                            recognition_type: h,
                            request_id: d
                        }
                    },
                    "link.global_holdback.lookup_failure": {
                        validation: _.D,
                        loggedParams: {
                            elements_assignment_id: h,
                            elements_session_id: h,
                            error: (0, l.I)({
                                code: h,
                                doc_url: h,
                                extra_fields: (0, l.I)({
                                    name: h
                                }),
                                message: h,
                                param: h,
                                shouldRetry: k,
                                status: u,
                                type: h
                            }),
                            in_link_auth_partnerships: k,
                            request_id: h
                        }
                    },
                    "link.global_holdback.exposure_update": {
                        validation: _.D,
                        loggedParams: {
                            arb_id: d,
                            dvs_provided: d,
                            eligible_for_link: h,
                            has_spms: h,
                            in_link_auth_partnerships: k,
                            integration_type: h,
                            intent_type: d,
                            is_link_holdback_manager: g,
                            is_returning_link_user: g,
                            link_default_opt_in: h,
                            recognition_type: d
                        }
                    },
                    "link.ab_test.exposure_update": {
                        validation: _.D,
                        loggedParams: {
                            arb_id: d,
                            dvs_provided: d,
                            in_link_auth_partnerships: k,
                            intent_type: d,
                            is_link_holdback_manager: g,
                            is_returning_link_user: g,
                            recognition_type: d
                        }
                    },
                    "link.global_holdback.error": {
                        validation: _.D,
                        loggedParams: {
                            error_message: d,
                            error_stack: d,
                            message: d
                        }
                    },
                    "link.global_holdback.debug": {
                        validation: _.D,
                        loggedParams: {
                            arbId: h,
                            currentDimensions: (0, l.I)({
                                dvs_provided: h,
                                intent_type: h,
                                is_link_holdback_manager: k,
                                is_returning_link_user: k,
                                recognition_type: h
                            }),
                            debug_message: d,
                            dvsProvided: h,
                            enabled: k,
                            initializedSurfaces: h,
                            isCheckout: k,
                            lastExposedDimensions: (0, l.I)({
                                dvs_provided: h,
                                intent_type: h,
                                is_link_holdback_manager: k,
                                is_returning_link_user: k,
                                recognition_type: h
                            }),
                            linkAbTest: k,
                            linkAbTestHasVariant: k,
                            linkAbTestVariant: h,
                            linkGlobalHoldback: k,
                            linkGlobalHoldbackHasVariant: k,
                            linkGlobalHoldbackVariant: h,
                            message: h,
                            variant: h
                        }
                    },
                    "link.ir_window_influence.session_created_but_logged_in": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.login_with_link_auth_intent.error": {
                        validation: _.D,
                        loggedParams: {
                            error: d
                        }
                    },
                    "link.login_with_link_auth_token.error": {
                        validation: _.D,
                        loggedParams: {
                            error: d
                        }
                    },
                    "link.login_with_link_auth_token.attempt_fallback_credential_login": {
                        validation: _.D,
                        loggedParams: {
                            element: d
                        }
                    },
                    "link.login_with_link_auth_token.retry_fallback_credential_login": {
                        validation: _.D,
                        loggedParams: {
                            element: d
                        }
                    },
                    "link.universal_link_modal.already_open": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h
                        }
                    },
                    "link.universal_link_modal.already_closed": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.intersection_observer_open_triggered": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.intersection_observer_spinner_triggered": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.cookied_card_display.no_card_details": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.cookied_balance_display.no_balance_details": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.cookied_klarna_display.no_klarna_details": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.cookied_klarna_display.no_klarna_plan_option": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.cookied_klarna_display.no_klarna_payment_session": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.assert_secure_click_check": {
                        validation: _.D,
                        loggedParams: {
                            consumerHasPreviousMerchantRelationship: g,
                            element_id: d,
                            foundConsumerSessionWithPartialCookie: g,
                            isContainerVisible: g,
                            isSecure: g,
                            isTrusted: g
                        }
                    },
                    "link.secure_click_candidate": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            foundConsumerSessionWithPartialCookie: g,
                            isContainerVisible: g,
                            isTrusted: g
                        }
                    },
                    "link.recollection_required_on_selected_payment_details": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            fields: d,
                            paymentDetailType: d
                        }
                    },
                    "link.consumer_unverified_after_ulm_login_attempt": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.no_secure_click_due_to_recollection_errors": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.widget_header.close_button_clicked": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            parentComponent: d
                        }
                    },
                    "link.steerage.payment_method_promoted": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            paymentMethod: d
                        }
                    },
                    "link.steerage.payment_method_clicked": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h,
                            type: d
                        }
                    },
                    "link.steerage.button_clicked_with_no_key_error": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.klarna_nux.universal_modal_opened": {
                        validation: _.D,
                        loggedParams: {
                            element_id: h
                        }
                    },
                    "link.klarna_nux.universal_modal_errored": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.klarna_nux.payment_session_error": {
                        validation: _.D,
                        loggedParams: {
                            decline_code: d
                        }
                    },
                    "link.klarna_in_link.experiment.unavailable": {
                        validation: _.D,
                        loggedParams: {
                            element_id: d,
                            in_link_auth_partnerships: k,
                            reason: d,
                            variant: h
                        }
                    },
                    "link.ece.dimensions_on_click": {
                        validation: _.D,
                        loggedParams: {
                            outer_width: m,
                            outer_height: m,
                            is_mounted_in_iframe: g,
                            billing_address_required: g,
                            shipping_address_required: g,
                            is_habanero: g
                        }
                    },
                    "link.ece.ulm_not_ready_fallback_to_popup": {
                        validation: _.D,
                        loggedParams: {
                            status: d
                        }
                    },
                    "link.ece.ulm_not_ready_no_fallback": {
                        validation: _.D,
                        loggedParams: {
                            status: d
                        }
                    },
                    "link.403_fallback_verification_triggered": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.403_fallback_verification.fatal_error.already_triggered": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.403_fallback_verification.no_verification_types": {
                        validation: _.D,
                        loggedParams: {}
                    },
                    "link.403_fallback_verification.verification.start": {
                        validation: _.D,
                        loggedParams: {
                            fallbackVerificationType: d
                        }
                    },
                    "link.403_fallback_verification.verification.otp_sent": {
                        validation: _.D,
                        loggedParams: {
                            fallbackVerificationType: d
                        }
                    },
                    "link.disabled.on_behalf_of_self": {
                        validation: _.D,
                        loggedParams: {
                            onBehalfOf: h
                        }
                    },
                    "link.cookied_payment_details_widget.change_payment_method_clicked": {
                        validation: _.D,
                        loggedParams: {
                            secureClickNeeded: g
                        }
                    },
                    "link.cookied_payment_details_widget.change_payment_method_rendered": {
                        validation: _.D,
                        loggedParams: {}
                    }
                },
                P = (0, r.me)(o.x8, {
                    frame_width: m
                }, v),
                D = P.outgoingSchema,
                f = P.joinParams
        }
    }
]);