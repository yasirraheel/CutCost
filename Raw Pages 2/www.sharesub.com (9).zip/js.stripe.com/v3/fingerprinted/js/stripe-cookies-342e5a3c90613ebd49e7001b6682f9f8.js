"use strict";
(window.webpackChunkStripeJSinner = window.webpackChunkStripeJSinner || []).push([
    [3422], {
        9570: function(e, t, i) {
            function o(e, t) {
                if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                e.prototype = Object.create(t && t.prototype, {
                    constructor: {
                        value: e,
                        writable: !0,
                        configurable: !0
                    }
                }), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), t && r(e, t)
            }

            function r(e, t) {
                return (r = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }

            function n(e) {
                var t = function() {
                    if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" == typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var i, o = s(e);
                    if (t) {
                        var r = s(this).constructor;
                        i = Reflect.construct(o, arguments, r)
                    } else i = o.apply(this, arguments);
                    return a(this, i)
                }
            }

            function a(e, t) {
                if (t && ("object" === g(t) || "function" == typeof t)) return t;
                if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
                return function(e) {
                    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return e
                }(e)
            }

            function s(e) {
                return (s = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
                    return e.__proto__ || Object.getPrototypeOf(e)
                })(e)
            }

            function c(e, t) {
                var i = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                if (!i) {
                    if (Array.isArray(e) || (i = h(e)) || t && e && "number" == typeof e.length) {
                        i && (e = i);
                        var o = 0,
                            r = function() {};
                        return {
                            s: r,
                            n: function() {
                                return o >= e.length ? {
                                    done: !0
                                } : {
                                    done: !1,
                                    value: e[o++]
                                }
                            },
                            e: function(e) {
                                throw e
                            },
                            f: r
                        }
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }
                var n, a = !0,
                    s = !1;
                return {
                    s: function() {
                        i = i.call(e)
                    },
                    n: function() {
                        var e = i.next();
                        return a = e.done, e
                    },
                    e: function(e) {
                        s = !0, n = e
                    },
                    f: function() {
                        try {
                            a || null == i.return || i.return()
                        } finally {
                            if (s) throw n
                        }
                    }
                }
            }

            function l() {
                function e(e, t, i) {
                    return Object.defineProperty(e, t, {
                        value: i,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }), e[t]
                }

                function t(e, t, i, r) {
                    var n = t && t.prototype instanceof o ? t : o,
                        a = Object.create(n.prototype),
                        s = new d(r || []);
                    return k(a, "_invoke", {
                        value: c(e, i, s)
                    }), a
                }

                function i(e, t, i) {
                    try {
                        return {
                            type: "normal",
                            arg: e.call(t, i)
                        }
                    } catch (e) {
                        return {
                            type: "throw",
                            arg: e
                        }
                    }
                }

                function o() {}

                function r() {}

                function n() {}

                function a(t) {
                    ["next", "throw", "return"].forEach((function(i) {
                        e(t, i, (function(e) {
                            return this._invoke(i, e)
                        }))
                    }))
                }

                function s(e, t) {
                    var o;
                    k(this, "_invoke", {
                        value: function(r, n) {
                            function a() {
                                return new t((function(o, a) {
                                    ! function o(r, n, a, s) {
                                        var c = i(e[r], e, n);
                                        if ("throw" !== c.type) {
                                            var l = c.arg,
                                                m = l.value;
                                            return m && "object" == g(m) && _.call(m, "__await") ? t.resolve(m.__await).then((function(e) {
                                                o("next", e, a, s)
                                            }), (function(e) {
                                                o("throw", e, a, s)
                                            })) : t.resolve(m).then((function(e) {
                                                l.value = e, a(l)
                                            }), (function(e) {
                                                return o("throw", e, a, s)
                                            }))
                                        }
                                        s(c.arg)
                                    }(r, n, o, a)
                                }))
                            }
                            return o = o ? o.then(a, a) : a()
                        }
                    })
                }

                function c(e, t, o) {
                    var r = "suspendedStart";
                    return function(n, a) {
                        if ("executing" === r) throw new Error("Generator is already running");
                        if ("completed" === r) {
                            if ("throw" === n) throw a;
                            return {
                                value: void 0,
                                done: !0
                            }
                        }
                        for (o.method = n, o.arg = a;;) {
                            var s = o.delegate;
                            if (s) {
                                var c = m(s, o);
                                if (c) {
                                    if (c === L) continue;
                                    return c
                                }
                            }
                            if ("next" === o.method) o.sent = o._sent = o.arg;
                            else if ("throw" === o.method) {
                                if ("suspendedStart" === r) throw r = "completed", o.arg;
                                o.dispatchException(o.arg)
                            } else "return" === o.method && o.abrupt("return", o.arg);
                            r = "executing";
                            var l = i(e, t, o);
                            if ("normal" === l.type) {
                                if (r = o.done ? "completed" : "suspendedYield", l.arg === L) continue;
                                return {
                                    value: l.arg,
                                    done: o.done
                                }
                            }
                            "throw" === l.type && (r = "completed", o.method = "throw", o.arg = l.arg)
                        }
                    }
                }

                function m(e, t) {
                    var o = t.method,
                        r = e.iterator[o];
                    if (void 0 === r) return t.delegate = null, "throw" === o && e.iterator.return && (t.method = "return", t.arg = void 0, m(e, t), "throw" === t.method) || "return" !== o && (t.method = "throw", t.arg = new TypeError("The iterator does not provide a '" + o + "' method")), L;
                    var n = i(r, e.iterator, t.arg);
                    if ("throw" === n.type) return t.method = "throw", t.arg = n.arg, t.delegate = null, L;
                    var a = n.arg;
                    return a ? a.done ? (t[e.resultName] = a.value, t.next = e.nextLoc, "return" !== t.method && (t.method = "next", t.arg = void 0), t.delegate = null, L) : a : (t.method = "throw", t.arg = new TypeError("iterator result is not an object"), t.delegate = null, L)
                }

                function u(e) {
                    var t = {
                        tryLoc: e[0]
                    };
                    1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                }

                function p(e) {
                    var t = e.completion || {};
                    t.type = "normal", delete t.arg, e.completion = t
                }

                function d(e) {
                    this.tryEntries = [{
                        tryLoc: "root"
                    }], e.forEach(u, this), this.reset(!0)
                }

                function f(e) {
                    if (e) {
                        var t = e[b];
                        if (t) return t.call(e);
                        if ("function" == typeof e.next) return e;
                        if (!isNaN(e.length)) {
                            var i = -1,
                                o = function t() {
                                    for (; ++i < e.length;)
                                        if (_.call(e, i)) return t.value = e[i], t.done = !1, t;
                                    return t.value = void 0, t.done = !0, t
                                };
                            return o.next = o
                        }
                    }
                    return {
                        next: h
                    }
                }

                function h() {
                    return {
                        value: void 0,
                        done: !0
                    }
                }
                l = function() {
                    return y
                };
                var y = {},
                    v = Object.prototype,
                    _ = v.hasOwnProperty,
                    k = Object.defineProperty || function(e, t, i) {
                        e[t] = i.value
                    },
                    S = "function" == typeof Symbol ? Symbol : {},
                    b = S.iterator || "@@iterator",
                    x = S.asyncIterator || "@@asyncIterator",
                    O = S.toStringTag || "@@toStringTag";
                try {
                    e({}, "")
                } catch (y) {
                    e = function(e, t, i) {
                        return e[t] = i
                    }
                }
                y.wrap = t;
                var L = {},
                    I = {};
                e(I, b, (function() {
                    return this
                }));
                var E = Object.getPrototypeOf,
                    A = E && E(E(f([])));
                A && A !== v && _.call(A, b) && (I = A);
                var C = n.prototype = o.prototype = Object.create(I);
                return r.prototype = n, k(C, "constructor", {
                    value: n,
                    configurable: !0
                }), k(n, "constructor", {
                    value: r,
                    configurable: !0
                }), r.displayName = e(n, O, "GeneratorFunction"), y.isGeneratorFunction = function(e) {
                    var t = "function" == typeof e && e.constructor;
                    return !!t && (t === r || "GeneratorFunction" === (t.displayName || t.name))
                }, y.mark = function(t) {
                    return Object.setPrototypeOf ? Object.setPrototypeOf(t, n) : (t.__proto__ = n, e(t, O, "GeneratorFunction")), t.prototype = Object.create(C), t
                }, y.awrap = function(e) {
                    return {
                        __await: e
                    }
                }, a(s.prototype), e(s.prototype, x, (function() {
                    return this
                })), y.AsyncIterator = s, y.async = function(e, i, o, r, n) {
                    void 0 === n && (n = w);
                    var a = new s(t(e, i, o, r), n);
                    return y.isGeneratorFunction(i) ? a : a.next().then((function(e) {
                        return e.done ? e.value : a.next()
                    }))
                }, a(C), e(C, O, "Generator"), e(C, b, (function() {
                    return this
                })), e(C, "toString", (function() {
                    return "[object Generator]"
                })), y.keys = function(e) {
                    var t = Object(e),
                        i = [];
                    for (var o in t) i.push(o);
                    return i.reverse(),
                        function e() {
                            for (; i.length;) {
                                var o = i.pop();
                                if (o in t) return e.value = o, e.done = !1, e
                            }
                            return e.done = !0, e
                        }
                }, y.values = f, d.prototype = {
                    constructor: d,
                    reset: function(e) {
                        if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, this.done = !1, this.delegate = null, this.method = "next", this.arg = void 0, this.tryEntries.forEach(p), !e)
                            for (var t in this) "t" === t.charAt(0) && _.call(this, t) && !isNaN(+t.slice(1)) && (this[t] = void 0)
                    },
                    stop: function() {
                        this.done = !0;
                        var e = this.tryEntries[0].completion;
                        if ("throw" === e.type) throw e.arg;
                        return this.rval
                    },
                    dispatchException: function(e) {
                        function t(t, o) {
                            return n.type = "throw", n.arg = e, i.next = t, o && (i.method = "next", i.arg = void 0), !!o
                        }
                        if (this.done) throw e;
                        for (var i = this, o = this.tryEntries.length - 1; o >= 0; --o) {
                            var r = this.tryEntries[o],
                                n = r.completion;
                            if ("root" === r.tryLoc) return t("end");
                            if (r.tryLoc <= this.prev) {
                                var a = _.call(r, "catchLoc"),
                                    s = _.call(r, "finallyLoc");
                                if (a && s) {
                                    if (this.prev < r.catchLoc) return t(r.catchLoc, !0);
                                    if (this.prev < r.finallyLoc) return t(r.finallyLoc)
                                } else if (a) {
                                    if (this.prev < r.catchLoc) return t(r.catchLoc, !0)
                                } else {
                                    if (!s) throw new Error("try statement without catch or finally");
                                    if (this.prev < r.finallyLoc) return t(r.finallyLoc)
                                }
                            }
                        }
                    },
                    abrupt: function(e, t) {
                        for (var i = this.tryEntries.length - 1; i >= 0; --i) {
                            var o = this.tryEntries[i];
                            if (o.tryLoc <= this.prev && _.call(o, "finallyLoc") && this.prev < o.finallyLoc) {
                                var r = o;
                                break
                            }
                        }
                        r && ("break" === e || "continue" === e) && r.tryLoc <= t && t <= r.finallyLoc && (r = null);
                        var n = r ? r.completion : {};
                        return n.type = e, n.arg = t, r ? (this.method = "next", this.next = r.finallyLoc, L) : this.complete(n)
                    },
                    complete: function(e, t) {
                        if ("throw" === e.type) throw e.arg;
                        return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), L
                    },
                    finish: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var i = this.tryEntries[t];
                            if (i.finallyLoc === e) return this.complete(i.completion, i.afterLoc), p(i), L
                        }
                    },
                    catch: function(e) {
                        for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                            var i = this.tryEntries[t];
                            if (i.tryLoc === e) {
                                var o = i.completion;
                                if ("throw" === o.type) {
                                    var r = o.arg;
                                    p(i)
                                }
                                return r
                            }
                        }
                        throw new Error("illegal catch attempt")
                    },
                    delegateYield: function(e, t, i) {
                        return this.delegate = {
                            iterator: f(e),
                            resultName: t,
                            nextLoc: i
                        }, "next" === this.method && (this.arg = void 0), L
                    }
                }, y
            }

            function m(e) {
                return function(e) {
                    if (Array.isArray(e)) return y(e)
                }(e) || function(e) {
                    if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
                }(e) || h(e) || function() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function u(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }

            function p(e, t) {
                for (var i = 0; i < t.length; i++) {
                    var o = t[i];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, (void 0, r = function(e, t) {
                        if ("object" !== g(e) || null === e) return e;
                        var i = e[Symbol.toPrimitive];
                        if (void 0 !== i) {
                            var o = i.call(e, t);
                            if ("object" !== g(o)) return o;
                            throw new TypeError("@@toPrimitive must return a primitive value.")
                        }
                        return String(e)
                    }(o.key, "string"), "symbol" === g(r) ? r : String(r)), o)
                }
                var r
            }

            function d(e, t, i) {
                return t && p(e.prototype, t), i && p(e, i), Object.defineProperty(e, "prototype", {
                    writable: !1
                }), e
            }

            function f(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    var i = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != i) {
                        var o, r, n, a, s = [],
                            c = !0,
                            l = !1;
                        try {
                            if (n = (i = i.call(e)).next, 0 === t) {
                                if (Object(i) !== i) return;
                                c = !1
                            } else
                                for (; !(c = (o = n.call(i)).done) && (s.push(o.value), s.length !== t); c = !0);
                        } catch (e) {
                            l = !0, r = e
                        } finally {
                            try {
                                if (!c && null != i.return && (a = i.return(), Object(a) !== a)) return
                            } finally {
                                if (l) throw r
                            }
                        }
                        return s
                    }
                }(e, t) || h(e, t) || function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function h(e, t) {
                if (e) {
                    if ("string" == typeof e) return y(e, t);
                    var i = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === i && e.constructor && (i = e.constructor.name), "Map" === i || "Set" === i ? Array.from(e) : "Arguments" === i || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i) ? y(e, t) : void 0
                }
            }

            function y(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var i = 0, o = new Array(t); i < t; i++) o[i] = e[i];
                return o
            }

            function g(e) {
                return (g = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function v(e, t, i, o) {
                return new(i || (i = w))((function(r, n) {
                    function a(e) {
                        try {
                            c(o.next(e))
                        } catch (e) {
                            n(e)
                        }
                    }

                    function s(e) {
                        try {
                            c(o.throw(e))
                        } catch (e) {
                            n(e)
                        }
                    }

                    function c(e) {
                        var t;
                        e.done ? r(e.value) : (t = e.value, t instanceof i ? t : new i((function(e) {
                            e(t)
                        }))).then(a, s)
                    }
                    c((o = o.apply(e, t || [])).next())
                }))
            }

            function _(e) {
                if (!E) return !1;
                var t;
                try {
                    t = window[e];
                    var i = "__storage_test__";
                    return t.setItem(i, i), t.removeItem(i), !0
                } catch (e) {
                    return !(!(e instanceof DOMException) || 22 !== e.code && 1014 !== e.code && "QuotaExceededError" !== e.name && "NS_ERROR_DOM_QUOTA_REACHED" !== e.name || !t || 0 === t.length)
                }
            }

            function k(e) {
                return "string" == typeof e && !!e.trim()
            }

            function S(e, t) {
                var i = e.split(";").filter(k),
                    o = i.shift().split("="),
                    r = o.shift(),
                    n = o.join("=");
                t = t ? (0, O.A)({}, se, t) : se;
                try {
                    n = t.decodeValues ? decodeURIComponent(n) : n
                } catch (e) {
                    console.error("set-cookie-parser encountered an error while decoding a cookie with value '" + n + "'. Set options.decodeValues to false to disable this feature.", e)
                }
                var a = {
                    name: r,
                    value: n
                };
                return i.forEach((function(e) {
                    var t = e.split("="),
                        i = t.shift().trimLeft().toLowerCase(),
                        o = t.join("=");
                    "expires" === i ? a.expires = new Date(o) : "max-age" === i ? a.maxAge = parseInt(o, 10) : "secure" === i ? a.secure = !0 : "httponly" === i ? a.httpOnly = !0 : "samesite" === i ? a.sameSite = o : a[i] = o
                })), a
            }

            function b(e, t) {
                if (t = t ? (0, O.A)({}, se, t) : se, !e) return t.map ? {} : [];
                if (e.headers && e.headers["set-cookie"]) e = e.headers["set-cookie"];
                else if (e.headers) {
                    var i = e.headers[Object.keys(e.headers).find((function(e) {
                        return "set-cookie" === e.toLowerCase()
                    }))];
                    i || !e.headers.cookie || t.silent || console.warn("Warning: set-cookie-parser appears to have been called on a request object. It is designed to parse Set-Cookie headers from responses, not Cookie headers from requests. Set the option {silent: true} to suppress this warning."), e = i
                }
                return Array.isArray(e) || (e = [e]), (t = t ? (0, O.A)({}, se, t) : se).map ? e.filter(k).reduce((function(e, i) {
                    var o = S(i, t);
                    return e[o.name] = o, e
                }), {}) : e.filter(k).map((function(e) {
                    return S(e, t)
                }))
            }
            i.r(t), i.d(t, {
                COOKIE_POLICY_URL: function() {
                    return Le
                },
                COOKIE_SETTINGS_PAGE_URL: function() {
                    return we
                },
                Categories: function() {
                    return L
                },
                Cookies: function() {
                    return pe
                },
                LocalStorage: function() {
                    return ve
                },
                PERMISSIONS_COOKIE_NAME: function() {
                    return Y
                },
                Permissions: function() {
                    return Q
                },
                SessionStorage: function() {
                    return Oe
                }
            });
            var x, O = i(75205),
                w = i(26331).K7,
                L = {
                    authentication: {
                        necessary: !0
                    },
                    essential: {
                        necessary: !0
                    },
                    functional: {
                        necessary: !1,
                        token: "f",
                        deprecatedTokens: {
                            1: ["p", "s"]
                        }
                    },
                    advertising: {
                        necessary: !1,
                        token: "a"
                    }
                },
                I = function(e, t, i) {
                    return function(e) {
                        var t;
                        t = function() {
                            function e() {
                                for (var e = 0, t = {}; e < arguments.length; e++) {
                                    var i = arguments[e];
                                    for (var o in i) t[o] = i[o]
                                }
                                return t
                            }

                            function t(e) {
                                return e.replace(/(%[0-9A-Z]{2})+/g, decodeURIComponent)
                            }
                            return function i(o) {
                                function r() {}

                                function n(t, i, n) {
                                    if ("undefined" != typeof document) {
                                        "number" == typeof(n = e({
                                            path: "/"
                                        }, r.defaults, n)).expires && (n.expires = new Date(1 * new Date + 864e5 * n.expires)), n.expires = n.expires ? n.expires.toUTCString() : "";
                                        try {
                                            var a = JSON.stringify(i);
                                            /^[\{\[]/.test(a) && (i = a)
                                        } catch (e) {}
                                        i = o.write ? o.write(i, t) : encodeURIComponent(String(i)).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent), t = encodeURIComponent(String(t)).replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent).replace(/[\(\)]/g, escape);
                                        var s = "";
                                        for (var c in n) n[c] && (s += "; " + c, !0 !== n[c] && (s += "=" + n[c].split(";")[0]));
                                        return document.cookie = t + "=" + i + s
                                    }
                                }

                                function a(e, i) {
                                    if ("undefined" != typeof document) {
                                        for (var r = {}, n = document.cookie ? document.cookie.split("; ") : [], a = 0; a < n.length; a++) {
                                            var s = n[a].split("="),
                                                c = s.slice(1).join("=");
                                            i || '"' !== c.charAt(0) || (c = c.slice(1, -1));
                                            try {
                                                var l = t(s[0]);
                                                if (c = (o.read || o)(c, l) || t(c), i) try {
                                                    c = JSON.parse(c)
                                                } catch (e) {}
                                                if (r[l] = c, e === l) break
                                            } catch (e) {}
                                        }
                                        return e ? r[e] : r
                                    }
                                }
                                return r.set = n, r.get = function(e) {
                                    return a(e, !1)
                                }, r.getJSON = function(e) {
                                    return a(e, !0)
                                }, r.remove = function(t, i) {
                                    n(t, "", e(i, {
                                        expires: -1
                                    }))
                                }, r.defaults = {}, r.withConverter = i, r
                            }((function() {}))
                        }, e.exports = t()
                    }(i = {
                        path: void 0,
                        exports: {},
                        require: function(e, t) {
                            return function() {
                                throw new Error("Dynamic requires are not currently supported by @rollup/plugin-commonjs")
                            }(null == t && i.path)
                        }
                    }, i.exports), i.exports
                }(),
                E = function() {
                    try {
                        return !!window
                    } catch (e) {
                        return !1
                    }
                }() && "object" === ("undefined" == typeof window ? "undefined" : g(window)) && "object" === ("undefined" == typeof document ? "undefined" : g(document)) && 9 === document.nodeType,
                A = function(e, t) {
                    return !!t && (e === t || 0 !== t.length && "." === t[0] && (t === ".".concat(e) || e.length > t.length && e.endsWith(t)))
                },
                C = function(e) {
                    return !!e.match(/(\.|\/\/)onelink\.com(\/|$)/i)
                },
                P = function(e) {
                    return !C(e) && !!(e.match(/(\.)?link.com?\//i) || e.match("mkt-mydev.dev.stripe.me") && e.match("host=link") || e.match("-mkt.tunnel.stripe.me") && e.match("host=link") || e.match(/mkt(\.qa)?\.corp\.stripe\.com/i) && e.match("host=link") || e.match("link_app-mydev.dev.stripe.me") || e.match("link_support_site-mydev.dev.stripe.com"))
                },
                j = E && (x = window.location.hostname, ["stripe.com", "stripe.dev", "stripe.global", "stripe.partners", "increment.com", "link.co", "link.com"].some((function(e) {
                    var t = "(^|.)".concat(e.replace(/\./g, "\\."), "$");
                    return new RegExp(t).test(x)
                }))),
                q = "[stripe-cookies]",
                H = function(e) {
                    if (!j) {
                        for (var t, i = arguments.length, o = new Array(i > 1 ? i - 1 : 0), r = 1; r < i; r++) o[r - 1] = arguments[r];
                        (t = console).warn.apply(t, ["".concat(q, " ").concat(e)].concat(o))
                    }
                },
                R = function(e) {
                    if (!j) {
                        for (var t, i = arguments.length, o = new Array(i > 1 ? i - 1 : 0), r = 1; r < i; r++) o[r - 1] = arguments[r];
                        (t = console).error.apply(t, ["".concat(q, " ").concat(e)].concat(o))
                    }
                },
                N = "-mydev.dev.stripe.me",
                D = "-stripejs.tunnel.stripe.me",
                M = "-mkt.tunnel.stripe.me",
                T = [/(^|\.)qa\.stripe\.com$/, /(^|\.)(link|admin|docs)\.qa\.corp\.stripe\.com$/, /(^|\.)qa-dashboard\.stripe\.com$/, /(^|\.)qa-docs\.stripe\.com$/, /(^|\.)qa-bfcm\.stripe\.com$/],
                $ = [/(^|\.)qa\.link\.co$/, /(^|\.)qa-app\.stripe\.co$/],
                U = [/(^|\.)qa\.link\.com$/, /(^|\.)qa-app\.link\.com$/],
                V = [/(^|\.)qa\.onelink\.com$/, /(^|\.)qa-app\.onelink\.com$/],
                G = [/(^|\.)preprod\.stripe\.com$/, /(^|\.)(link|admin|docs)\.preprod\.corp\.stripe\.com$/, /(^|\.)preprod-dashboard\.stripe\.com$/, /(^|\.)preprod-dashboard\.stripe\.com$/, /(^|\.)preprod-docs\.stripe\.com$/],
                z = [/(^|\.)preprod\.onelink\.com$/, /(^|\.)preprod-app\.onelink\.com$/],
                F = ["https://c.stripe.dev/cookie", "https://c.stripe.global/cookie", "https://c.stripe.partners/cookie", "https://c.increment.com/cookie"],
                W = ["https://qa-c.stripe.dev/cookie", "https://qa-c.stripe.global/cookie", "https://qa-c.stripe.partners/cookie", "https://qa-c.increment.com/cookie"],
                B = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : E ? window.location.href : "";
                    return C(e) ? "https://onelink.com" : P(e) ? e.match(/(\.)?link.co([^m]|\b)/i) ? "https://link.co" : "https://link.com" : "https://stripe.com"
                },
                J = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : E ? window.location.href : "",
                        i = B(t) + e;
                    if (!E || !window.URL || !window.URLSearchParams) return i;
                    var o = new URL(t),
                        r = new URL(i);
                    if (o.hostname.match(N) || o.hostname.match(D)) {
                        var n, a = o.hostname.split(".", 1),
                            s = f(a, 1),
                            c = s[0];
                        if (c.split("--", 1)[0] !== c) {
                            var l = c.split("--", 1),
                                m = f(l, 1);
                            n = m[0], n += "-"
                        } else {
                            var u = c.split("-", 1),
                                p = f(u, 1);
                            n = p[0]
                        }
                        return r.hostname = "".concat(n, "-mkt-mydev.dev.stripe.me"), c.includes("manage-dashboard-proxy-mydev") && (r.hostname = "stripe.com"), i.includes("link.co") && (r.search = new URLSearchParams({
                            $host: "link"
                        }).toString()), r.toString()
                    }
                    return o.hostname.match(/(^|-)(dev|iso|corpiso)\.dev\.stripe\.me$/) ? i.replace("stripe.com", o.hostname) : T.some((function(e) {
                        return e.test(o.hostname)
                    })) ? i.replace("stripe.com", "qa.stripe.com") : G.some((function(e) {
                        return e.test(o.hostname)
                    })) ? i.replace("stripe.com", "preprod.stripe.com") : $.some((function(e) {
                        return e.test(o.hostname)
                    })) ? i.replace("link.co", "qa.link.co") : U.some((function(e) {
                        return e.test(o.hostname)
                    })) ? i.replace("link.com", "qa.link.com") : V.some((function(e) {
                        return e.test(o.hostname)
                    })) ? i.replace("onelink.com", "qa.onelink.com") : o.hostname.match(/(^|\.)preprod\.link\.co$/) || o.hostname.match(/(^|\.)preprod-app\.stripe\.co$/) ? i.replace("link.co", "preprod.link.co") : o.hostname.match(/(^|\.)preprod\.link\.com$/) || o.hostname.match(/(^|\.)preprod-app\.link\.com$/) ? i.replace("link.com", "preprod.link.com") : z.some((function(e) {
                        return e.test(o.hostname)
                    })) ? i.replace("onelink.com", "preprod.onelink.com") : o.hostname.match(/mkt(\.qa)?\.corp\.stripe\.com/i) || o.hostname.match(M) ? (r.hostname = o.hostname, i.includes("link.co") && (r.search = new URLSearchParams({
                        $host: "link"
                    }).toString()), r.toString()) : r.toString()
                },
                K = function() {
                    var e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : E ? window.location.href : "";
                    try {
                        e = new URL(t).hostname
                    } catch (e) {
                        return F
                    }
                    return [N, D, M].concat(T, $, U, V, [/(^|-)(dev|iso|corpiso)\.dev\.stripe\.me$/, /mkt\.qa\.corp\.stripe\.com/i]).some((function(t) {
                        return e.match(t)
                    })) ? W : F
                },
                Y = "cookie-perms",
                X = Object.keys(L),
                Q = function() {
                    function e(t, i, o) {
                        u(this, e), this._parsed_version = t, this._permissions = o, this._timestamp = i
                    }
                    return d(e, [{
                        key: "version",
                        get: function() {
                            return this._parsed_version
                        }
                    }, {
                        key: "timestamp",
                        get: function() {
                            return this._timestamp
                        }
                    }, {
                        key: "get",
                        value: function(e) {
                            return this._permissions[e]
                        }
                    }, {
                        key: "getAll",
                        value: function() {
                            return (0, O.A)({}, this._permissions)
                        }
                    }, {
                        key: "toString",
                        value: function() {
                            var t = this,
                                i = X.reduce((function(e, i) {
                                    var o = L[i];
                                    return o && !o.necessary && t._permissions[i] ? [].concat(m(e), [o.token]) : e
                                }), []).sort(),
                                o = Math.floor(this.timestamp.valueOf() / 1e3);
                            return "".concat(e.CURRENT_VERSION, ":").concat(o, "|").concat(i.join(""))
                        }
                    }], [{
                        key: "deserialize",
                        value: function(t) {
                            var i = f(t.split(":", 2), 2),
                                o = i[0],
                                r = i[1].split("|"),
                                n = new Date(1e3 * Number(r[0])),
                                a = r[1].split(""),
                                s = X.reduce((function(e, t) {
                                    var i = L[t];
                                    if (i.necessary) e[t] = !0;
                                    else if (i.token) {
                                        var r = i.token,
                                            n = i.deprecatedTokens,
                                            s = null == n ? void 0 : n[o],
                                            c = [r].concat(m(s || []));
                                        e[t] = c.some((function(e) {
                                            return a.indexOf(e) >= 0
                                        }))
                                    }
                                    return e
                                }), {});
                            return new e(o, n, s)
                        }
                    }, {
                        key: "get",
                        value: function() {
                            try {
                                var t = I.get("cookie-perms");
                                if (t) return e.deserialize(t)
                            } catch (e) {}
                            return null
                        }
                    }, {
                        key: "set",
                        value: function(t) {
                            return v(this, void 0, void 0, l().mark((function i() {
                                var o, r, n, a = this;
                                return l().wrap((function(i) {
                                    for (;;) switch (i.prev = i.next) {
                                        case 0:
                                            if (o = function(e) {
                                                    return v(a, void 0, void 0, l().mark((function i() {
                                                        return l().wrap((function(i) {
                                                            for (;;) switch (i.prev = i.next) {
                                                                case 0:
                                                                    return i.prev = 0, i.next = 3, fetch(e, {
                                                                        method: "post",
                                                                        body: JSON.stringify(t),
                                                                        credentials: "include",
                                                                        headers: {
                                                                            "Content-Type": "application/json",
                                                                            "X-Requested-With": "cookies"
                                                                        }
                                                                    });
                                                                case 3:
                                                                    return i.abrupt("return", i.sent);
                                                                case 6:
                                                                    i.prev = 6, i.t0 = i.catch(0), i.t0 instanceof Error ? R(i.t0.message) : R("Unexpected error", i.t0);
                                                                case 9:
                                                                case "end":
                                                                    return i.stop()
                                                            }
                                                        }), i, null, [
                                                            [0, 6]
                                                        ])
                                                    })))
                                                }, r = J("/cookie-settings/update"), !P(r)) {
                                                i.next = 7;
                                                break
                                            }
                                            return i.next = 5, o(r);
                                        case 5:
                                            i.next = 10;
                                            break;
                                        case 7:
                                            return n = K(), i.next = 10, w.all([r].concat(m(n)).map(o));
                                        case 10:
                                            return i.abrupt("return", e.get());
                                        case 11:
                                        case "end":
                                            return i.stop()
                                    }
                                }), i)
                            })))
                        }
                    }, {
                        key: "allowAll",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function t() {
                                var i;
                                return l().wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return i = X.reduce((function(e, t) {
                                                return L[t].necessary || (e[t] = !0), e
                                            }), {}), t.abrupt("return", e.set(i));
                                        case 2:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })))
                        }
                    }, {
                        key: "rejectAll",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function t() {
                                var i;
                                return l().wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return i = X.reduce((function(e, t) {
                                                return L[t].necessary || (e[t] = !1), e
                                            }), {}), t.abrupt("return", e.set(i));
                                        case 2:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })))
                        }
                    }]), e
                }();
            Q.CURRENT_VERSION = "2";
            var Z = function() {
                    function e(t) {
                        u(this, e), this._getPermissions = t, this._callbacks = []
                    }
                    return d(e, [{
                        key: "addCallback",
                        value: function(e) {
                            this._callbacks.indexOf(e) >= 0 ? R("PermissionsWatcher.addCallback() was called for a function that was already registered with the PermissionsWatcher.") : (this._callbacks.push(e), this._interval || this._pollForPermissionsChanges())
                        }
                    }, {
                        key: "removeCallback",
                        value: function(e) {
                            var t = this._callbacks.indexOf(e);
                            t < 0 ? R("PermissionsWatcher.removeCallback() was called for a function that wasn't registered with the PermissionsWatcher.") : (this._callbacks.splice(t, 1), this._interval && 0 === this._callbacks.length && (clearInterval(this._interval), this._interval = null))
                        }
                    }, {
                        key: "_pollForPermissionsChanges",
                        value: function() {
                            var e = this,
                                t = this._getPermissions();
                            this._interval = setInterval((function() {
                                var i = e._getPermissions();
                                if (null !== i) {
                                    var o = null === t && null !== i,
                                        r = t && i && t.timestamp !== i.timestamp;
                                    (o || r) && e._callbacks.forEach((function(e) {
                                        return e(i)
                                    })), t = i
                                }
                            }), 100)
                        }
                    }]), e
                }(),
                ee = null,
                te = function() {
                    function e(t) {
                        u(this, e), this._watcher = new Z((function() {
                            return Q.get()
                        })), t.enforcementMode && (this._enforcementModeValue = t.enforcementMode)
                    }
                    return d(e, [{
                        key: "getEnforcementMode",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function e() {
                                return l().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.abrupt("return", this.getEnforcementModeMaybeSync());
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })))
                        }
                    }, {
                        key: "getEnforcementModeMaybeSync",
                        value: function() {
                            var e = this;
                            if (!this._enforcementModeValue) {
                                var t = (ee || (ee = w.race([v(void 0, void 0, void 0, l().mark((function e() {
                                    var t, i, o, r;
                                    return l().wrap((function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                return t = "restricted", e.prev = 1, e.next = 4, fetch(J("/cookie-settings/enforcement-mode"));
                                            case 4:
                                                return i = e.sent, e.next = 7, i.json();
                                            case 7:
                                                o = e.sent, "restricted" !== (r = o.mode) && "open" !== r && "functional" !== r || (t = r), e.next = 14;
                                                break;
                                            case 12:
                                                e.prev = 12, e.t0 = e.catch(1);
                                            case 14:
                                                return e.abrupt("return", t);
                                            case 15:
                                            case "end":
                                                return e.stop()
                                        }
                                    }), e, null, [
                                        [1, 12]
                                    ])
                                }))), new w((function(e) {
                                    setTimeout((function() {
                                        return e("restricted")
                                    }), 1e3)
                                }))])), ee);
                                t.then((function(t) {
                                    e._enforcementModeValue = t
                                })), this._enforcementModeValue = t
                            }
                            return this._enforcementModeValue
                        }
                    }, {
                        key: "getPermissions",
                        value: function() {
                            return Q.get()
                        }
                    }, {
                        key: "setPermissions",
                        value: function(e) {
                            return v(this, void 0, void 0, l().mark((function t() {
                                return l().wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return t.abrupt("return", Q.set(e));
                                        case 1:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })))
                        }
                    }, {
                        key: "allowAll",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function e() {
                                return l().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.abrupt("return", Q.allowAll());
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })))
                        }
                    }, {
                        key: "rejectAll",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function e() {
                                return l().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.abrupt("return", Q.rejectAll());
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })))
                        }
                    }, {
                        key: "isCategoryAllowed",
                        value: function(e) {
                            return v(this, arguments, void 0, (function(e) {
                                var t = this,
                                    i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                                return l().mark((function o() {
                                    return l().wrap((function(o) {
                                        for (;;) switch (o.prev = o.next) {
                                            case 0:
                                                return o.abrupt("return", t.isCategoryAllowedMaybeSync(e, i));
                                            case 1:
                                            case "end":
                                                return o.stop()
                                        }
                                    }), o)
                                }))()
                            }))
                        }
                    }, {
                        key: "isCategoryAllowedMaybeSync",
                        value: function(e) {
                            var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                                i = Q.get();
                            if (L[e].necessary) return !0;
                            if (!t && "advertising" === e && "undefined" != typeof navigator) {
                                var o = navigator;
                                if (null == o ? void 0 : o.globalPrivacyControl) return !1
                            }
                            if (i) return !!i.get(e);
                            var r = this.getEnforcementModeMaybeSync();
                            return "string" == typeof r ? "functional" === r ? "advertising" !== e : "restricted" !== r : r.then((function(t) {
                                return "functional" === t ? "advertising" !== e : "restricted" !== t
                            }))
                        }
                    }, {
                        key: "areCategoriesAllowed",
                        value: function() {
                            for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++) t[i] = arguments[i];
                            return v(this, void 0, void 0, l().mark((function e() {
                                var i, o, r;
                                return l().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            i = 0, o = t;
                                        case 1:
                                            if (!(i < o.length)) {
                                                e.next = 11;
                                                break
                                            }
                                            return r = o[i], e.next = 5, this.isCategoryAllowed(r);
                                        case 5:
                                            if (e.sent) {
                                                e.next = 8;
                                                break
                                            }
                                            return e.abrupt("return", !1);
                                        case 8:
                                            i++, e.next = 1;
                                            break;
                                        case 11:
                                            return e.abrupt("return", !0);
                                        case 12:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })))
                        }
                    }, {
                        key: "shouldShowBanner",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function e() {
                                var t;
                                return l().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            if (!this.getPermissions()) {
                                                e.next = 3;
                                                break
                                            }
                                            return e.abrupt("return", !1);
                                        case 3:
                                            return e.next = 5, this.getEnforcementMode();
                                        case 5:
                                            return t = e.sent, e.abrupt("return", "restricted" === t || "functional" === t);
                                        case 7:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e, this)
                            })))
                        }
                    }, {
                        key: "watchPermissions",
                        value: function(e) {
                            this._watcher.addCallback(e)
                        }
                    }, {
                        key: "unwatchPermissions",
                        value: function(e) {
                            this._watcher.removeCallback(e)
                        }
                    }]), e
                }(),
                ie = function() {
                    function e(t, i) {
                        u(this, e), this.name = t, this.category = i.category, this.lifetime = i.lifetime, this.domains = i.domains, this.secure = !(!1 === i.secure), this.httpOnly = !(!1 === i.httpOnly), this.sameSite = i.sameSite || "Lax", this.name.indexOf("*") >= 0 ? (this.inexact = !0, this._regexp = new RegExp(t.replace("*", ".+"))) : this.inexact = !1
                    }
                    return d(e, [{
                        key: "isMatch",
                        value: function(e) {
                            return this.name === e || this._regexp && this._regexp.test(e)
                        }
                    }, {
                        key: "resolveDomain",
                        value: function(e, t) {
                            if (!this.name.startsWith("__Host-")) {
                                var i = [];
                                this.domains && (i = this.domains.map((function(e) {
                                    return t[e] || e
                                })));
                                var o = e;
                                if (!o && E && (o = document.location.host), o && o.match("dev.stripe.me")) return ".dev.stripe.me";
                                if (o && !i.some((function(e) {
                                        return A(o, e)
                                    }))) throw new Error("The ".concat(this.name, " cookie is not allowed to be set on the ").concat(o, " domain."));
                                return o || i[0]
                            }
                        }
                    }, {
                        key: "resolveExpiry",
                        value: function(e) {
                            if ("forever" !== this.lifetime) {
                                if ("session" !== this.lifetime) {
                                    var t = this.lifetime || 0;
                                    if (e) {
                                        if (t < e) throw new Error("The ".concat(this.name, " cookie has a maximum lifetime of ").concat(this.lifetime, " seconds."));
                                        t = e
                                    }
                                    return new Date(Date.now() + 1e3 * t)
                                }
                                if (e) throw new Error("The ".concat(this.name, " cookie cannot have a lifetime, because it is a session cookie."))
                            }
                        }
                    }]), e
                }(),
                oe = {
                    "__Secure-1PAPISID": {
                        category: "essential",
                        domains: [".google.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Secure-1PSID": {
                        category: "essential",
                        domains: [".google.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Secure-1PSIDCC": {
                        category: "essential",
                        domains: [".google.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Secure-3PAPISID": {
                        category: "essential",
                        domains: [".google.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Secure-3PSID": {
                        category: "essential",
                        domains: [".google.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Secure-3PSIDCC": {
                        category: "essential",
                        domains: [".google.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    __ps_did: {
                        category: "advertising",
                        domains: [".stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    __ps_fva: {
                        category: "advertising",
                        domains: [".stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    __ps_lu: {
                        category: "advertising",
                        domains: [".stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    __ps_r: {
                        category: "advertising",
                        domains: [".stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    __ps_slu: {
                        category: "advertising",
                        domains: [".stripe.com"],
                        lifetime: 1800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    __ps_sr: {
                        category: "advertising",
                        domains: [".stripe.com"],
                        lifetime: 1800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    __stripe_mid: {
                        category: "essential",
                        domains: [".checkout.stripe.com", ".link.co", ".link.com", ".onelink.com", "request"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    __stripe_orig_props: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    __stripe_sid: {
                        category: "essential",
                        domains: [".checkout.stripe.com", ".link.co", ".link.com", ".onelink.com", "request"],
                        lifetime: 1800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _cfduid: {
                        category: "advertising",
                        domains: [".stripecdn.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _fbp: {
                        category: "advertising",
                        domains: [".facebook.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 7862400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _forum_session: {
                        category: "authentication",
                        domains: [".discuss.stripe.community"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    _ga: {
                        category: "advertising",
                        domains: [".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "_ga*": {
                        category: "advertising",
                        domains: [".stripe.com", ".stripe.events", ".go.stripe.global", ".link.co", ".link.com", ".portal.stripe.partners", ".onelink.com"],
                        lifetime: 5184e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _gat: {
                        category: "functional",
                        domains: [".stripe.com", ".stripe.events", ".go.stripe.global", ".portal.stripe.partners"],
                        lifetime: 60,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _gat_stripe_com: {
                        category: "functional",
                        domains: [".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 60,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "_gat_UA-12675062-5": {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 60,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "_gat_UA-12675062-14": {
                        category: "functional",
                        domains: [".link.co", ".link.com", ".onelink.com"],
                        lifetime: 60,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "_gac_gb_G-SEKFWD1C9J": {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global"],
                        lifetime: 5184e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _gcl_au: {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global"],
                        lifetime: 7862400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _gid: {
                        category: "functional",
                        domains: [".stripe.com", ".go.stripe.global", ".link.co", ".link.com", ".onelink.com", ".portal.stripe.partners"],
                        lifetime: 86400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _GRECAPTCHA: {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    _guid: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 86400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _mkto_trk: {
                        category: "advertising",
                        domains: [".stripecdn.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _pxhd: {
                        category: "advertising",
                        domains: [".stripecdn.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _t: {
                        category: "authentication",
                        domains: [".discuss.stripe.community"],
                        lifetime: 5270400,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    _uetmsclkid: {
                        category: "advertising",
                        domains: [".stripe.com"],
                        lifetime: 7776e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _uetsid: {
                        category: "advertising",
                        domains: [".stripe.com"],
                        lifetime: 86400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _uetvid: {
                        category: "advertising",
                        domains: [".stripe.com"],
                        lifetime: 34214400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    aam_uuid: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 2592e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    act_token: {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "allow-unsupported-browser": {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "AMCV_*": {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    AnalyticsSyncHistory: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 2592e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    anonymous_overrides: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 1209600,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    APISID: {
                        category: "essential",
                        domains: [".google.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    ark_in_cad_opt_out: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    art_token: {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "__Host-arct_token": {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    atlas_invite: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    bcookie: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    business_intents_data: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 3600,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    c_user: {
                        category: "advertising",
                        domains: [".clearbit.com", ".facebook.com", ".go.stripe.global", ".stripe.com", ".stripe.events"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    cbt_token: {
                        category: "essential",
                        domains: ["dashboard.stripe.com", "connect.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    china_info_notification_dismissed: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    eid: {
                        category: "functional",
                        domains: [".checkout.stripe.com"],
                        lifetime: 5270400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    cid: {
                        category: "functional",
                        domains: [".stripe.com", ".link.com", ".link.co", ".onelink.com"],
                        lifetime: 7862400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-cliauth_token": {
                        category: "authentication",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 1800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Strict"
                    },
                    "color-scheme": {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    connect_locale: {
                        category: "essential",
                        domains: [".connect.stripe.com", ".express.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "cookie-perms": {
                        category: "essential",
                        domains: [".stripe.com", ".stripe.dev", ".go.stripe.global", ".increment.com", ".link.co", ".link.com", ".onelink.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    country: {
                        category: "essential",
                        domains: [".link.co", ".link.com", ".stripe.com", ".onelink.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    csv: {
                        category: "advertising",
                        domains: [".reddit.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    datr: {
                        category: "advertising",
                        domains: [".facebook.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    disable_cmd_f_override: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "docs.prefs": {
                        category: "functional",
                        domains: [".stripe.com", ".dev.stripe.me"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    double_cmd_f_uses: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    dpr: {
                        category: "advertising",
                        domains: [".facebook.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    edgebucket: {
                        category: "advertising",
                        domains: [".reddit.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 39484800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    ev: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 5270400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "expanded-topics": {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    fr: {
                        category: "advertising",
                        domains: [".facebook.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 7862400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Secure-f-visitor-id": {
                        category: "essential",
                        domains: [".link.com", ".stripe.com", ".stripecdn.com", ".onelink.com"],
                        lifetime: 86400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "None"
                    },
                    gh_src: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    GPS: {
                        category: "advertising",
                        domains: [".youtube.com"],
                        lifetime: 1800,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    handoff: {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: 9e4,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    has_intentionally_selected_curl: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-has_recently_requested_netsuite_connector_*": {
                        category: "essential",
                        domains: ["marketplace.stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-has_recently_requested_salesforce_cpq_connector_*": {
                        category: "essential",
                        domains: ["marketplace.stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-has_recently_requested_sap_connector_*": {
                        category: "essential",
                        domains: ["marketplace.stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    HSID: {
                        category: "essential",
                        domains: [".google.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    IDE: {
                        category: "advertising",
                        domains: [".doubleclick.net"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    invite: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    lang: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    lc_token: {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    _ldbrbid: {
                        category: "advertising",
                        domains: [".line.me", ".stripe.com", ".go.stripe.global"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    li_oatml: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 2592e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    li_sugr: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 7862400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    liap: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    lidc: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global", ".stripe.events"],
                        lifetime: 86400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-LinkSession": {
                        category: "authentication",
                        domains: ["checkout-cookies.stripe.com", "checkout-cookies.link.com", "merchant-ui-api.stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "None"
                    },
                    "__Secure-LinkSessionPresent": {
                        category: "essential",
                        domains: [".stripe.com", ".link.com", ".onelink.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "None"
                    },
                    "__Secure-HasLoggedIntoLinkApp": {
                        category: "essential",
                        domains: [".link.com", ".onelink.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "None"
                    },
                    "__Secure-IsLoggedIntoLinkApp": {
                        category: "essential",
                        domains: [".link.com", ".onelink.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "None"
                    },
                    lissc: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    locale: {
                        category: "essential",
                        domains: [".link.co", ".link.com", ".stripe.com", ".onelink.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    loid: {
                        category: "advertising",
                        domains: [".reddit.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    m: {
                        category: "essential",
                        domains: [".m.stripe.com"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "m-tz": {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global", ".stripe.events"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "m-ans_frontend_early_version": {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global", ".stripe.events"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "m-s": {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global", ".stripe.events"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "m-b_strict": {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global", ".stripe.events"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "m-b_lax": {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global", ".stripe.events"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "m-uid": {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global", ".stripe.events"],
                        lifetime: 57888e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "m-b": {
                        category: "advertising",
                        domains: [".stripe.com", ".go.stripe.global", ".stripe.events"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    machine_identifier: {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    merchant: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "None"
                    },
                    MR: {
                        category: "advertising",
                        domains: [".stripe.com"],
                        lifetime: 34214400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    MSPTC: {
                        category: "advertising",
                        domains: [".stripe.com"],
                        lifetime: 34214400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    MUID: {
                        category: "advertising",
                        domains: [".stripe.com"],
                        lifetime: 34214400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    NID: {
                        category: "essential",
                        domains: [".google.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    over18: {
                        category: "advertising",
                        domains: [".reddit.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 47347200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    pay_sid: {
                        category: "authentication",
                        domains: [".link.co", ".link.com", ".onelink.com", ".link.corp.stripe.com", ".link.qa.corp.stripe.com", ".onelink.corp.stripe.com", ".onelink.qa.corp.stripe.com", ".link-support-site.corp.stripe.com", ".link-support-site.qa.corp.stripe.com", ".link-support-site.preprod.corp.stripe.com", ".onelink-support-site.corp.stripe.com", ".onelink-support-site.qa.corp.stripe.com", ".onelink-support-site.preprod.corp.stripe.com", ".dev.stripe.me"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    private_machine_identifier: {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "None"
                    },
                    prt_token: {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "recent-views": {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    recent_srs: {
                        category: "advertising",
                        domains: [".reddit.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "saml_sca_success_for_*": {
                        category: "authentication",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 30,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    samlit_email: {
                        category: "authentication",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 960,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    samlit_token: {
                        category: "authentication",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 960,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    SAPISID: {
                        category: "essential",
                        domains: [".google.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    sb: {
                        category: "advertising",
                        domains: [".facebook.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    sca_migration_not_started_alert_actioned: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    scfc: {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    sdsc: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-sessions_on_demand_qualified": {
                        category: "essential",
                        domains: ["stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    session_tracker: {
                        category: "advertising",
                        domains: [".reddit.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    SID: {
                        category: "essential",
                        domains: [".google.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    SIDCC: {
                        category: "essential",
                        domains: [".google.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    sp_adid: {
                        category: "advertising",
                        domains: ["spotify.com", "stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    sp_landing: {
                        category: "advertising",
                        domains: ["spotify.com", "stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    sp_t: {
                        category: "advertising",
                        domains: ["spotify.com", "stripe.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Secure-sid": {
                        category: "functional",
                        domains: [".stripe.com", ".link.com", ".onelink.com"],
                        lifetime: 1800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    SSID: {
                        category: "essential",
                        domains: [".google.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    token_v2: {
                        category: "advertising",
                        domains: [".reddit.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "__Host-session": {
                        category: "authentication",
                        domains: ["support.stripe.com", "support-conversations.stripe.com", "stripe.com", "dashboard.stripe.com", "connect.stripe.com", "express.stripe.com", "marketplace.stripe.com", "docs.stripe.com", "access.stripe.com", "workbench.stripe.com", "invoicedata.stripe.com", "profile.stripe.com", "dashboard-admin.stripe.com", "site-admin.stripe.com", "support-admin.corp.stripe.com", "support-conversations.corp.stripe.com", "manage.stripe.com", "billing.stripe.com", "pay.stripe.com"],
                        lifetime: 7776e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "__Host-auth_token": {
                        category: "authentication",
                        domains: ["dashboard.stripe.com", "dashboard-admin.stripe.com", "docs.stripe.com", "marketplace.stripe.com", "support.stripe.com", "access.stripe.com", "invoicedata.stripe.com"],
                        lifetime: 7776e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "__Host-stripe.link_app.csrf": {
                        category: "essential",
                        domains: ["app.link.co", "app.link.com", "link.corp.stripe.com", "link.qa.corp.stripe.com", "app.onelink.com", "onelink.corp.stripe.com", "onelink.qa.corp.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "__Secure-stripe.link_app.last_link_brand": {
                        category: "essential",
                        domains: [".link.com", ".onelink.com"],
                        lifetime: 86400,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "__Host-shopify_app_session": {
                        category: "authentication",
                        domains: ["sbyog-ppp-external.stripe.com"],
                        lifetime: 86400,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    site_sid: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 7200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "site-auth": {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    skip_mismatched_country_check: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    skip_tfa_interrupt: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 2592e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    spin: {
                        category: "advertising",
                        domains: [".facebook.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    spl: {
                        category: "advertising",
                        domains: [".stripe.events"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "stripe.csrf": {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "None"
                    },
                    "stripe.appmarketplace.csrf": {
                        category: "essential",
                        domains: ["marketplace.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "stripe.climate.csrf": {
                        category: "essential",
                        domains: ["climate.stripe.com", "edge-climate.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "stripe.customerportal.csrf": {
                        category: "essential",
                        domains: ["billing.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "__Host-stripe.customerportal.sid": {
                        category: "authentication",
                        domains: ["billing.stripe.com"],
                        lifetime: 86400,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "stripe.docs.csrf": {
                        category: "essential",
                        domains: ["docs.stripe.com", "edge-docs.stripe.com", "docs.corp.stripe.com", "docs.qa.corp.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    svt_token: {
                        category: "essential",
                        domains: ["dashboard.stripe.com", "connect.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    tuuid: {
                        category: "advertising",
                        domains: [".demandbase.com", ".stripe.com"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    tuuid_lu: {
                        category: "advertising",
                        domains: [".demandbase.com", ".stripe.com"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    U: {
                        category: "advertising",
                        domains: [".adsymptotic.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 7862400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    UserMatchHistory: {
                        category: "advertising",
                        domains: [".stripe.com", ".linkedin.com", ".ads.linkedin.com", ".go.stripe.global"],
                        lifetime: 2592e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    user: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    VISITOR_INFO1_LIVE: {
                        category: "advertising",
                        domains: [".youtube.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    wd: {
                        category: "advertising",
                        domains: [".facebook.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    xs: {
                        category: "advertising",
                        domains: [".facebook.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    XA: {
                        category: "advertising",
                        domains: [".yahoo.co.jp", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    XB: {
                        category: "advertising",
                        domains: [".yahoo.co.jp", ".go.stripe.global"],
                        lifetime: 52617600,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    ndcd: {
                        category: "essential",
                        domains: [".acs.touch.tech", ".idcheck.acs.touchtechpayments.com", ".verifiedbyvisa.acs.touchtechpayments.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    YSC: {
                        category: "advertising",
                        domains: [".youtube.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "stripe.delegated-authentication.csrf": {
                        category: "essential",
                        domains: ["delegated-authentication.stripe.com", "oneclickauthn.qa.corp.stripe.com", "oneclickauthn.corp.stripe.com"],
                        lifetime: 1800,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    payment_methods_settings_platform: {
                        category: "functional",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    VisitorId: {
                        category: "advertising",
                        domains: [".stripecdn.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-stripe.link_support_site.csrf": {
                        category: "essential",
                        domains: ["support.link.co", "support.link.com", "support.onelink.com", "link-support-site.corp.stripe.com", "link-support-site.qa.corp.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "__Host-stripe.sources_redirect_site.csrf": {
                        category: "essential",
                        domains: ["hooks.stripe.com", "hooks.qa.corp.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    saml_login_result: {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-saml_auth_result": {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 60,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-stripe.support_site.csrf": {
                        category: "essential",
                        domains: ["support.stripe.com", "edge-support.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "__Host-unauthenticated_support_identity": {
                        category: "authentication",
                        domains: ["support.stripe.com", "support.link.co", "support.link.com", "support.onelink.com", "support-conversations.stripe.com", "edge-support-conversations.stripe.com", "support-conversations.link.co", "support-conversations.link.com", "support-conversations.onelink.com", "dashboard.stripe.com", "edge-dashboard.stripe.com", "dashboard-admin.stripe.com", "admin.corp.stripe.com", "commerce-assistant.corp.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "__Host-stripe.site.csrf": {
                        category: "essential",
                        domains: ["stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "__Host-upsess": {
                        category: "authentication",
                        domains: ["privacy.stripe.com"],
                        lifetime: 1800,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "__Host-privacy-csat": {
                        category: "functional",
                        domains: ["privacy.stripe.com"],
                        lifetime: 2592e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Strict"
                    },
                    "__Host-stripe.mkt.csrf": {
                        category: "essential",
                        domains: ["stripe.com", "press.stripe.com", "link.com", "site-admin.stripe.com", "edge.stripe.com", "edge-press.stripe.com", "onelink.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Strict"
                    },
                    "__Secure-webchat_qualification": {
                        category: "advertising",
                        domains: [".stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Strict"
                    },
                    "__Host-webchat_widget": {
                        category: "essential",
                        domains: ["sales-live-chat.stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Strict"
                    },
                    "__Host-webchat_state": {
                        category: "essential",
                        domains: ["sales-live-chat.stripe.com", "stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Strict"
                    },
                    "__Host-webchat_survey": {
                        category: "essential",
                        domains: ["sales-live-chat.stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Strict"
                    },
                    "__Secure-has_logged_in": {
                        category: "essential",
                        domains: [".stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Strict"
                    },
                    muc_ads: {
                        category: "advertising",
                        domains: [".t.co", ".stripe.com", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    personalization_id: {
                        category: "advertising",
                        domains: [".twitter.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    guest_id: {
                        category: "advertising",
                        domains: [".twitter.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    guest_id_ads: {
                        category: "advertising",
                        domains: [".twitter.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    guest_id_marketing: {
                        category: "advertising",
                        domains: [".twitter.com", ".stripe.com", ".go.stripe.global"],
                        lifetime: 63072e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    glance_ssn_info: {
                        category: "functional",
                        domains: ["dashboard.stripe.com", "dev.stripe.me"],
                        lifetime: 28800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-oauth_registration_token": {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 600,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-oauth_it_token": {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 960,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    datadome: {
                        category: "essential",
                        domains: [".stripecdn.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _pxvid: {
                        category: "essential",
                        domains: [".stripecdn.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _px2: {
                        category: "essential",
                        domains: [".stripecdn.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _pxcts: {
                        category: "essential",
                        domains: [".stripecdn.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    pxcts: {
                        category: "essential",
                        domains: [".stripecdn.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-oauth_security_token": {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 960,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "__Host-oauth_code_verifier": {
                        category: "authentication",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 960,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "__Host-oauth_acf_secret": {
                        category: "authentication",
                        domains: ["dashboard.stripe.com"],
                        lifetime: 600,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "__Host-tax_connectors_bigcommerce_oauth_nonce": {
                        category: "authentication",
                        domains: ["tax-connectors.stripe.com"],
                        lifetime: 300,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "None"
                    },
                    _zitok: {
                        category: "functional",
                        domains: ["b.stripecdn.com"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _cfuvid: {
                        category: "functional",
                        domains: [".zoominfo.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _px3: {
                        category: "essential",
                        domains: [".zoominfo.com", ".stripecdn.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    __cf_bm: {
                        category: "functional",
                        domains: [".zoominfo.com"],
                        lifetime: 1800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-stripe.paywall.token": {
                        category: "authentication",
                        domains: ["paywall.stripe.com"],
                        lifetime: 3600,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "none"
                    },
                    "__Host-sandbox_assignment": {
                        category: "authentication",
                        domains: ["docs.stripe.com", "dashboard.stripe.com", "docs.corp.stripe.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "__Secure-PaymentMethodSelections-PayByBank": {
                        category: "essential",
                        domains: ["checkout-cookies.stripe.com", "checkout-cookies.link.com", "merchant-ui-api.stripe.com"],
                        lifetime: 15811200,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "None"
                    },
                    TTD_PID: {
                        category: "advertising",
                        domains: [".adsrvr.org"],
                        lifetime: 31536e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    uid: {
                        category: "advertising",
                        domains: [".ml-attr.com"],
                        lifetime: 34214400,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    uis_token: {
                        category: "essential",
                        domains: ["dashboard.stripe.com"],
                        lifetime: "session",
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _rdt_uuid: {
                        category: "advertising",
                        domains: [".reddit.com", ".stripe.com", ".stripe.events", ".go.stripe.global"],
                        lifetime: 7776e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _ly_r: {
                        category: "advertising",
                        domains: [".yahoo.co.jp"],
                        lifetime: 7776e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _ly_su: {
                        category: "advertising",
                        domains: [".yahoo.co.jp"],
                        lifetime: 7776e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _ly_c: {
                        category: "advertising",
                        domains: [".yahoo.co.jp"],
                        lifetime: 7776e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    _ycla_aw: {
                        category: "advertising",
                        domains: [".yahoo.co.jp"],
                        lifetime: 7776e3,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    },
                    "__Host-delegated_support_auth": {
                        category: "authentication",
                        domains: ["support.stripe.com"],
                        lifetime: 86400,
                        secure: !0,
                        httpOnly: !0,
                        sameSite: "Lax"
                    },
                    "__Host-onelink_uk_banner_dismissed": {
                        category: "functional",
                        domains: ["onelink.com", "app.onelink.com", "support.onelink.com"],
                        lifetime: 604800,
                        secure: !0,
                        httpOnly: !1,
                        sameSite: "Lax"
                    }
                },
                re = {},
                ne = null,
                ae = function(e) {
                    if (oe[e]) return new ie(e, oe[e]);
                    if (re[e]) return new ie(e, re[e]);
                    ne || (ne = [].concat(m(Object.entries(oe)), m(Object.entries(re))).map((function(e) {
                        var t = f(e, 2),
                            i = t[0],
                            o = t[1];
                        return new ie(i, o)
                    })).filter((function(e) {
                        return e.inexact
                    })));
                    var t, i = c(ne);
                    try {
                        for (i.s(); !(t = i.n()).done;) {
                            var o = t.value;
                            if (o.isMatch(e)) return o
                        }
                    } catch (e) {
                        i.e(e)
                    } finally {
                        i.f()
                    }
                    return null
                },
                se = {
                    decodeValues: !0,
                    map: !1,
                    silent: !1
                },
                ce = b,
                le = b,
                me = S;
            ce.parse = le, ce.parseString = me, ce.splitCookiesString = function(e) {
                function t() {
                    for (; c < e.length && /\s/.test(e.charAt(c));) c += 1;
                    return c < e.length
                }
                if (Array.isArray(e)) return e;
                if ("string" != typeof e) return [];
                for (var i, o, r, n, a, s = [], c = 0; c < e.length;) {
                    for (i = c, a = !1; t();)
                        if ("," === (o = e.charAt(c))) {
                            for (r = c, c += 1, t(), n = c; c < e.length && "=" !== (o = e.charAt(c)) && ";" !== o && "," !== o;) c += 1;
                            c < e.length && "=" === e.charAt(c) ? (a = !0, c = n, s.push(e.substring(i, r)), i = c) : c = r + 1
                        } else c += 1;
                    (!a || c >= e.length) && s.push(e.substring(i, e.length))
                }
                return s
            };
            var ue = null,
                pe = function() {
                    function e() {
                        var i, o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        if (u(this, e), (i = t.call(this, o))._domainOverrides = o.domainOverrides || {}, i._documentCookiePatched = !1, "undefined" != typeof navigator) {
                            var r = navigator;
                            if (null == r ? void 0 : r.globalPrivacyControl)
                                for (var n = I.get(), a = 0, s = Object.keys(n); a < s.length; a++) {
                                    var c = s[a],
                                        l = ae(c);
                                    "advertising" !== (null == l ? void 0 : l.category) || (null == l ? void 0 : l.httpOnly) || i.remove(c)
                                }
                        }
                        return i
                    }
                    o(e, te);
                    var t = n(e);
                    return d(e, [{
                        key: "get",
                        value: function(e) {
                            ae(e) || H("No cookie matching the name ".concat(e, " was found in the cookies.yaml or cookies-next.yaml manifests. ") + "Reading the value of the cookie will work, but attempting to set the cookie will result in an error. If you're adding a new cookie, please visit go/cookies for more information!");
                            var t = I.get(e);
                            return void 0 === t ? null : t
                        }
                    }, {
                        key: "set",
                        value: function(e, t) {
                            return v(this, arguments, void 0, (function(e, t) {
                                var i = this,
                                    o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
                                return l().mark((function r() {
                                    var n, a, s, c, m;
                                    return l().wrap((function(r) {
                                        for (;;) switch (r.prev = r.next) {
                                            case 0:
                                                if (n = ae(e)) {
                                                    r.next = 4;
                                                    break
                                                }
                                                return R("No cookie matching the name ".concat(e, " was found in the cookies.yaml or cookies-next.yaml manifests. ") + "If you're adding a new cookie, please visit go/cookies for more information!"), r.abrupt("return", !1);
                                            case 4:
                                                if (!n.httpOnly) {
                                                    r.next = 7;
                                                    break
                                                }
                                                return R("Cannot set the cookie ".concat(e, " via JavaScript, since it is marked HttpOnly. ") + "Please visit go/cookies for more information!"), r.abrupt("return", !1);
                                            case 7:
                                                r.prev = 7, a = n.resolveDomain(o.domain, i._domainOverrides), s = n.resolveExpiry(o.lifetime), r.next = 16;
                                                break;
                                            case 12:
                                                return r.prev = 12, r.t0 = r.catch(7), r.t0 instanceof Error ? R(r.t0.message) : R("Unexpected error", r.t0), r.abrupt("return", !1);
                                            case 16:
                                                return r.next = 18, i.isCategoryAllowed(n.category);
                                            case 18:
                                                if (r.sent) {
                                                    r.next = 22;
                                                    break
                                                }
                                                return H("Attempting to set cookie ".concat(e, " without the correct permissions: ").concat(n.category, " ") + "Please accept cookies and try again."), r.abrupt("return", !1);
                                            case 22:
                                                return !E || n.name.startsWith("__Host-") || A(window.location.hostname, a) || H("The cookie ".concat(e, " will be set on the domain ").concat(a, ", which doesn't match ") + "the current domain (".concat(window.location.hostname, "). This will result in the ") + "cookie being silently ignored by the browser. Please check to ensure the domain(s) for the cookie are correct in cookies[-next].yaml, or visit go/cookies for more information."), c = void 0 === o.secure ? n.secure : o.secure, m = i._getCookieAttributes({
                                                    domain: a,
                                                    expires: s,
                                                    secure: c,
                                                    sameSite: n.sameSite
                                                }), n.name.startsWith("__Host-") && (m.path = "/"), I.set(e, t, m), r.abrupt("return", !0);
                                            case 28:
                                            case "end":
                                                return r.stop()
                                        }
                                    }), r, null, [
                                        [7, 12]
                                    ])
                                }))()
                            }))
                        }
                    }, {
                        key: "remove",
                        value: function(e) {
                            var t, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                                o = ae(e);
                            if (!o) return R("No cookie matching the name ".concat(e, " was found in the cookies.yaml or cookies-next.yaml manifests. ") + "If you're adding a new cookie, please visit go/cookies for more information!"), !1;
                            try {
                                t = o.resolveDomain(i.domain, this._domainOverrides)
                            } catch (e) {
                                return e instanceof Error ? R(e.message) : R("Unexpected error", e), !1
                            }
                            E && !A(window.location.hostname, t) && H("The cookie ".concat(e, " will be set on the domain ").concat(t, ", which doesn't match ") + "the current domain (".concat(window.location.hostname, "). This will result in the ") + "cookie being silently ignored by the browser. Please check to ensure the domain(s) for the cookie are correct in cookies[-next].yaml, or visit go/cookies for more information.");
                            var r = this._getCookieAttributes({
                                domain: t,
                                secure: o.secure,
                                sameSite: o.sameSite
                            });
                            return I.remove(e, r), !0
                        }
                    }, {
                        key: "refresh",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function e() {
                                var t = this;
                                return l().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            Object.keys(I.get()).forEach((function(e) {
                                                var i = ae(e);
                                                if (i && I.get(e)) {
                                                    var o = t.isCategoryAllowedMaybeSync(i.category);
                                                    !1 === o && t.remove(e), o instanceof w && o.then((function(i) {
                                                        i || t.remove(e)
                                                    }))
                                                }
                                            }));
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })))
                        }
                    }, {
                        key: "trapDocumentCookie",
                        value: function() {
                            this._documentCookiePatched || (this._documentCookiePatched = function(e) {
                                if (!E) return R("You cannot patch document.cookie if you aren't in a browser."), !1;
                                if (ue || (ue = Object.getOwnPropertyDescriptor(Document.prototype, "cookie")), !ue || !ue.get || !ue.set) return !1;
                                var t = ue.get,
                                    i = ue.set;
                                return Object.defineProperty(document, "cookie", {
                                    configurable: !0,
                                    get: function() {
                                        for (var e = arguments.length, i = new Array(e), o = 0; o < e; o++) i[o] = arguments[o];
                                        return t.apply(this, i)
                                    },
                                    set: function(t) {
                                        if (!t || 0 === t.length) return i.apply(this, [t]);
                                        var o = me(t),
                                            r = o.name,
                                            n = o.value,
                                            a = o.domain;
                                        "true" === o.allowed ? i.apply(this, [t]) : e.set(r, n, {
                                            domain: a
                                        })
                                    }
                                }), !0
                            }(this))
                        }
                    }, {
                        key: "untrapDocumentCookie",
                        value: function() {
                            this._documentCookiePatched && (ue ? Object.defineProperty(document, "cookie", ue) : R("The document.cookie property has not been patched"), this._documentCookiePatched = !1)
                        }
                    }, {
                        key: "_getCookieAttributes",
                        value: function(e) {
                            var t = (0, O.A)({}, e);
                            return this._documentCookiePatched && (t.allowed = "true"), t
                        }
                    }]), e
                }(),
                de = function() {
                    function e(t, i) {
                        u(this, e), this.name = t, this.category = i.category, this.name.indexOf("*") >= 0 ? (this.inexact = !0, this._regexp = new RegExp(t.replace("*", ".+"))) : this.inexact = !1
                    }
                    return d(e, [{
                        key: "isMatch",
                        value: function(e) {
                            return this.name === e || this._regexp && this._regexp.test(e)
                        }
                    }]), e
                }(),
                fe = {
                    "dealdesk-*": {
                        category: "functional"
                    },
                    "*_dismissed": {
                        category: "functional"
                    },
                    "compliance-center.*": {
                        category: "essential"
                    },
                    "cockpit.*": {
                        category: "functional"
                    },
                    "dante:*": {
                        category: "essential"
                    },
                    "dev-agent-statics:*": {
                        category: "functional"
                    },
                    "sesame.announcementDismissed.*": {
                        category: "functional"
                    },
                    docs: {
                        category: "essential"
                    },
                    lsid: {
                        category: "functional"
                    },
                    "issuing-admin-overview-filters": {
                        category: "functional"
                    },
                    imt: {
                        category: "advertising"
                    },
                    keyboard_shortcuts: {
                        category: "functional"
                    },
                    personalizations: {
                        category: "functional"
                    },
                    "twilio_chat_*": {
                        category: "essential"
                    },
                    "yt-remote-connected-devices": {
                        category: "advertising"
                    },
                    "yt-remote-device-id": {
                        category: "advertising"
                    },
                    "yt.innertube::nextId": {
                        category: "advertising"
                    },
                    "yt.innertube::requests": {
                        category: "advertising"
                    },
                    "link.auth_session_client_secret": {
                        category: "authentication"
                    },
                    apps_oauth_state: {
                        category: "authentication"
                    },
                    list_view_spotlight_last_dismissed: {
                        category: "functional"
                    },
                    request_sign_key: {
                        category: "authentication"
                    },
                    easel_position: {
                        category: "essential"
                    },
                    easel_read_message_ids: {
                        category: "essential"
                    },
                    easel_test_customer_location: {
                        category: "essential"
                    },
                    user_session_token: {
                        category: "authentication"
                    },
                    "userleap.ids": {
                        category: "essential"
                    },
                    "userleap.pageviews": {
                        category: "essential"
                    },
                    workbenchState: {
                        category: "functional"
                    },
                    "dashboard.banner-dismissals": {
                        category: "essential"
                    },
                    "dashboard.nav-collapsed": {
                        category: "functional"
                    },
                    link_app_devtools: {
                        category: "essential"
                    },
                    "payment_method_settings.direct": {
                        category: "functional"
                    },
                    "verification-session-create--verification-flow-toggle--value": {
                        category: "functional"
                    },
                    "payment_method_settings.connect": {
                        category: "functional"
                    },
                    "rc::a": {
                        category: "essential"
                    },
                    "rc::f": {
                        category: "essential"
                    },
                    register_login_redesign: {
                        category: "functional"
                    },
                    "dashboard.setup-guide-closed": {
                        category: "functional"
                    },
                    "dashboard.setup-guide-collapsed": {
                        category: "functional"
                    },
                    logged_user: {
                        category: "essential"
                    },
                    "x-px-cookies": {
                        category: "essential"
                    },
                    "developers.apps.detail.permissionMigrationCallout.dismissed": {
                        category: "functional"
                    },
                    "stripe.paywall.token": {
                        category: "authentication"
                    },
                    devtools_copy_optimization_tools: {
                        category: "functional"
                    },
                    devtools_bento_show_overrides: {
                        category: "functional"
                    },
                    "connect.growth.recommendations.amount_filter": {
                        category: "functional"
                    },
                    devtools_show_product_boundaries: {
                        category: "functional"
                    },
                    devtools_show_product_availability: {
                        category: "functional"
                    },
                    devtools_disable_controlled_content_tracking: {
                        category: "functional"
                    },
                    "account-status-debug": {
                        category: "functional"
                    },
                    "support-beam-user-state": {
                        category: "functional"
                    },
                    "nebula-code-agent-acknowledge": {
                        category: "functional"
                    },
                    "billing_overview_settings.date_picker": {
                        category: "functional"
                    },
                    connect_overview_settings: {
                        category: "functional"
                    },
                    express_theme_preference: {
                        category: "functional"
                    },
                    "crypto.wallet_prefs": {
                        category: "functional"
                    },
                    sdp_incomplete_warehouse_setup: {
                        category: "functional"
                    },
                    "bfcm-2025-settings": {
                        category: "functional"
                    },
                    "biznet-landing-hero-profiles": {
                        category: "functional"
                    },
                    "dashboard.recent-metadata-keys": {
                        category: "functional"
                    },
                    "harbor-state": {
                        category: "functional"
                    },
                    "sdp.export_plan_tab_order": {
                        category: "functional"
                    },
                    balances_overview_view_mode_setting: {
                        category: "functional"
                    },
                    enable_react_devtools: {
                        category: "functional"
                    },
                    user_last_activity_ts: {
                        category: "functional"
                    },
                    currentUser: {
                        category: "functional"
                    },
                    pricing_session: {
                        category: "essential"
                    }
                },
                he = Object.keys(fe).reduce((function(e, t) {
                    var i = fe[t];
                    return e[t] = new de(t, i), e
                }), {}),
                ye = Object.keys(he).filter((function(e) {
                    return he[e].inexact
                })).map((function(e) {
                    return he[e]
                })),
                ge = function(e) {
                    if (he[e]) return he[e];
                    var t, i = c(ye);
                    try {
                        for (i.s(); !(t = i.n()).done;) {
                            var o = t.value;
                            if (o.isMatch(e)) return o
                        }
                    } catch (e) {
                        i.e(e)
                    } finally {
                        i.f()
                    }
                    return null
                },
                ve = function() {
                    function e() {
                        var i, o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        return u(this, e), i = t.call(this, o), _("localStorage") && setTimeout((function() {
                            i.refresh()
                        }), 0), i
                    }
                    o(e, te);
                    var t = n(e);
                    return d(e, [{
                        key: "isStorageAvailable",
                        value: function() {
                            return _("localStorage")
                        }
                    }, {
                        key: "get",
                        value: function(e) {
                            return ge(e) || H("No item matching the name ".concat(e, " was found in the localStorage.yaml manifest. ") + "Reading the value of the item will work, but attempting to set the item will result in an error. If you're adding a new localStorage item, please visit go/cookies for more information!"), _("localStorage") ? (this.refresh(), localStorage.getItem(e)) : null
                        }
                    }, {
                        key: "getKeyMatches",
                        value: function(e) {
                            if (!(e.indexOf("*") >= 0)) return H("Invalid pattern provided, no wildcard after other characters"), [];
                            var t = new RegExp("^".concat(e.replace("*", ".+"), "$"));
                            return Object.keys(localStorage).filter((function(e) {
                                return t.test(e)
                            })).filter((function(e) {
                                return ge(e)
                            }))
                        }
                    }, {
                        key: "set",
                        value: function(e, t) {
                            return v(this, void 0, void 0, l().mark((function i() {
                                var o;
                                return l().wrap((function(i) {
                                    for (;;) switch (i.prev = i.next) {
                                        case 0:
                                            if (o = ge(e)) {
                                                i.next = 4;
                                                break
                                            }
                                            return R("No item matching the name ".concat(e, " was found in the localStorage.yaml manifest. ") + "If you're adding a new item, please visit go/cookies for more information!"), i.abrupt("return", !1);
                                        case 4:
                                            return i.next = 6, this.isCategoryAllowed(o.category);
                                        case 6:
                                            if (i.sent) {
                                                i.next = 10;
                                                break
                                            }
                                            return H("Attempting to set localStorage ".concat(e, " without the correct permissions. ") + "Please accept cookies and try again."), i.abrupt("return", !1);
                                        case 10:
                                            if (_("localStorage")) {
                                                i.next = 12;
                                                break
                                            }
                                            return i.abrupt("return", !1);
                                        case 12:
                                            return localStorage.setItem(e, t), i.abrupt("return", !0);
                                        case 14:
                                        case "end":
                                            return i.stop()
                                    }
                                }), i, this)
                            })))
                        }
                    }, {
                        key: "remove",
                        value: function(e) {
                            return ge(e) ? !!_("localStorage") && (localStorage.removeItem(e), !0) : (R("No item matching the name ".concat(e, " was found in the localStorage.yaml manifest. ") + "If you're adding a new item, please visit go/cookies for more information!"), !1)
                        }
                    }, {
                        key: "refresh",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function e() {
                                var t = this;
                                return l().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            Object.keys(localStorage).forEach((function(e) {
                                                var i = ge(e);
                                                if (i && localStorage.getItem(e)) {
                                                    var o = t.isCategoryAllowedMaybeSync(i.category);
                                                    !1 === o && localStorage.removeItem(e), o instanceof w && o.then((function(t) {
                                                        t || localStorage.removeItem(e)
                                                    }))
                                                }
                                            }));
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })))
                        }
                    }]), e
                }(),
                _e = function() {
                    function e(t, i) {
                        u(this, e), this.name = t, this.category = i.category, this.name.indexOf("*") >= 0 ? (this.inexact = !0, this._regexp = new RegExp(t.replace("*", ".+"))) : this.inexact = !1
                    }
                    return d(e, [{
                        key: "isMatch",
                        value: function(e) {
                            return this.name === e || this._regexp && this._regexp.test(e)
                        }
                    }]), e
                }(),
                ke = {
                    1: {
                        category: "essential"
                    },
                    placeholder_session_storage_object: {
                        category: "essential"
                    },
                    workbenchState: {
                        category: "functional"
                    },
                    "dashboard.tab-context": {
                        category: "essential"
                    },
                    _ab: {
                        category: "essential"
                    },
                    _mf: {
                        category: "essential"
                    },
                    id: {
                        category: "essential"
                    },
                    "link_app.subscription_card_dismissed": {
                        category: "essential"
                    },
                    "rc::b": {
                        category: "essential"
                    },
                    "rc::c": {
                        category: "essential"
                    },
                    register_login_redesign: {
                        category: "functional"
                    },
                    "glance-cobrowse-storage": {
                        category: "functional"
                    },
                    "stripe-assistant-is-open": {
                        category: "essential"
                    },
                    universal_chat_cta_card_dismissed: {
                        category: "functional"
                    },
                    "dashboard.persisted_flag_overrides": {
                        category: "essential"
                    },
                    "dashboard.persisted_product_availability_override": {
                        category: "essential"
                    },
                    "dashboard.ltm_allowlist_overrides": {
                        category: "essential"
                    }
                },
                Se = Object.keys(ke).reduce((function(e, t) {
                    var i = ke[t];
                    return e[t] = new _e(t, i), e
                }), {}),
                be = Object.keys(Se).filter((function(e) {
                    return Se[e].inexact
                })).map((function(e) {
                    return Se[e]
                })),
                xe = function(e) {
                    if (Se[e]) return Se[e];
                    var t, i = c(be);
                    try {
                        for (i.s(); !(t = i.n()).done;) {
                            var o = t.value;
                            if (o.isMatch(e)) return o
                        }
                    } catch (e) {
                        i.e(e)
                    } finally {
                        i.f()
                    }
                    return null
                },
                Oe = function() {
                    function e() {
                        var i, o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        return u(this, e), i = t.call(this, o), _("sessionStorage") && setTimeout((function() {
                            i.refresh()
                        }), 0), i
                    }
                    o(e, te);
                    var t = n(e);
                    return d(e, [{
                        key: "isStorageAvailable",
                        value: function() {
                            return _("sessionStorage")
                        }
                    }, {
                        key: "get",
                        value: function(e) {
                            return xe(e) || H("No item matching the name ".concat(e, " was found in the sessionStorage.yaml manifest. ") + "Reading the value of the item will work, but attempting to set the item will result in an error. If you're adding a new sessionStorage item, please visit go/cookies for more information!"), _("sessionStorage") ? (this.refresh(), sessionStorage.getItem(e)) : null
                        }
                    }, {
                        key: "set",
                        value: function(e, t) {
                            return v(this, void 0, void 0, l().mark((function i() {
                                var o;
                                return l().wrap((function(i) {
                                    for (;;) switch (i.prev = i.next) {
                                        case 0:
                                            if (o = xe(e)) {
                                                i.next = 4;
                                                break
                                            }
                                            return R("No item matching the name ".concat(e, " was found in the sessionStorage.yaml manifest. ") + "If you're adding a new item, please visit go/cookies for more information!"), i.abrupt("return", !1);
                                        case 4:
                                            return i.next = 6, this.isCategoryAllowed(o.category);
                                        case 6:
                                            if (i.sent) {
                                                i.next = 10;
                                                break
                                            }
                                            return H("Attempting to set sessionStorage ".concat(e, " without the correct permissions. ") + "Please accept cookies and try again."), i.abrupt("return", !1);
                                        case 10:
                                            if (_("sessionStorage")) {
                                                i.next = 12;
                                                break
                                            }
                                            return i.abrupt("return", !1);
                                        case 12:
                                            return sessionStorage.setItem(e, t), i.abrupt("return", !0);
                                        case 14:
                                        case "end":
                                            return i.stop()
                                    }
                                }), i, this)
                            })))
                        }
                    }, {
                        key: "remove",
                        value: function(e) {
                            return xe(e) ? !!_("sessionStorage") && (sessionStorage.removeItem(e), !0) : (R("No item matching the name ".concat(e, " was found in the sessionStorage.yaml manifest. ") + "If you're adding a new item, please visit go/cookies for more information!"), !1)
                        }
                    }, {
                        key: "refresh",
                        value: function() {
                            return v(this, void 0, void 0, l().mark((function e() {
                                var t = this;
                                return l().wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            Object.keys(sessionStorage).forEach((function(e) {
                                                var i = xe(e);
                                                if (i && sessionStorage.getItem(e)) {
                                                    var o = t.isCategoryAllowedMaybeSync(i.category);
                                                    !1 === o && sessionStorage.removeItem(e), o instanceof w && o.then((function(t) {
                                                        t || sessionStorage.removeItem(e)
                                                    }))
                                                }
                                            }));
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })))
                        }
                    }]), e
                }(),
                we = J("/cookie-settings"),
                Le = J("/cookies-policy/legal")
        }
    }
]);