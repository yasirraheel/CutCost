/*! For license information please see vendor-modern.5678c280.js.LICENSE.txt */
(globalThis.webpackChunkintercom_js = globalThis.webpackChunkintercom_js || []).push([
    [4121], {
        97160: function(e) {
            e.exports = function() {
                "use strict";

                function e(e, t) {
                    (null == t || t > e.length) && (t = e.length);
                    for (var r = 0, n = Array(t); r < t; r++) n[r] = e[r];
                    return n
                }

                function t(t) {
                    if (Array.isArray(t)) return e(t)
                }

                function r(e, t, r) {
                    return (t = l(t)) in e ? Object.defineProperty(e, t, {
                        value: r,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[t] = r, e
                }

                function n(e) {
                    if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
                }

                function o() {
                    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }

                function i(e, t) {
                    var r = Object.keys(e);
                    if (Object.getOwnPropertySymbols) {
                        var n = Object.getOwnPropertySymbols(e);
                        t && (n = n.filter((function(t) {
                            return Object.getOwnPropertyDescriptor(e, t).enumerable
                        }))), r.push.apply(r, n)
                    }
                    return r
                }

                function a(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? i(Object(n), !0).forEach((function(t) {
                            r(e, t, n[t])
                        })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach((function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                        }))
                    }
                    return e
                }

                function s(e) {
                    return t(e) || n(e) || u(e) || o()
                }

                function c(e, t) {
                    if ("object" != typeof e || !e) return e;
                    var r = e[Symbol.toPrimitive];
                    if (void 0 !== r) {
                        var n = r.call(e, t);
                        if ("object" != typeof n) return n;
                        throw new TypeError("@@toPrimitive must return a primitive value.")
                    }
                    return ("string" === t ? String : Number)(e)
                }

                function l(e) {
                    var t = c(e, "string");
                    return "symbol" == typeof t ? t : t + ""
                }

                function u(t, r) {
                    if (t) {
                        if ("string" == typeof t) return e(t, r);
                        var n = {}.toString.call(t).slice(8, -1);
                        return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? e(t, r) : void 0
                    }
                }

                function _(e, t) {
                    return e(t = {
                        exports: {}
                    }, t.exports), t.exports
                }
                var d = _((function(e) {
                        ! function(t) {
                            var r = /^\s+/,
                                n = /\s+$/,
                                o = 0,
                                i = t.round,
                                a = t.min,
                                s = t.max,
                                c = t.random;

                            function l(e, t) {
                                if (t = t || {}, (e = e || "") instanceof l) return e;
                                if (!(this instanceof l)) return new l(e, t);
                                var r = u(e);
                                this._originalInput = e, this._r = r.r, this._g = r.g, this._b = r.b, this._a = r.a, this._roundA = i(100 * this._a) / 100, this._format = t.format || r.format, this._gradientType = t.gradientType, this._r < 1 && (this._r = i(this._r)), this._g < 1 && (this._g = i(this._g)), this._b < 1 && (this._b = i(this._b)), this._ok = r.ok, this._tc_id = o++
                            }

                            function u(e) {
                                var t = {
                                        r: 0,
                                        g: 0,
                                        b: 0
                                    },
                                    r = 1,
                                    n = null,
                                    o = null,
                                    i = null,
                                    c = !1,
                                    l = !1;
                                return "string" == typeof e && (e = K(e)), "object" == typeof e && (X(e.r) && X(e.g) && X(e.b) ? (t = _(e.r, e.g, e.b), c = !0, l = "%" === String(e.r).substr(-1) ? "prgb" : "rgb") : X(e.h) && X(e.s) && X(e.v) ? (n = H(e.s), o = H(e.v), t = h(e.h, n, o), c = !0, l = "hsv") : X(e.h) && X(e.s) && X(e.l) && (n = H(e.s), i = H(e.l), t = p(e.h, n, i), c = !0, l = "hsl"), e.hasOwnProperty("a") && (r = e.a)), r = F(r), {
                                    ok: c,
                                    format: e.format || l,
                                    r: a(255, s(t.r, 0)),
                                    g: a(255, s(t.g, 0)),
                                    b: a(255, s(t.b, 0)),
                                    a: r
                                }
                            }

                            function _(e, t, r) {
                                return {
                                    r: 255 * D(e, 255),
                                    g: 255 * D(t, 255),
                                    b: 255 * D(r, 255)
                                }
                            }

                            function d(e, t, r) {
                                e = D(e, 255), t = D(t, 255), r = D(r, 255);
                                var n, o, i = s(e, t, r),
                                    c = a(e, t, r),
                                    l = (i + c) / 2;
                                if (i == c) n = o = 0;
                                else {
                                    var u = i - c;
                                    switch (o = l > .5 ? u / (2 - i - c) : u / (i + c), i) {
                                        case e:
                                            n = (t - r) / u + (t < r ? 6 : 0);
                                            break;
                                        case t:
                                            n = (r - e) / u + 2;
                                            break;
                                        case r:
                                            n = (e - t) / u + 4
                                    }
                                    n /= 6
                                }
                                return {
                                    h: n,
                                    s: o,
                                    l: l
                                }
                            }

                            function p(e, t, r) {
                                var n, o, i;

                                function a(e, t, r) {
                                    return r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6 ? e + 6 * (t - e) * r : r < .5 ? t : r < 2 / 3 ? e + (t - e) * (2 / 3 - r) * 6 : e
                                }
                                if (e = D(e, 360), t = D(t, 100), r = D(r, 100), 0 === t) n = o = i = r;
                                else {
                                    var s = r < .5 ? r * (1 + t) : r + t - r * t,
                                        c = 2 * r - s;
                                    n = a(c, s, e + 1 / 3), o = a(c, s, e), i = a(c, s, e - 1 / 3)
                                }
                                return {
                                    r: 255 * n,
                                    g: 255 * o,
                                    b: 255 * i
                                }
                            }

                            function f(e, t, r) {
                                e = D(e, 255), t = D(t, 255), r = D(r, 255);
                                var n, o, i = s(e, t, r),
                                    c = a(e, t, r),
                                    l = i,
                                    u = i - c;
                                if (o = 0 === i ? 0 : u / i, i == c) n = 0;
                                else {
                                    switch (i) {
                                        case e:
                                            n = (t - r) / u + (t < r ? 6 : 0);
                                            break;
                                        case t:
                                            n = (r - e) / u + 2;
                                            break;
                                        case r:
                                            n = (e - t) / u + 4
                                    }
                                    n /= 6
                                }
                                return {
                                    h: n,
                                    s: o,
                                    v: l
                                }
                            }

                            function h(e, r, n) {
                                e = 6 * D(e, 360), r = D(r, 100), n = D(n, 100);
                                var o = t.floor(e),
                                    i = e - o,
                                    a = n * (1 - r),
                                    s = n * (1 - i * r),
                                    c = n * (1 - (1 - i) * r),
                                    l = o % 6;
                                return {
                                    r: 255 * [n, s, a, a, c, n][l],
                                    g: 255 * [c, n, n, s, a, a][l],
                                    b: 255 * [a, a, c, n, n, s][l]
                                }
                            }

                            function m(e, t, r, n) {
                                var o = [U(i(e).toString(16)), U(i(t).toString(16)), U(i(r).toString(16))];
                                return n && o[0].charAt(0) == o[0].charAt(1) && o[1].charAt(0) == o[1].charAt(1) && o[2].charAt(0) == o[2].charAt(1) ? o[0].charAt(0) + o[1].charAt(0) + o[2].charAt(0) : o.join("")
                            }

                            function y(e, t, r, n, o) {
                                var a = [U(i(e).toString(16)), U(i(t).toString(16)), U(i(r).toString(16)), U(q(n))];
                                return o && a[0].charAt(0) == a[0].charAt(1) && a[1].charAt(0) == a[1].charAt(1) && a[2].charAt(0) == a[2].charAt(1) && a[3].charAt(0) == a[3].charAt(1) ? a[0].charAt(0) + a[1].charAt(0) + a[2].charAt(0) + a[3].charAt(0) : a.join("")
                            }

                            function g(e, t, r, n) {
                                return [U(q(n)), U(i(e).toString(16)), U(i(t).toString(16)), U(i(r).toString(16))].join("")
                            }

                            function v(e, t) {
                                t = 0 === t ? 0 : t || 10;
                                var r = l(e).toHsl();
                                return r.s -= t / 100, r.s = j(r.s), l(r)
                            }

                            function b(e, t) {
                                t = 0 === t ? 0 : t || 10;
                                var r = l(e).toHsl();
                                return r.s += t / 100, r.s = j(r.s), l(r)
                            }

                            function w(e) {
                                return l(e).desaturate(100)
                            }

                            function k(e, t) {
                                t = 0 === t ? 0 : t || 10;
                                var r = l(e).toHsl();
                                return r.l += t / 100, r.l = j(r.l), l(r)
                            }

                            function S(e, t) {
                                t = 0 === t ? 0 : t || 10;
                                var r = l(e).toRgb();
                                return r.r = s(0, a(255, r.r - i(-t / 100 * 255))), r.g = s(0, a(255, r.g - i(-t / 100 * 255))), r.b = s(0, a(255, r.b - i(-t / 100 * 255))), l(r)
                            }

                            function x(e, t) {
                                t = 0 === t ? 0 : t || 10;
                                var r = l(e).toHsl();
                                return r.l -= t / 100, r.l = j(r.l), l(r)
                            }

                            function C(e, t) {
                                var r = l(e).toHsl(),
                                    n = (r.h + t) % 360;
                                return r.h = n < 0 ? 360 + n : n, l(r)
                            }

                            function E(e) {
                                var t = l(e).toHsl();
                                return t.h = (t.h + 180) % 360, l(t)
                            }

                            function T(e) {
                                var t = l(e).toHsl(),
                                    r = t.h;
                                return [l(e), l({
                                    h: (r + 120) % 360,
                                    s: t.s,
                                    l: t.l
                                }), l({
                                    h: (r + 240) % 360,
                                    s: t.s,
                                    l: t.l
                                })]
                            }

                            function A(e) {
                                var t = l(e).toHsl(),
                                    r = t.h;
                                return [l(e), l({
                                    h: (r + 90) % 360,
                                    s: t.s,
                                    l: t.l
                                }), l({
                                    h: (r + 180) % 360,
                                    s: t.s,
                                    l: t.l
                                }), l({
                                    h: (r + 270) % 360,
                                    s: t.s,
                                    l: t.l
                                })]
                            }

                            function R(e) {
                                var t = l(e).toHsl(),
                                    r = t.h;
                                return [l(e), l({
                                    h: (r + 72) % 360,
                                    s: t.s,
                                    l: t.l
                                }), l({
                                    h: (r + 216) % 360,
                                    s: t.s,
                                    l: t.l
                                })]
                            }

                            function O(e, t, r) {
                                t = t || 6, r = r || 30;
                                var n = l(e).toHsl(),
                                    o = 360 / r,
                                    i = [l(e)];
                                for (n.h = (n.h - (o * t >> 1) + 720) % 360; --t;) n.h = (n.h + o) % 360, i.push(l(n));
                                return i
                            }

                            function P(e, t) {
                                t = t || 6;
                                for (var r = l(e).toHsv(), n = r.h, o = r.s, i = r.v, a = [], s = 1 / t; t--;) a.push(l({
                                    h: n,
                                    s: o,
                                    v: i
                                })), i = (i + s) % 1;
                                return a
                            }
                            l.prototype = {
                                isDark: function() {
                                    return this.getBrightness() < 128
                                },
                                isLight: function() {
                                    return !this.isDark()
                                },
                                isValid: function() {
                                    return this._ok
                                },
                                getOriginalInput: function() {
                                    return this._originalInput
                                },
                                getFormat: function() {
                                    return this._format
                                },
                                getAlpha: function() {
                                    return this._a
                                },
                                getBrightness: function() {
                                    var e = this.toRgb();
                                    return (299 * e.r + 587 * e.g + 114 * e.b) / 1e3
                                },
                                getLuminance: function() {
                                    var e, r, n, o = this.toRgb();
                                    return e = o.r / 255, r = o.g / 255, n = o.b / 255, .2126 * (e <= .03928 ? e / 12.92 : t.pow((e + .055) / 1.055, 2.4)) + .7152 * (r <= .03928 ? r / 12.92 : t.pow((r + .055) / 1.055, 2.4)) + .0722 * (n <= .03928 ? n / 12.92 : t.pow((n + .055) / 1.055, 2.4))
                                },
                                setAlpha: function(e) {
                                    return this._a = F(e), this._roundA = i(100 * this._a) / 100, this
                                },
                                toHsv: function() {
                                    var e = f(this._r, this._g, this._b);
                                    return {
                                        h: 360 * e.h,
                                        s: e.s,
                                        v: e.v,
                                        a: this._a
                                    }
                                },
                                toHsvString: function() {
                                    var e = f(this._r, this._g, this._b),
                                        t = i(360 * e.h),
                                        r = i(100 * e.s),
                                        n = i(100 * e.v);
                                    return 1 == this._a ? "hsv(" + t + ", " + r + "%, " + n + "%)" : "hsva(" + t + ", " + r + "%, " + n + "%, " + this._roundA + ")"
                                },
                                toHsl: function() {
                                    var e = d(this._r, this._g, this._b);
                                    return {
                                        h: 360 * e.h,
                                        s: e.s,
                                        l: e.l,
                                        a: this._a
                                    }
                                },
                                toHslString: function() {
                                    var e = d(this._r, this._g, this._b),
                                        t = i(360 * e.h),
                                        r = i(100 * e.s),
                                        n = i(100 * e.l);
                                    return 1 == this._a ? "hsl(" + t + ", " + r + "%, " + n + "%)" : "hsla(" + t + ", " + r + "%, " + n + "%, " + this._roundA + ")"
                                },
                                toHex: function(e) {
                                    return m(this._r, this._g, this._b, e)
                                },
                                toHexString: function(e) {
                                    return "#" + this.toHex(e)
                                },
                                toHex8: function(e) {
                                    return y(this._r, this._g, this._b, this._a, e)
                                },
                                toHex8String: function(e) {
                                    return "#" + this.toHex8(e)
                                },
                                toRgb: function() {
                                    return {
                                        r: i(this._r),
                                        g: i(this._g),
                                        b: i(this._b),
                                        a: this._a
                                    }
                                },
                                toRgbString: function() {
                                    return 1 == this._a ? "rgb(" + i(this._r) + ", " + i(this._g) + ", " + i(this._b) + ")" : "rgba(" + i(this._r) + ", " + i(this._g) + ", " + i(this._b) + ", " + this._roundA + ")"
                                },
                                toPercentageRgb: function() {
                                    return {
                                        r: i(100 * D(this._r, 255)) + "%",
                                        g: i(100 * D(this._g, 255)) + "%",
                                        b: i(100 * D(this._b, 255)) + "%",
                                        a: this._a
                                    }
                                },
                                toPercentageRgbString: function() {
                                    return 1 == this._a ? "rgb(" + i(100 * D(this._r, 255)) + "%, " + i(100 * D(this._g, 255)) + "%, " + i(100 * D(this._b, 255)) + "%)" : "rgba(" + i(100 * D(this._r, 255)) + "%, " + i(100 * D(this._g, 255)) + "%, " + i(100 * D(this._b, 255)) + "%, " + this._roundA + ")"
                                },
                                toName: function() {
                                    return 0 === this._a ? "transparent" : !(this._a < 1) && (I[m(this._r, this._g, this._b, !0)] || !1)
                                },
                                toFilter: function(e) {
                                    var t = "#" + g(this._r, this._g, this._b, this._a),
                                        r = t,
                                        n = this._gradientType ? "GradientType = 1, " : "";
                                    if (e) {
                                        var o = l(e);
                                        r = "#" + g(o._r, o._g, o._b, o._a)
                                    }
                                    return "progid:DXImageTransform.Microsoft.gradient(" + n + "startColorstr=" + t + ",endColorstr=" + r + ")"
                                },
                                toString: function(e) {
                                    var t = !!e;
                                    e = e || this._format;
                                    var r = !1,
                                        n = this._a < 1 && this._a >= 0;
                                    return t || !n || "hex" !== e && "hex6" !== e && "hex3" !== e && "hex4" !== e && "hex8" !== e && "name" !== e ? ("rgb" === e && (r = this.toRgbString()), "prgb" === e && (r = this.toPercentageRgbString()), "hex" !== e && "hex6" !== e || (r = this.toHexString()), "hex3" === e && (r = this.toHexString(!0)), "hex4" === e && (r = this.toHex8String(!0)), "hex8" === e && (r = this.toHex8String()), "name" === e && (r = this.toName()), "hsl" === e && (r = this.toHslString()), "hsv" === e && (r = this.toHsvString()), r || this.toHexString()) : "name" === e && 0 === this._a ? this.toName() : this.toRgbString()
                                },
                                clone: function() {
                                    return l(this.toString())
                                },
                                _applyModification: function(e, t) {
                                    var r = e.apply(null, [this].concat([].slice.call(t)));
                                    return this._r = r._r, this._g = r._g, this._b = r._b, this.setAlpha(r._a), this
                                },
                                lighten: function() {
                                    return this._applyModification(k, arguments)
                                },
                                brighten: function() {
                                    return this._applyModification(S, arguments)
                                },
                                darken: function() {
                                    return this._applyModification(x, arguments)
                                },
                                desaturate: function() {
                                    return this._applyModification(v, arguments)
                                },
                                saturate: function() {
                                    return this._applyModification(b, arguments)
                                },
                                greyscale: function() {
                                    return this._applyModification(w, arguments)
                                },
                                spin: function() {
                                    return this._applyModification(C, arguments)
                                },
                                _applyCombination: function(e, t) {
                                    return e.apply(null, [this].concat([].slice.call(t)))
                                },
                                analogous: function() {
                                    return this._applyCombination(O, arguments)
                                },
                                complement: function() {
                                    return this._applyCombination(E, arguments)
                                },
                                monochromatic: function() {
                                    return this._applyCombination(P, arguments)
                                },
                                splitcomplement: function() {
                                    return this._applyCombination(R, arguments)
                                },
                                triad: function() {
                                    return this._applyCombination(T, arguments)
                                },
                                tetrad: function() {
                                    return this._applyCombination(A, arguments)
                                }
                            }, l.fromRatio = function(e, t) {
                                if ("object" == typeof e) {
                                    var r = {};
                                    for (var n in e) e.hasOwnProperty(n) && (r[n] = "a" === n ? e[n] : H(e[n]));
                                    e = r
                                }
                                return l(e, t)
                            }, l.equals = function(e, t) {
                                return !(!e || !t) && l(e).toRgbString() == l(t).toRgbString()
                            }, l.random = function() {
                                return l.fromRatio({
                                    r: c(),
                                    g: c(),
                                    b: c()
                                })
                            }, l.mix = function(e, t, r) {
                                r = 0 === r ? 0 : r || 50;
                                var n = l(e).toRgb(),
                                    o = l(t).toRgb(),
                                    i = r / 100;
                                return l({
                                    r: (o.r - n.r) * i + n.r,
                                    g: (o.g - n.g) * i + n.g,
                                    b: (o.b - n.b) * i + n.b,
                                    a: (o.a - n.a) * i + n.a
                                })
                            }, l.readability = function(e, r) {
                                var n = l(e),
                                    o = l(r);
                                return (t.max(n.getLuminance(), o.getLuminance()) + .05) / (t.min(n.getLuminance(), o.getLuminance()) + .05)
                            }, l.isReadable = function(e, t, r) {
                                var n, o, i = l.readability(e, t);
                                switch (o = !1, (n = J(r)).level + n.size) {
                                    case "AAsmall":
                                    case "AAAlarge":
                                        o = i >= 4.5;
                                        break;
                                    case "AAlarge":
                                        o = i >= 3;
                                        break;
                                    case "AAAsmall":
                                        o = i >= 7
                                }
                                return o
                            }, l.mostReadable = function(e, t, r) {
                                var n, o, i, a, s = null,
                                    c = 0;
                                o = (r = r || {}).includeFallbackColors, i = r.level, a = r.size;
                                for (var u = 0; u < t.length; u++)(n = l.readability(e, t[u])) > c && (c = n, s = l(t[u]));
                                return l.isReadable(e, s, {
                                    level: i,
                                    size: a
                                }) || !o ? s : (r.includeFallbackColors = !1, l.mostReadable(e, ["#fff", "#000"], r))
                            };
                            var M = l.names = {
                                    aliceblue: "f0f8ff",
                                    antiquewhite: "faebd7",
                                    aqua: "0ff",
                                    aquamarine: "7fffd4",
                                    azure: "f0ffff",
                                    beige: "f5f5dc",
                                    bisque: "ffe4c4",
                                    black: "000",
                                    blanchedalmond: "ffebcd",
                                    blue: "00f",
                                    blueviolet: "8a2be2",
                                    brown: "a52a2a",
                                    burlywood: "deb887",
                                    burntsienna: "ea7e5d",
                                    cadetblue: "5f9ea0",
                                    chartreuse: "7fff00",
                                    chocolate: "d2691e",
                                    coral: "ff7f50",
                                    cornflowerblue: "6495ed",
                                    cornsilk: "fff8dc",
                                    crimson: "dc143c",
                                    cyan: "0ff",
                                    darkblue: "00008b",
                                    darkcyan: "008b8b",
                                    darkgoldenrod: "b8860b",
                                    darkgray: "a9a9a9",
                                    darkgreen: "006400",
                                    darkgrey: "a9a9a9",
                                    darkkhaki: "bdb76b",
                                    darkmagenta: "8b008b",
                                    darkolivegreen: "556b2f",
                                    darkorange: "ff8c00",
                                    darkorchid: "9932cc",
                                    darkred: "8b0000",
                                    darksalmon: "e9967a",
                                    darkseagreen: "8fbc8f",
                                    darkslateblue: "483d8b",
                                    darkslategray: "2f4f4f",
                                    darkslategrey: "2f4f4f",
                                    darkturquoise: "00ced1",
                                    darkviolet: "9400d3",
                                    deeppink: "ff1493",
                                    deepskyblue: "00bfff",
                                    dimgray: "696969",
                                    dimgrey: "696969",
                                    dodgerblue: "1e90ff",
                                    firebrick: "b22222",
                                    floralwhite: "fffaf0",
                                    forestgreen: "228b22",
                                    fuchsia: "f0f",
                                    gainsboro: "dcdcdc",
                                    ghostwhite: "f8f8ff",
                                    gold: "ffd700",
                                    goldenrod: "daa520",
                                    gray: "808080",
                                    green: "008000",
                                    greenyellow: "adff2f",
                                    grey: "808080",
                                    honeydew: "f0fff0",
                                    hotpink: "ff69b4",
                                    indianred: "cd5c5c",
                                    indigo: "4b0082",
                                    ivory: "fffff0",
                                    khaki: "f0e68c",
                                    lavender: "e6e6fa",
                                    lavenderblush: "fff0f5",
                                    lawngreen: "7cfc00",
                                    lemonchiffon: "fffacd",
                                    lightblue: "add8e6",
                                    lightcoral: "f08080",
                                    lightcyan: "e0ffff",
                                    lightgoldenrodyellow: "fafad2",
                                    lightgray: "d3d3d3",
                                    lightgreen: "90ee90",
                                    lightgrey: "d3d3d3",
                                    lightpink: "ffb6c1",
                                    lightsalmon: "ffa07a",
                                    lightseagreen: "20b2aa",
                                    lightskyblue: "87cefa",
                                    lightslategray: "789",
                                    lightslategrey: "789",
                                    lightsteelblue: "b0c4de",
                                    lightyellow: "ffffe0",
                                    lime: "0f0",
                                    limegreen: "32cd32",
                                    linen: "faf0e6",
                                    magenta: "f0f",
                                    maroon: "800000",
                                    mediumaquamarine: "66cdaa",
                                    mediumblue: "0000cd",
                                    mediumorchid: "ba55d3",
                                    mediumpurple: "9370db",
                                    mediumseagreen: "3cb371",
                                    mediumslateblue: "7b68ee",
                                    mediumspringgreen: "00fa9a",
                                    mediumturquoise: "48d1cc",
                                    mediumvioletred: "c71585",
                                    midnightblue: "191970",
                                    mintcream: "f5fffa",
                                    mistyrose: "ffe4e1",
                                    moccasin: "ffe4b5",
                                    navajowhite: "ffdead",
                                    navy: "000080",
                                    oldlace: "fdf5e6",
                                    olive: "808000",
                                    olivedrab: "6b8e23",
                                    orange: "ffa500",
                                    orangered: "ff4500",
                                    orchid: "da70d6",
                                    palegoldenrod: "eee8aa",
                                    palegreen: "98fb98",
                                    paleturquoise: "afeeee",
                                    palevioletred: "db7093",
                                    papayawhip: "ffefd5",
                                    peachpuff: "ffdab9",
                                    peru: "cd853f",
                                    pink: "ffc0cb",
                                    plum: "dda0dd",
                                    powderblue: "b0e0e6",
                                    purple: "800080",
                                    rebeccapurple: "663399",
                                    red: "f00",
                                    rosybrown: "bc8f8f",
                                    royalblue: "4169e1",
                                    saddlebrown: "8b4513",
                                    salmon: "fa8072",
                                    sandybrown: "f4a460",
                                    seagreen: "2e8b57",
                                    seashell: "fff5ee",
                                    sienna: "a0522d",
                                    silver: "c0c0c0",
                                    skyblue: "87ceeb",
                                    slateblue: "6a5acd",
                                    slategray: "708090",
                                    slategrey: "708090",
                                    snow: "fffafa",
                                    springgreen: "00ff7f",
                                    steelblue: "4682b4",
                                    tan: "d2b48c",
                                    teal: "008080",
                                    thistle: "d8bfd8",
                                    tomato: "ff6347",
                                    turquoise: "40e0d0",
                                    violet: "ee82ee",
                                    wheat: "f5deb3",
                                    white: "fff",
                                    whitesmoke: "f5f5f5",
                                    yellow: "ff0",
                                    yellowgreen: "9acd32"
                                },
                                I = l.hexNames = N(M);

                            function N(e) {
                                var t = {};
                                for (var r in e) e.hasOwnProperty(r) && (t[e[r]] = r);
                                return t
                            }

                            function F(e) {
                                return e = parseFloat(e), (isNaN(e) || e < 0 || e > 1) && (e = 1), e
                            }

                            function D(e, r) {
                                W(e) && (e = "100%");
                                var n = z(e);
                                return e = a(r, s(0, parseFloat(e))), n && (e = parseInt(e * r, 10) / 100), t.abs(e - r) < 1e-6 ? 1 : e % r / parseFloat(r)
                            }

                            function j(e) {
                                return a(1, s(0, e))
                            }

                            function L(e) {
                                return parseInt(e, 16)
                            }

                            function W(e) {
                                return "string" == typeof e && -1 != e.indexOf(".") && 1 === parseFloat(e)
                            }

                            function z(e) {
                                return "string" == typeof e && -1 != e.indexOf("%")
                            }

                            function U(e) {
                                return 1 == e.length ? "0" + e : "" + e
                            }

                            function H(e) {
                                return e <= 1 && (e = 100 * e + "%"), e
                            }

                            function q(e) {
                                return t.round(255 * parseFloat(e)).toString(16)
                            }

                            function B(e) {
                                return L(e) / 255
                            }
                            var $, G, V, Y = (G = "[\\s|\\(]+(" + ($ = "(?:[-\\+]?\\d*\\.\\d+%?)|(?:[-\\+]?\\d+%?)") + ")[,|\\s]+(" + $ + ")[,|\\s]+(" + $ + ")\\s*\\)?", V = "[\\s|\\(]+(" + $ + ")[,|\\s]+(" + $ + ")[,|\\s]+(" + $ + ")[,|\\s]+(" + $ + ")\\s*\\)?", {
                                CSS_UNIT: new RegExp($),
                                rgb: new RegExp("rgb" + G),
                                rgba: new RegExp("rgba" + V),
                                hsl: new RegExp("hsl" + G),
                                hsla: new RegExp("hsla" + V),
                                hsv: new RegExp("hsv" + G),
                                hsva: new RegExp("hsva" + V),
                                hex3: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
                                hex6: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
                                hex4: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
                                hex8: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/
                            });

                            function X(e) {
                                return !!Y.CSS_UNIT.exec(e)
                            }

                            function K(e) {
                                e = e.replace(r, "").replace(n, "").toLowerCase();
                                var t, o = !1;
                                if (M[e]) e = M[e], o = !0;
                                else if ("transparent" == e) return {
                                    r: 0,
                                    g: 0,
                                    b: 0,
                                    a: 0,
                                    format: "name"
                                };
                                return (t = Y.rgb.exec(e)) ? {
                                    r: t[1],
                                    g: t[2],
                                    b: t[3]
                                } : (t = Y.rgba.exec(e)) ? {
                                    r: t[1],
                                    g: t[2],
                                    b: t[3],
                                    a: t[4]
                                } : (t = Y.hsl.exec(e)) ? {
                                    h: t[1],
                                    s: t[2],
                                    l: t[3]
                                } : (t = Y.hsla.exec(e)) ? {
                                    h: t[1],
                                    s: t[2],
                                    l: t[3],
                                    a: t[4]
                                } : (t = Y.hsv.exec(e)) ? {
                                    h: t[1],
                                    s: t[2],
                                    v: t[3]
                                } : (t = Y.hsva.exec(e)) ? {
                                    h: t[1],
                                    s: t[2],
                                    v: t[3],
                                    a: t[4]
                                } : (t = Y.hex8.exec(e)) ? {
                                    r: L(t[1]),
                                    g: L(t[2]),
                                    b: L(t[3]),
                                    a: B(t[4]),
                                    format: o ? "name" : "hex8"
                                } : (t = Y.hex6.exec(e)) ? {
                                    r: L(t[1]),
                                    g: L(t[2]),
                                    b: L(t[3]),
                                    format: o ? "name" : "hex"
                                } : (t = Y.hex4.exec(e)) ? {
                                    r: L(t[1] + "" + t[1]),
                                    g: L(t[2] + "" + t[2]),
                                    b: L(t[3] + "" + t[3]),
                                    a: B(t[4] + "" + t[4]),
                                    format: o ? "name" : "hex8"
                                } : !!(t = Y.hex3.exec(e)) && {
                                    r: L(t[1] + "" + t[1]),
                                    g: L(t[2] + "" + t[2]),
                                    b: L(t[3] + "" + t[3]),
                                    format: o ? "name" : "hex"
                                }
                            }

                            function J(e) {
                                var t, r;
                                return "AA" !== (t = ((e = e || {
                                    level: "AA",
                                    size: "small"
                                }).level || "AA").toUpperCase()) && "AAA" !== t && (t = "AA"), "small" !== (r = (e.size || "small").toLowerCase()) && "large" !== r && (r = "small"), {
                                    level: t,
                                    size: r
                                }
                            }
                            e.exports ? e.exports = l : window.tinycolor = l
                        }(Math)
                    })),
                    p = d("#14161a").setAlpha(.5).toRgbString(),
                    f = d("#14161a").toRgbString(),
                    h = 10,
                    m = .6,
                    y = 21.5,
                    g = 3,
                    v = 3,
                    b = 4.5,
                    w = 2,
                    k = {
                        light: {
                            background: d("#ffffff").toRgbString(),
                            foreground: d("#14161a").toRgbString(),
                            default_large_content_text: d("#14161a").setAlpha(.7).toRgbString(),
                            fallback_large_content_text: d("#FFFFFF").setAlpha(.7).toRgbString(),
                            primary_button_text: d("#14161a").setAlpha(.5).toRgbString(),
                            background_hover: d("#1a1a1a").toRgbString(),
                            background_active: d("#333333").toRgbString()
                        },
                        dark: {
                            background: d("#14161a").toRgbString(),
                            foreground: d("#f7f7f7").toRgbString(),
                            default_large_content_text: d("#f7f7f7").setAlpha(.4).toRgbString(),
                            fallback_large_content_text: d("#14161a").setAlpha(.4).toRgbString(),
                            primary_button_text: d("#f7f7f7").toRgbString(),
                            background_hover: d("#f7f7f7").toRgbString(),
                            background_active: d("#f7f7f7").toRgbString()
                        }
                    };

                function S(e, t, r) {
                    return d.readability(e, t) >= 4.5 ? t : r
                }

                function x(e) {
                    var t = d(e).toHsl(),
                        r = k.light.background,
                        n = d({
                            h: t.h,
                            s: t.s,
                            l: 85
                        }).toRgbString();
                    return E(n, e, g) || (n = k.light.background), {
                        greeting_text_color: n,
                        introduction_text_color: r,
                        secondary_type: "dark"
                    }
                }

                function C(e) {
                    var t = d(e).toHsl(),
                        r = k.light.foreground,
                        n = d({
                            h: t.h,
                            s: 5,
                            l: 50
                        }).toRgbString();
                    return E(n, e, g) || (n = k.light.foreground), {
                        greeting_text_color: n,
                        introduction_text_color: r,
                        secondary_type: "light"
                    }
                }

                function E(e, t) {
                    var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : v;
                    return d.readability(t, e) >= r
                }

                function T(e, t) {
                    var r = k[t].background;
                    if (E(e, r, w)) return null;
                    for (var n = "light" === t, o = d(e), i = 5; i <= 60; i += 5) {
                        var a = n ? o.clone().darken(i) : o.clone().lighten(i);
                        if (E(a.toRgbString(), r, w)) return a
                    }
                    return d(n ? k.light.foreground : k.light.background)
                }

                function A(e, t) {
                    return E(e, t, w) ? e : d.readability(t, "#ffffff") > d.readability(t, "#000000") ? k.light.background : k.light.foreground
                }

                function R(e) {
                    var t = d(e).toHsl().l,
                        r = 100 * (.95 - t),
                        n = d(e).lighten(r).toRgbString(),
                        o = 100 * (t - .85),
                        i = d(e).darken(o).toRgbString(),
                        a = 100 * (t - .3),
                        s = d(e).darken(a).toRgbString(),
                        c = 100 * (t - .25),
                        l = d(e).darken(c).toRgbString();
                    return t < .35 ? {
                        light: n,
                        dark: e
                    } : t > .9 ? {
                        light: i,
                        dark: S(i, s, l)
                    } : {
                        light: n,
                        dark: S(n, s, l)
                    }
                }

                function O(e) {
                    var t = d(e).toHsl().l,
                        r = 120 * (.85 - t),
                        n = d(e).lighten(r).toRgbString(),
                        o = 80 * (t - .75),
                        i = d(e).darken(o).toRgbString(),
                        a = 90 * (t - .4),
                        s = d(e).darken(a).toRgbString(),
                        c = 95 * (t - .35),
                        l = d(e).darken(c).toRgbString();
                    return t < .25 ? {
                        light: n,
                        dark: e
                    } : t > .8 ? {
                        light: e,
                        dark: S(n, s, l)
                    } : {
                        light: n,
                        dark: S(n, i, s)
                    }
                }

                function P(e, t, r, n, o) {
                    var i = arguments.length > 5 && void 0 !== arguments[5] && arguments[5],
                        s = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : "light";
                    this.primary = e.toRgbString(), this.secondary = t.toRgbString(), this.primaryVariant = r.toRgbString(), this.secondaryVariant = n.toRgbString(), this.gradientEnd = o.toRgbString();
                    var c = e.getLuminance() < .2 ? "lighten" : "darken",
                        l = e.clone(),
                        u = e.clone();
                    this.primaryHover = l[c](10).toRgbString(), this.primaryActive = u[c](20).toRgbString();
                    var _ = "light" === s,
                        h = _ ? R(this.primary) : O(this.primary),
                        m = T(this.primary, s),
                        g = m ? m.toRgbString() : this.primary,
                        v = this.primaryHover,
                        b = this.primaryActive;
                    if (m) {
                        var w = m.getLuminance() < .2 ? "lighten" : "darken";
                        v = m.clone()[w](10).toRgbString(), b = m.clone()[w](20).toRgbString()
                    }
                    var S = {
                        gradient_start_color: this.secondary,
                        gradient_end_color: this.gradientEnd,
                        card_border_top_color: this.primaryVariant,
                        button_background_color: g,
                        button_background_color_hover: v,
                        button_background_color_active: b,
                        primary_on_white_contrast: Math.round(1e3 * d.readability(k[s].background, this.primary)) / 1e3,
                        secondary_on_white_contrast: Math.round(1e3 * d.readability(k[s].background, this.secondary)) / 1e3,
                        quick_reply_text_color: _ ? h.dark : h.light,
                        quick_reply_background_color: _ ? h.light : h.dark,
                        avatar_background_color: d(this.primary).darken(y).toRgbString()
                    };
                    this.generateLightPrimaryLightSecondary = function() {
                        return a(a(a({}, S), C(this.secondary)), {}, {
                            header_title_color: k[s].foreground,
                            header_text_color: k[s].default_large_content_text,
                            launcher_icon_color: i ? f : p,
                            button_text_color: A(i ? f : p, S.button_background_color),
                            link_color: _ ? k[s].foreground : this.primary,
                            link_color_hover: _ ? k[s].background_hover : this.primaryHover,
                            link_color_active: _ ? k[s].background_active : this.primaryActive,
                            primary_type: "light",
                            secondary_type: "light"
                        })
                    }, this.generateLightPrimaryDarkSecondary = function() {
                        return a(a(a({}, S), x(this.secondary)), {}, {
                            header_title_color: k[s].background,
                            header_text_color: k[s].fallback_large_content_text,
                            launcher_icon_color: i ? f : k[s].primary_button_text,
                            button_text_color: A(i ? f : k[s].primary_button_text, S.button_background_color),
                            link_color: _ ? k[s].foreground : this.primary,
                            link_color_hover: _ ? k[s].background_hover : this.primaryHover,
                            link_color_active: _ ? k[s].background_active : this.primaryActive,
                            primary_type: "light",
                            secondary_type: "dark"
                        })
                    }, this.generateDarkPrimaryLightSecondary = function() {
                        return a(a(a({}, S), C(this.secondary)), {}, {
                            header_title_color: k[s].foreground,
                            header_text_color: k[s].default_large_content_text,
                            launcher_icon_color: _ ? k[s].background : k[s].foreground,
                            button_text_color: A(_ ? k[s].background : k[s].foreground, S.button_background_color),
                            link_color: _ ? this.primary : k[s].foreground,
                            link_color_hover: _ ? this.primaryHover : k[s].background_hover,
                            link_color_active: _ ? this.primaryActive : k[s].background_active,
                            primary_type: "dark",
                            secondary_type: "light"
                        })
                    }, this.generateDarkPrimaryDarkSecondary = function() {
                        return a(a(a({}, S), x(this.secondary)), {}, {
                            header_title_color: k[s].background,
                            header_text_color: k[s].fallback_large_content_text,
                            launcher_icon_color: _ ? k[s].background : k[s].foreground,
                            button_text_color: A(_ ? k[s].background : k[s].foreground, S.button_background_color),
                            link_color: _ ? this.primary : k[s].foreground,
                            link_color_hover: _ ? this.primaryHover : k[s].background_hover,
                            link_color_active: _ ? this.primaryActive : k[s].background_active,
                            primary_type: "dark",
                            secondary_type: "dark"
                        })
                    }
                }

                function M(e, t, r) {
                    var n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : m;
                    switch (r) {
                        case "contrast-ratio-4.5":
                            return !E(k[t].background, e, b);
                        case "contrast-ratio-3.0":
                            return !E(k[t].background, e, v);
                        default:
                            return e.getLuminance() > n
                    }
                }

                function I(e) {
                    if (!Boolean(e.primaryColor)) throw "A primary color was not provided to the color calculation";
                    var t = e.themeMode || "light",
                        r = d(e.primaryColor),
                        n = r.clone().setAlpha(.5),
                        o = d(e.secondaryColor || e.primaryColor),
                        i = o.toHsv(),
                        a = d({
                            h: i.h,
                            s: Math.min(i.s, .12),
                            v: 1
                        }),
                        s = o.clone();
                    s.darken(e.darkenAmount || h);
                    var c = M(r, "light", e.contrastCheckMethod, e.brightnessCutoff),
                        l = M(o, "light", e.contrastCheckMethod, e.brightnessCutoff),
                        u = "contrast-ratio-4.5" === e.contrastCheckMethod || "contrast-ratio-3.0" === e.contrastCheckMethod,
                        _ = new P(r, o, n, a, s, "pureBlackActionColors" in e ? e.pureBlackActionColors : u, t);
                    return c && l ? _.generateLightPrimaryLightSecondary() : c && !l ? _.generateLightPrimaryDarkSecondary() : !c && l ? _.generateDarkPrimaryLightSecondary() : c || l ? void 0 : _.generateDarkPrimaryDarkSecondary()
                }
                I.tinycolor = d;
                var N = function(e, t) {
                        var r = d(t);
                        return [r.clone().lighten(10).desaturate(e), r.clone().lighten(20).desaturate(e), r.clone().lighten(30).desaturate(e), r.clone().lighten(40).desaturate(e), r.clone().lighten(50).desaturate(e), r.clone().lighten(60).desaturate(e), r.clone().lighten(70).desaturate(e), r.clone().lighten(80).desaturate(e), r.clone().lighten(90).desaturate(e), r.clone().lighten(100).desaturate(e)]
                    },
                    F = function(e, t) {
                        var r = d(t);
                        return [r.clone().darken(10).desaturate(e), r.clone().darken(20).desaturate(e), r.clone().darken(30).desaturate(e), r.clone().darken(40).desaturate(e), r.clone().darken(50).desaturate(e), r.clone().darken(60).desaturate(e), r.clone().darken(70).desaturate(e), r.clone().darken(80).desaturate(e), r.clone().darken(90).desaturate(e), r.clone().darken(100).desaturate(e)]
                    },
                    D = .5,
                    j = .15,
                    L = 50,
                    W = function(e) {
                        return d(e).toHsl().l
                    },
                    z = function(e) {
                        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : L,
                            r = W(e),
                            n = r > D,
                            o = N(r < j ? 1.5 * t : t, e),
                            i = F(t, e),
                            a = (n ? [].concat(s(i), s(o)) : [].concat(s(o), s(i))).find((function(t) {
                                return E(t, e, b)
                            }));
                        if (!a) return {
                            foregroundColor: null,
                            isLightColor: !1
                        };
                        var c = W(a) > r;
                        return {
                            foregroundColor: a.toHexString(),
                            isLightColor: c
                        }
                    };
                return I.getAccessibleForegroundColorForBackground = z, I
            }()
        },
        13560: e => {
            var t;
            globalThis, t = () => (() => {
                "use strict";
                var e = {
                        d: (t, r) => {
                            for (var n in r) e.o(r, n) && !e.o(t, n) && Object.defineProperty(t, n, {
                                enumerable: !0,
                                get: r[n]
                            })
                        },
                        o: (e, t) => Object.prototype.hasOwnProperty.call(e, t),
                        r: e => {
                            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                                value: "Module"
                            }), Object.defineProperty(e, "__esModule", {
                                value: !0
                            })
                        }
                    },
                    t = {};
                e.r(t), e.d(t, {
                    default: () => S
                });
                var r = {
                    NEXUS_CLIENT_VERSION: "0.21.0",
                    IS_TYPING_THROTTLE: 1e3,
                    PRESENCE_INTERVAL: 12e4,
                    PRESENCE_ENABLED: !0,
                    PING_TIMEOUT: 45e3,
                    PONG_TIMEOUT: 1e4,
                    WEBSOCKET_CONNECT_TIMEOUT: 3e4,
                    EVENT_BUFFER_TTL: 3e4
                };
                const n = new(function() {
                    function e() {
                        Object.assign(this, r)
                    }
                    return e.prototype.reset = function() {
                        Object.assign(this, r)
                    }, e.prototype.setOptions = function(e) {
                        Object.assign(this, e)
                    }, e
                }());
                var o = "NexusClient - ";
                const i = new(function() {
                    function e() {
                        this.logger = console
                    }
                    return e.prototype.destroy = function() {
                        this.logger = null
                    }, e.prototype.setLogger = function(e) {
                        this.logger = e
                    }, e.prototype.info = function(e) {
                        window.NEXUS_DEBUG_LOGGING && console.log(o + e), this.logger && this.logger.info(o + e)
                    }, e.prototype.error = function(e) {
                        window.NEXUS_DEBUG_LOGGING && console.error(o + e), this.logger && this.logger.error(o + e)
                    }, e
                }());
                var a = "nexusclient-js.",
                    s = {
                        increment: function(e) {},
                        timing: function(e, t) {}
                    };
                const c = new(function() {
                        function e() {
                            this._sink = s
                        }
                        return e.prototype.setSink = function(e) {
                            this._sink = e
                        }, e.prototype.reset = function() {
                            this._sink = s
                        }, e.prototype.increment = function(e) {
                            this._sink.increment(a + e)
                        }, e.prototype.timing = function(e, t) {
                            this._sink.timing(a + e, t)
                        }, e
                    }()),
                    l = function() {
                        function e(e, t, r, n, o) {
                            this.initialBaseDelay = e, this.maxBaseDelay = t, this.backoffMultiplier = r, this.minRandom = n, this.maxRandom = o, this.reset()
                        }
                        return e.prototype.reset = function() {
                            this.nextInitialBaseDelay = this.initialBaseDelay
                        }, e.prototype.next = function() {
                            if (this.nextInitialBaseDelay > this.maxBaseDelay) return this.reset(), Math.floor(this.maxBaseDelay * this.randomFloat(this.minRandom, this.maxRandom));
                            var e = Math.floor(this.nextInitialBaseDelay * this.randomFloat(this.minRandom, this.maxRandom));
                            return this.nextInitialBaseDelay = this.nextInitialBaseDelay * this.backoffMultiplier, e
                        }, e.prototype.randomFloat = function(e, t) {
                            return Math.random() * (t - e) + e
                        }, e
                    }();

                function u(e, t) {
                    for (var r in e) e.hasOwnProperty(r) && t(r, e[r])
                }

                function _(e, t) {
                    return [].concat(e, t).filter((function(e, t, r) {
                        return r.indexOf(e) === t
                    }))
                }

                function d(e, t) {
                    return e.filter((function(e) {
                        return !t.includes(e)
                    }))
                }

                function p() {
                    var e = document;
                    return void 0 !== e.hidden || void 0 !== e.mozHidden || void 0 !== e.msHidden || void 0 !== e.webkitHidden
                }
                const f = function() {
                        function e(e) {
                            this._nexusWebSocket = e, this._topics = []
                        }
                        return e.prototype.subscribe = function(e) {
                            this._topics = _(this._topics, e), this._publish_event("nx.Subscribe", e)
                        }, e.prototype.unsubscribe = function(e) {
                            this._topics = d(this._topics, e), this._publish_event("nx.Unsubscribe", e)
                        }, e.prototype.hasNoSubscriptions = function() {
                            return 0 === this._topics.length
                        }, e.prototype.flush = function() {
                            this._topics.length > 0 && this.subscribe(this._topics)
                        }, e.prototype.destroy = function() {
                            this._nexusWebSocket = null, this._topics = []
                        }, e.setEventTopics = function(e) {
                            var t = this._event_topics(e.eventName, e.eventData);
                            return t && (e["nx.Topics"] = t), e
                        }, e.isTopicEvent = function(e) {
                            return ["nx.Subscribe", "nx.Unsubscribe"].includes(e.eventName)
                        }, e._event_topics = function(e, t) {
                            switch (e) {
                                case "AdminIsTyping":
                                case "UserIsTyping":
                                case "ConversationSeen":
                                case "AdminIsTypingANote":
                                case "UserContentSeenByAdmin":
                                case "NewComment":
                                    return t.conversationId ? ["conversation/".concat(t.conversationId)] : ["conversation/new"];
                                default:
                                    return !1
                            }
                        }, e.prototype._publish_event = function(e, t) {
                            this._nexusWebSocket && this._nexusWebSocket.isWebsocketTransport() && this._nexusWebSocket.publish({
                                eventName: e,
                                "nx.Topics": t
                            })
                        }, e
                    }(),
                    h = function() {
                        function e(e) {
                            this._publish = e, this._events = {}, this._conversationEvents = {}
                        }
                        return e.prototype.getEvents = function() {
                            return {
                                events: this._events,
                                conversationEvents: this._conversationEvents
                            }
                        }, e.prototype.pushEvent = function(e) {
                            if (!f.isTopicEvent(e)) {
                                var t = e.eventData && e.eventData.conversationId;
                                t ? this._pushConversationEvent(t, e) : this._pushEvent(e)
                            }
                        }, e.prototype.flush = function() {
                            this._flushEvents(this._events), this._events = {}, this._flushConversationEvents(), this._conversationEvents = {}
                        }, e.prototype._pushEvent = function(e) {
                            var t = (new Date).getTime();
                            this._events[t] = e
                        }, e.prototype._pushConversationEvent = function(e, t) {
                            var r = (new Date).getTime(),
                                n = this._conversationEvents[e] || {};
                            n[r] = t, this._conversationEvents[e] = n
                        }, e.prototype._flushEvents = function(e) {
                            var t = this,
                                r = (new Date).getTime();
                            u(e, (function(e, o) {
                                r - e < n.EVENT_BUFFER_TTL && t._publish(o)
                            }))
                        }, e.prototype._flushConversationEvents = function() {
                            var e = this;
                            u(this._conversationEvents, (function(t, r) {
                                return e._flushEvents(r)
                            }))
                        }, e
                    }(),
                    m = function(e, t, r) {
                        var n = null,
                            o = -1,
                            i = null,
                            a = null,
                            s = !1 !== (null == r ? void 0 : r.trailing),
                            c = function() {
                                if (o = Date.now(), n = null, i) try {
                                    e.apply(a, i)
                                } finally {
                                    i = null, a = null
                                }
                            },
                            l = function() {
                                for (var r = [], l = 0; l < arguments.length; l++) r[l] = arguments[l];
                                var u = Date.now();
                                if (a = this, i = r, o < 0 || u - o >= t) {
                                    n && (clearTimeout(n), n = null), o = u;
                                    try {
                                        e.apply(a, i)
                                    } finally {
                                        i = null, a = null
                                    }
                                } else !n && s && (n = setTimeout(c, t - (u - o)))
                            };
                        return l.cancel = function() {
                            n && (clearTimeout(n), n = null), o = -1, i = null, a = null
                        }, l
                    },
                    y = function() {
                        function e(e) {
                            this._throttlePresenceEvent = this._createSendPresenceEventThrottle(), this._nexusWebSocket = e, this._initPageVisibilityListenners()
                        }
                        return e.prototype.start = function() {
                            var e = this;
                            this._presenceInterval || (this._throttlePresenceEvent(), this._presenceInterval = setInterval((function() {
                                e._throttlePresenceEvent()
                            }), n.PRESENCE_INTERVAL))
                        }, e.prototype.stop = function() {
                            this._presenceInterval && clearInterval(this._presenceInterval), this._presenceInterval = null
                        }, e.prototype.destroy = function() {
                            this.stop(), this._teardownPageVisibilityListeners(), this._nexusWebSocket = null
                        }, e.prototype.reset = function() {
                            this.stop(), this._throttlePresenceEvent.cancel(), this.start()
                        }, e.prototype._sendPresenceEvent = function() {
                            n.PRESENCE_ENABLED && this._nexusWebSocket && this._nexusWebSocket.publish({
                                eventName: "nx.UserPresence"
                            })
                        }, e.prototype._createSendPresenceEventThrottle = function() {
                            return m(this._sendPresenceEvent.bind(this), n.PRESENCE_INTERVAL)
                        }, e.prototype._initPageVisibilityListenners = function() {
                            var e, t;
                            p() && (this._visibilityEvent = (void 0 !== (t = document).hidden ? e = "visibilitychange" : void 0 !== t.mozHidden ? e = "mozvisibilitychange" : void 0 !== t.msHidden ? e = "msvisibilitychange" : void 0 !== t.webkitHidden && (e = "webkitvisibilitychange"), e), this._onPageVisibleBound = this._onPageVisibilityChange.bind(this), window.addEventListener(this._visibilityEvent, this._onPageVisibleBound))
                        }, e.prototype._teardownPageVisibilityListeners = function() {
                            p() && window.removeEventListener(this._visibilityEvent, this._onPageVisibleBound)
                        }, e.prototype._onPageVisibilityChange = function() {
                            var e;
                            (void 0 !== (e = document).hidden ? e.hidden : void 0 !== e.mozHidden ? e.mozHidden : void 0 !== e.msHidden ? e.msHidden : void 0 !== e.webkitHidden && e.webkitHidden) ? this.stop(): this.start()
                        }, e
                    }(),
                    g = function() {
                        function e(e, t) {
                            this.nexusWebSocket = e, this.onError = t
                        }
                        return e.prototype.start = function() {
                            var e = this;
                            this._pingTestTimer = setTimeout((function() {
                                e._ping(), e._pongTestTimer = setTimeout((function() {
                                    e.onError()
                                }), n.PONG_TIMEOUT)
                            }), n.PING_TIMEOUT)
                        }, e.prototype.ack = function() {
                            this.reset()
                        }, e.prototype.reset = function() {
                            this._stopPingPong(), this.start()
                        }, e.prototype.destroy = function() {
                            this._stopPingPong(), this.nexusWebSocket = null, this.onError = null
                        }, e.prototype.healthCheck = function() {
                            var e = this;
                            this._pongHealthCheckTimer || (this._ping(), this._pongHealthCheckTimer = setTimeout((function() {
                                e.onError()
                            }), n.PONG_TIMEOUT))
                        }, e.prototype._stopPingPong = function() {
                            this._pingTestTimer && clearTimeout(this._pingTestTimer), this._pongTestTimer && clearTimeout(this._pongTestTimer), this._resetPongHCTimer()
                        }, e.prototype._ping = function() {
                            var e = (new Date).getTime(),
                                t = {
                                    eventName: "nx.Ping",
                                    eventGuid: e.toString(),
                                    eventData: {
                                        sendTime: e,
                                        endpoint: this.nexusWebSocket.endpoint
                                    }
                                };
                            this.nexusWebSocket.publish(t)
                        }, e.prototype._resetPongHCTimer = function() {
                            this._pongHealthCheckTimer && clearTimeout(this._pongHealthCheckTimer), this._pongHealthCheckTimer = null
                        }, e
                    }(),
                    v = function() {
                        function e(e) {
                            this.nexusWebSocket = e, this._initOnlineOfflineListeners()
                        }
                        return e.prototype.destroy = function() {
                            this._teardownOnlineOfflineListeners(), this.nexusWebSocket = null
                        }, e.prototype._initOnlineOfflineListeners = function() {
                            this._cameOnlineBound = this._cameOnline.bind(this), this._wentOfflineBound = this._wentOffline.bind(this), window.addEventListener("online", this._cameOnlineBound), window.addEventListener("offline", this._wentOfflineBound)
                        }, e.prototype._teardownOnlineOfflineListeners = function() {
                            window.removeEventListener("online", this._cameOnlineBound), window.removeEventListener("offline", this._wentOfflineBound)
                        }, e.prototype._cameOnline = function() {
                            this.nexusWebSocket.reconnectNow()
                        }, e.prototype._wentOffline = function() {
                            this.nexusWebSocket.destroyWebSocket()
                        }, e
                    }(),
                    b = function() {
                        function e(e, t, r, n, o) {
                            void 0 === t && (t = function() {}), void 0 === r && (r = function() {}), void 0 === n && (n = function(e) {}), this.endpoint = e, this.onConnect = t, this.onDisconnect = r, this.onFailedToEstablishNewWebsocketConnection = n, this._userRole = o, this._calledOnConnectSinceLastDisconnect = !1, this.numberOfConsecutiveFailedRetriesToConnect = 0, this._listeners = {}, this._globalListeners = [], this.retryCounter = new l(2e3, 3e5, 2, .5, 2.5), this._initBuffer(), this._initWebSocket() ? (this._reachability = new v(this), this._presence = new y(this), this._topicManager = new f(this)) : this.onFailedToEstablishNewWebsocketConnection("websocket_not_supported")
                        }
                        return e.prototype.addListener = function(e, t) {
                            void 0 === this._listeners[e] ? this._listeners[e] = [t] : this._listeners[e].push(t)
                        }, e.prototype.removeListener = function(e, t) {
                            var r = this._listeners[e];
                            if (r) {
                                var n = r.indexOf(t);
                                n >= 0 && r.splice(n, 1)
                            }
                        }, e.prototype.addGlobalListener = function(e) {
                            this._globalListeners.push(e)
                        }, e.prototype.publish = function(e) {
                            if (this.isOpen()) try {
                                this.webSocket.send(JSON.stringify(e))
                            } catch (e) {
                                i.error("Error with publishing a message: ".concat(JSON.stringify(e))), this.webSocket && this.webSocket.close && this.webSocket.close(1e3)
                            } else this._buffer.pushEvent(e)
                        }, e.prototype.subscribeToTopics = function(e) {
                            this._topicManager.subscribe(e)
                        }, e.prototype.unsubscribeFromTopics = function(e) {
                            this._topicManager.unsubscribe(e)
                        }, e.prototype.shutdown = function() {
                            this._destroyPinger(), this._reachability.destroy(), this._presence.destroy(), this._topicManager.destroy(), this.destroyWebSocket(), this._listeners = {}, this._globalListeners = [], this._initBuffer(), this._clearConnectTimeout(), this._clearScheduledReconnect()
                        }, e.prototype.isOpen = function() {
                            return this.webSocket && this.webSocket.readyState === this.webSocket.OPEN
                        }, e.prototype.isConnecting = function() {
                            return this.webSocket && this.webSocket.readyState === this.webSocket.CONNECTING
                        }, e.prototype.isWebsocketTransport = function() {
                            return !0
                        }, e.prototype.scheduleReconnect = function(e) {
                            var t = this;
                            this._clearScheduledReconnect(), this._scheduledReconnect = setTimeout((function() {
                                t.reconnectNow()
                            }), e)
                        }, e.prototype.reconnectNow = function() {
                            this._clearScheduledReconnect(), this.destroyWebSocket(), this._topicManager.hasNoSubscriptions() && c.increment("reconnect_no_subscriptions"), this._initWebSocket()
                        }, e.prototype.eagerReconnect = function(e) {
                            var t = this,
                                r = this.webSocket,
                                n = r ? r.readyState : "null";
                            i.info("Starting eager reconnect. Old connection: ".concat(this._getReadyStateString(n))), e && (this.endpoint = e);
                            var o = this._webSocketUrl(this.endpoint),
                                a = new WebSocket(o);
                            i.info("Created new WebSocket for eager reconnect"), a.onmessage = this._onMessage.bind(this), a.onerror = function(e) {
                                i.error("New connection error during eager reconnect: ".concat(e)), t._onError(e)
                            }, a.onclose = function(e) {
                                i.info("New connection closed during eager reconnect. Code: ".concat(e.code, ", Reason: ").concat(e.reason)), t._onClose(e)
                            }, a.onopen = function(e) {
                                i.info("New connection opened. Active connections - Old: ".concat(t._getReadyStateString(null == r ? void 0 : r.readyState), ", New: ").concat(t._getReadyStateString(a.readyState))), t.webSocket = a, t._onOpen(), r && (r.onopen = null, r.onmessage = null, r.onerror = null, r.onclose = function(e) {
                                    i.info("Old connection closed. Eager reconnect complete")
                                }, r.readyState !== WebSocket.OPEN && r.readyState !== WebSocket.CONNECTING || (i.info("Closing old connection: ".concat(t._getReadyStateString(r.readyState))), r.close(1e3, "Eager reconnect")))
                            }
                        }, e.prototype._getReadyStateString = function(e) {
                            switch (e) {
                                case WebSocket.CONNECTING:
                                    return "CONNECTING (0)";
                                case WebSocket.OPEN:
                                    return "OPEN (1)";
                                case WebSocket.CLOSING:
                                    return "CLOSING (2)";
                                case WebSocket.CLOSED:
                                    return "CLOSED (3)";
                                default:
                                    return "UNKNOWN (".concat(e, ")")
                            }
                        }, e.prototype.destroyWebSocket = function() {
                            this._clearConnectTimeout(), this._calledOnConnectSinceLastDisconnect && (this.onDisconnect(), this._calledOnConnectSinceLastDisconnect = !1), this.webSocket && (this.webSocket.onopen = null, this.webSocket.onmessage = null, this.webSocket.onerror = null, this.webSocket.onclose = null, this.isOpen() ? this.webSocket && this.webSocket.close && this.webSocket.close(1e3) : this.isConnecting() && i.info("Destroying a websocket that is still in the connecting state"), this.webSocket = null), this._destroyPinger()
                        }, e.prototype.performHealthCheck = function() {
                            this._pinger && this._pinger.healthCheck(), this.isOpen() || this.reconnectNow()
                        }, e.prototype._onOpen = function() {
                            this.retryCounter.reset(), this._clearConnectTimeout(), this.numberOfConsecutiveFailedRetriesToConnect = 0, this._initPinger(), this._calledOnConnectSinceLastDisconnect = !0, this.onConnect(), this._presence.start(), this._buffer.flush(), this._topicManager.flush()
                        }, e.prototype._onMessage = function(e) {
                            var t = this._parseMessage(e);
                            t && (this._callListeners(t), "ACK" === t.eventName && this._pinger.ack())
                        }, e.prototype._onError = function(e) {
                            c.increment("error"), i.error("Websocket _onError called: ".concat(JSON.stringify(e)))
                        }, e.prototype._onClose = function(e) {
                            this.destroyWebSocket(), i.error("Websocket closed: code: ".concat(e.code, ", reason: ").concat(e.reason, ", wasClean: ").concat(e.wasClean)), navigator.onLine ? (this.numberOfConsecutiveFailedRetriesToConnect++, this.numberOfConsecutiveFailedRetriesToConnect >= 5 ? this.onFailedToEstablishNewWebsocketConnection("max_retries_to_connect_failed") : this.scheduleReconnect(this.retryCounter.next())) : this.scheduleReconnect(this.retryCounter.next())
                        }, e.prototype._onPingTimeout = function() {
                            c.increment("ping_timeout"), this.webSocket && this.webSocket.close && this.webSocket.close(1e3)
                        }, e.prototype._callListeners = function(e) {
                            var t = e.eventName;
                            this._listeners[t] && this._listeners[t].forEach((function(t) {
                                return t(e)
                            })), this._globalListeners.forEach((function(t) {
                                return t(e)
                            }))
                        }, e.prototype._clearScheduledReconnect = function() {
                            this._scheduledReconnect && (clearTimeout(this._scheduledReconnect), this._scheduledReconnect = null)
                        }, e.prototype._initBuffer = function() {
                            this._buffer = new h(this.publish.bind(this))
                        }, e.prototype._initWebSocket = function() {
                            var e = this._webSocketUrl(this.endpoint);
                            return this._startConnectTimeout(), window.WebSocket ? (this.webSocket = new WebSocket(e), this.webSocket.onopen = this._onOpen.bind(this), this.webSocket.onmessage = this._onMessage.bind(this), this.webSocket.onerror = this._onError.bind(this), this.webSocket.onclose = this._onClose.bind(this), !0) : (this._clearConnectTimeout(), !1)
                        }, e.prototype._initPinger = function() {
                            this._destroyPinger(), this._pinger = new g(this, this._onPingTimeout.bind(this)), this._pinger.start()
                        }, e.prototype._destroyPinger = function() {
                            this._pinger && (this._pinger.destroy(), this._pinger = null)
                        }, e.prototype._startConnectTimeout = function() {
                            var e = this;
                            this._clearConnectTimeout(), n.WEBSOCKET_CONNECT_TIMEOUT > 0 && (this._connectTimeout = setTimeout((function() {
                                c.increment("connect_timeout"), e.webSocket && e.webSocket.close && e.webSocket.close(1e3)
                            }), n.WEBSOCKET_CONNECT_TIMEOUT))
                        }, e.prototype._clearConnectTimeout = function() {
                            this._connectTimeout && (clearTimeout(this._connectTimeout), this._connectTimeout = null)
                        }, e.prototype._addQueryParam = function(e, t, r) {
                            var n = t + "=" + r;
                            return e + (e.split("?")[1] ? "&" : "?") + n
                        }, e.prototype._webSocketUrl = function(e) {
                            var t = e;
                            return t = this._addQueryParam(t, "X-Nexus-New-Client", !0), t = this._addQueryParam(t, "X-Nexus-Version", n.NEXUS_CLIENT_VERSION), (t = this._addQueryParam(t, "user_role", this._userRole)).replace(/^http/, "ws")
                        }, e.prototype._parseMessage = function(e) {
                            if (e.data && "" !== e.data.trim()) try {
                                return JSON.parse(e.data)
                            } catch (e) {
                                return
                            }
                        }, e
                    }();
                var w = function() {},
                    k = function() {
                        return []
                    };
                const S = function() {
                    function e(e, t, r, o, a, s, l, u, _) {
                        void 0 === o && (o = w), void 0 === a && (a = w), void 0 === s && (s = k), void 0 === l && (l = w), void 0 === u && (u = {}), this._endpoints = e, this._onNexusAvailable = o, this._onNexusNotAvailable = a, this._onChannelExpired = s, this._onFailureToEstablishConnection = l, this._userRole = _, n.setOptions(u), c.setSink(r), i.setLogger(t), this.activeConnections = 0, this._firstConnectDone = !1, this._registeredListeners = {}, this._registeredGlobalListeners = [], this._subscribedTopics = [], this._buffer = this._createBuffer(), this.connections = this._createConnections(), this.throttleSendEvent = this._createSendEventThrottle(), this.throttleSendUserEvent = this._createSendUserEventThrottle(), this.addListener("EXP", this._onExpired.bind(this)), this.addListener("nx.eagerReconnect", this._onEagerReconnect.bind(this))
                    }
                    return e.prototype.addListener = function(e, t) {
                        this._registeredListeners[e] || (this._registeredListeners[e] = []), this._registeredListeners[e].push(t), this.connections.forEach((function(r) {
                            return r.addListener(e, t)
                        }))
                    }, e.prototype.addGlobalListener = function(e) {
                        this._registeredGlobalListeners.push(e), this.connections.forEach((function(t) {
                            return t.addGlobalListener(e)
                        }))
                    }, e.prototype.setListener = function(e, t) {
                        this.addListener(e, t)
                    }, e.prototype.sendEvent = function(e, t) {
                        var r = {
                            eventName: e,
                            eventData: t
                        };
                        r = f.setEventTopics(r), this._publish(r)
                    }, e.prototype.sendUserEvent = function(e, t, r) {
                        var n = {
                            "nx.ToUser": e,
                            eventName: t,
                            eventData: r
                        };
                        n = f.setEventTopics(n), this._publish(n)
                    }, e.prototype.subscribeTopics = function(e) {
                        this._subscribedTopics = _(this._subscribedTopics, e), this.connections.forEach((function(t) {
                            return t.subscribeToTopics(e)
                        }))
                    }, e.prototype.subscribeToAllTopics = function() {
                        this.subscribeTopics(["*"])
                    }, e.prototype.unsubscribeTopics = function(e) {
                        this._subscribedTopics = d(this._subscribedTopics, e), this.connections.forEach((function(t) {
                            return t.unsubscribeFromTopics(e)
                        }))
                    }, e.prototype.newMessage = function(e) {
                        this.sendEvent("NewMessage", e)
                    }, e.prototype.newComment = function(e) {
                        this.sendEvent("NewComment", e)
                    }, e.prototype.getEndpoints = function() {
                        return this._endpoints
                    }, e.prototype.shutdown = function() {
                        this.connections.forEach((function(e) {
                            return e.shutdown()
                        })), i.destroy(), c.reset(), this.activeConnections = 0
                    }, e.prototype.retryConnection = function() {
                        this.connections.forEach((function(e) {
                            return e.reconnectNow()
                        }))
                    }, e.prototype.eagerReconnect = function(e) {
                        e && e.length > 0 && (this._endpoints = e), this.connections.forEach((function(t, r) {
                            var n = null == e ? void 0 : e[r];
                            t.eagerReconnect(n)
                        }))
                    }, e.prototype.unsubscribe = function() {
                        this.shutdown()
                    }, e.prototype.onFailedToEstablishNewWebsocketConnection = function(e) {
                        void 0 === e && (e = ""), c.increment("unable_to_establish_new_websocket_because_".concat(e)), this._onFailureToEstablishConnection(e), this._resetConnections()
                    }, e.prototype.performHealthCheck = function() {
                        this.connections.forEach((function(e) {
                            return e.performHealthCheck()
                        }))
                    }, e.prototype._onConnect = function() {
                        this.activeConnections++, 1 === this.activeConnections ? (this._onNexusAvailable(), void 0 !== this._lastDisconnectAt && (c.timing("offline", (new Date).getTime() - this._lastDisconnectAt), this._lastDisconnectAt = void 0)) : c.increment("more-than-one-connection")
                    }, e.prototype._onDisconnect = function() {
                        this.activeConnections = this.activeConnections > 0 ? this.activeConnections - 1 : 0, this.activeConnections < 1 && (this._lastDisconnectAt = (new Date).getTime(), this._onNexusNotAvailable())
                    }, e.prototype._onFirstConnect = function() {
                        this._firstConnectDone = !0, this._buffer.flush()
                    }, e.prototype._onExpired = function(e) {
                        return t = this, n = function() {
                            var e, t;
                            return function(e, t) {
                                var r, n, o, i = {
                                        label: 0,
                                        sent: function() {
                                            if (1 & o[0]) throw o[1];
                                            return o[1]
                                        },
                                        trys: [],
                                        ops: []
                                    },
                                    a = Object.create(("function" == typeof Iterator ? Iterator : Object).prototype);
                                return a.next = s(0), a.throw = s(1), a.return = s(2), "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                                    return this
                                }), a;

                                function s(s) {
                                    return function(c) {
                                        return function(s) {
                                            if (r) throw new TypeError("Generator is already executing.");
                                            for (; a && (a = 0, s[0] && (i = 0)), i;) try {
                                                if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                                switch (n = 0, o && (s = [2 & s[0], o.value]), s[0]) {
                                                    case 0:
                                                    case 1:
                                                        o = s;
                                                        break;
                                                    case 4:
                                                        return i.label++, {
                                                            value: s[1],
                                                            done: !1
                                                        };
                                                    case 5:
                                                        i.label++, n = s[1], s = [0];
                                                        continue;
                                                    case 7:
                                                        s = i.ops.pop(), i.trys.pop();
                                                        continue;
                                                    default:
                                                        if (!((o = (o = i.trys).length > 0 && o[o.length - 1]) || 6 !== s[0] && 2 !== s[0])) {
                                                            i = 0;
                                                            continue
                                                        }
                                                        if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) {
                                                            i.label = s[1];
                                                            break
                                                        }
                                                        if (6 === s[0] && i.label < o[1]) {
                                                            i.label = o[1], o = s;
                                                            break
                                                        }
                                                        if (o && i.label < o[2]) {
                                                            i.label = o[2], i.ops.push(s);
                                                            break
                                                        }
                                                        o[2] && i.ops.pop(), i.trys.pop();
                                                        continue
                                                }
                                                s = t.call(e, i)
                                            } catch (e) {
                                                s = [6, e], n = 0
                                            } finally {
                                                r = o = 0
                                            }
                                            if (5 & s[0]) throw s[1];
                                            return {
                                                value: s[0] ? s[1] : void 0,
                                                done: !0
                                            }
                                        }([s, c])
                                    }
                                }
                            }(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return r.trys.push([0, 2, , 3]), console.log("Channel expired, requesting new endpoints"), [4, this._onChannelExpired()];
                                    case 1:
                                        return (e = r.sent()) && Array.isArray(e) && 0 !== e.length ? (console.log("Received ".concat(e.length, " new endpoint(s), performing hot-swap")), this.eagerReconnect(e), [3, 3]) : (console.log("No valid endpoints returned from onChannelExpired callback, cannot reconnect, shutting down"), c.increment("onChannelExpired_no_valid_endpoints"), this.shutdown(), [2]);
                                    case 2:
                                        return t = r.sent(), console.error("Error in onChannelExpired callback, cannot reconnect, shutting down", t), c.increment("onChannelExpired_callback_error"), this.shutdown(), [3, 3];
                                    case 3:
                                        return [2]
                                }
                            }))
                        }, new((r = void 0) || (r = Promise))((function(e, o) {
                            function i(e) {
                                try {
                                    s(n.next(e))
                                } catch (e) {
                                    o(e)
                                }
                            }

                            function a(e) {
                                try {
                                    s(n.throw(e))
                                } catch (e) {
                                    o(e)
                                }
                            }

                            function s(t) {
                                var n;
                                t.done ? e(t.value) : (n = t.value, n instanceof r ? n : new r((function(e) {
                                    e(n)
                                }))).then(i, a)
                            }
                            s((n = n.apply(t, [])).next())
                        }));
                        var t, r, n
                    }, e.prototype._onEagerReconnect = function() {
                        this.eagerReconnect()
                    }, e.prototype._publish = function(e) {
                        e.eventGuid = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (function(e) {
                            var t = 16 * Math.random() | 0;
                            return ("x" === e ? t : 3 & t | 8).toString(16)
                        })), this.useNewWebSockets || this._firstConnectDone || this._buffer.pushEvent(e), this.connections.forEach((function(t) {
                            return t.publish(e)
                        }))
                    }, e.prototype._createBuffer = function() {
                        return new h(this._publish.bind(this))
                    }, e.prototype._resetConnections = function() {
                        this.connections.forEach((function(e) {
                            return e.shutdown()
                        })), this.connections = this._createConnections(), this._rehydrateConnections()
                    }, e.prototype._rehydrateConnections = function() {
                        for (var e = this, t = function(e, t) {
                                for (var n = function(t) {
                                        r.connections.forEach((function(r) {
                                            return r.addListener(e, t)
                                        }))
                                    }, o = 0, i = t; o < i.length; o++) n(i[o])
                            }, r = this, n = 0, o = Object.entries(this._registeredListeners); n < o.length; n++) {
                            var i = o[n];
                            t(i[0], i[1])
                        }
                        this._registeredGlobalListeners.forEach((function(t) {
                            e.connections.forEach((function(e) {
                                return e.addGlobalListener(t)
                            }))
                        })), this._subscribedTopics.length > 0 && this.connections.forEach((function(t) {
                            return t.subscribeToTopics(e._subscribedTopics)
                        }))
                    }, e.prototype._createConnections = function() {
                        var e = this;
                        return this._endpoints.map((function(t) {
                            return new b(t, e._onConnect.bind(e), e._onDisconnect.bind(e), e.onFailedToEstablishNewWebsocketConnection.bind(e), e._userRole)
                        })).filter(Boolean)
                    }, e.prototype._createSendEventThrottle = function() {
                        return m(this.sendEvent.bind(this), n.IS_TYPING_THROTTLE)
                    }, e.prototype._createSendUserEventThrottle = function() {
                        return m(this.sendUserEvent.bind(this), n.IS_TYPING_THROTTLE, {
                            trailing: !1
                        })
                    }, e
                }();
                return t
            })(), e.exports = t()
        },
        79100: (e, t, r) => {
            "use strict";
            r.d(t, {
                _: () => p
            });
            var n = r(38729),
                o = function(e, t) {
                    var r = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!r) return e;
                    var n, o, i = r.call(e),
                        a = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(n = i.next()).done;) a.push(n.value)
                    } catch (e) {
                        o = {
                            error: e
                        }
                    } finally {
                        try {
                            n && !n.done && (r = i.return) && r.call(i)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return a
                },
                i = function(e, t, r) {
                    if (r || 2 === arguments.length)
                        for (var n, o = 0, i = t.length; o < i; o++) !n && o in t || (n || (n = Array.prototype.slice.call(t, 0, o)), n[o] = t[o]);
                    return e.concat(n || Array.prototype.slice.call(t))
                },
                a = function() {
                    function e() {}
                    return e.prototype.active = function() {
                        return n.l
                    }, e.prototype.with = function(e, t, r) {
                        for (var n = [], a = 3; a < arguments.length; a++) n[a - 3] = arguments[a];
                        return t.call.apply(t, i([r], o(n), !1))
                    }, e.prototype.bind = function(e, t) {
                        return t
                    }, e.prototype.enable = function() {
                        return this
                    }, e.prototype.disable = function() {
                        return this
                    }, e
                }(),
                s = r(75158),
                c = r(44892),
                l = function(e, t) {
                    var r = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!r) return e;
                    var n, o, i = r.call(e),
                        a = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(n = i.next()).done;) a.push(n.value)
                    } catch (e) {
                        o = {
                            error: e
                        }
                    } finally {
                        try {
                            n && !n.done && (r = i.return) && r.call(i)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return a
                },
                u = function(e, t, r) {
                    if (r || 2 === arguments.length)
                        for (var n, o = 0, i = t.length; o < i; o++) !n && o in t || (n || (n = Array.prototype.slice.call(t, 0, o)), n[o] = t[o]);
                    return e.concat(n || Array.prototype.slice.call(t))
                },
                _ = "context",
                d = new a,
                p = function() {
                    function e() {}
                    return e.getInstance = function() {
                        return this._instance || (this._instance = new e), this._instance
                    }, e.prototype.setGlobalContextManager = function(e) {
                        return (0, s.$G)(_, e, c.K.instance())
                    }, e.prototype.active = function() {
                        return this._getContextManager().active()
                    }, e.prototype.with = function(e, t, r) {
                        for (var n, o = [], i = 3; i < arguments.length; i++) o[i - 3] = arguments[i];
                        return (n = this._getContextManager()).with.apply(n, u([e, t, r], l(o), !1))
                    }, e.prototype.bind = function(e, t) {
                        return this._getContextManager().bind(e, t)
                    }, e.prototype._getContextManager = function() {
                        return (0, s.mS)(_) || d
                    }, e.prototype.disable = function() {
                        this._getContextManager().disable(), (0, s.kv)(_, c.K.instance())
                    }, e
                }()
        },
        44892: (e, t, r) => {
            "use strict";
            r.d(t, {
                K: () => _
            });
            var n = r(75158),
                o = function(e, t) {
                    var r = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!r) return e;
                    var n, o, i = r.call(e),
                        a = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(n = i.next()).done;) a.push(n.value)
                    } catch (e) {
                        o = {
                            error: e
                        }
                    } finally {
                        try {
                            n && !n.done && (r = i.return) && r.call(i)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return a
                },
                i = function(e, t, r) {
                    if (r || 2 === arguments.length)
                        for (var n, o = 0, i = t.length; o < i; o++) !n && o in t || (n || (n = Array.prototype.slice.call(t, 0, o)), n[o] = t[o]);
                    return e.concat(n || Array.prototype.slice.call(t))
                },
                a = function() {
                    function e(e) {
                        this._namespace = e.namespace || "DiagComponentLogger"
                    }
                    return e.prototype.debug = function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                        return s("debug", this._namespace, e)
                    }, e.prototype.error = function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                        return s("error", this._namespace, e)
                    }, e.prototype.info = function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                        return s("info", this._namespace, e)
                    }, e.prototype.warn = function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                        return s("warn", this._namespace, e)
                    }, e.prototype.verbose = function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                        return s("verbose", this._namespace, e)
                    }, e
                }();

            function s(e, t, r) {
                var a = (0, n.mS)("diag");
                if (a) return r.unshift(t), a[e].apply(a, i([], o(r), !1))
            }
            var c = r(76733);
            var l = function(e, t) {
                    var r = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!r) return e;
                    var n, o, i = r.call(e),
                        a = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(n = i.next()).done;) a.push(n.value)
                    } catch (e) {
                        o = {
                            error: e
                        }
                    } finally {
                        try {
                            n && !n.done && (r = i.return) && r.call(i)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                    return a
                },
                u = function(e, t, r) {
                    if (r || 2 === arguments.length)
                        for (var n, o = 0, i = t.length; o < i; o++) !n && o in t || (n || (n = Array.prototype.slice.call(t, 0, o)), n[o] = t[o]);
                    return e.concat(n || Array.prototype.slice.call(t))
                },
                _ = function() {
                    function e() {
                        function e(e) {
                            return function() {
                                for (var t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                                var o = (0, n.mS)("diag");
                                if (o) return o[e].apply(o, u([], l(t), !1))
                            }
                        }
                        var t = this;
                        t.setLogger = function(e, r) {
                            var o, i, a;
                            if (void 0 === r && (r = {
                                    logLevel: c.u.INFO
                                }), e === t) {
                                var s = new Error("Cannot use diag as the logger for itself. Please use a DiagLogger implementation like ConsoleDiagLogger or a custom implementation");
                                return t.error(null !== (o = s.stack) && void 0 !== o ? o : s.message), !1
                            }
                            "number" == typeof r && (r = {
                                logLevel: r
                            });
                            var l = (0, n.mS)("diag"),
                                u = function(e, t) {
                                    function r(r, n) {
                                        var o = t[r];
                                        return "function" == typeof o && e >= n ? o.bind(t) : function() {}
                                    }
                                    return e < c.u.NONE ? e = c.u.NONE : e > c.u.ALL && (e = c.u.ALL), t = t || {}, {
                                        error: r("error", c.u.ERROR),
                                        warn: r("warn", c.u.WARN),
                                        info: r("info", c.u.INFO),
                                        debug: r("debug", c.u.DEBUG),
                                        verbose: r("verbose", c.u.VERBOSE)
                                    }
                                }(null !== (i = r.logLevel) && void 0 !== i ? i : c.u.INFO, e);
                            if (l && !r.suppressOverrideMessage) {
                                var _ = null !== (a = (new Error).stack) && void 0 !== a ? a : "<failed to generate stacktrace>";
                                l.warn("Current logger will be overwritten from " + _), u.warn("Current logger will overwrite one already registered from " + _)
                            }
                            return (0, n.$G)("diag", u, t, !0)
                        }, t.disable = function() {
                            (0, n.kv)("diag", t)
                        }, t.createComponentLogger = function(e) {
                            return new a(e)
                        }, t.verbose = e("verbose"), t.debug = e("debug"), t.info = e("info"), t.warn = e("warn"), t.error = e("error")
                    }
                    return e.instance = function() {
                        return this._instance || (this._instance = new e), this._instance
                    }, e
                }()
        },
        41844: (e, t, r) => {
            "use strict";
            r.d(t, {
                _: () => n
            });
            var n = r(79100)._.getInstance()
        },
        38729: (e, t, r) => {
            "use strict";

            function n(e) {
                return Symbol.for(e)
            }
            r.d(t, {
                l: () => o,
                n: () => n
            });
            var o = new function e(t) {
                var r = this;
                r._currentContext = t ? new Map(t) : new Map, r.getValue = function(e) {
                    return r._currentContext.get(e)
                }, r.setValue = function(t, n) {
                    var o = new e(r._currentContext);
                    return o._currentContext.set(t, n), o
                }, r.deleteValue = function(t) {
                    var n = new e(r._currentContext);
                    return n._currentContext.delete(t), n
                }
            }
        },
        76733: (e, t, r) => {
            "use strict";
            var n;
            r.d(t, {
                    u: () => n
                }),
                function(e) {
                    e[e.NONE = 0] = "NONE", e[e.ERROR = 30] = "ERROR", e[e.WARN = 50] = "WARN", e[e.INFO = 60] = "INFO", e[e.DEBUG = 70] = "DEBUG", e[e.VERBOSE = 80] = "VERBOSE", e[e.ALL = 9999] = "ALL"
                }(n || (n = {}))
        },
        75158: (e, t, r) => {
            "use strict";
            r.d(t, {
                mS: () => _,
                $G: () => u,
                kv: () => d
            });
            var n = "object" == typeof globalThis ? globalThis : "object" == typeof self ? self : "object" == typeof window ? window : "object" == typeof r.g ? r.g : {},
                o = "1.9.0",
                i = /^(\d+)\.(\d+)\.(\d+)(-(.+))?$/;
            var a = function(e) {
                    var t = new Set([e]),
                        r = new Set,
                        n = e.match(i);
                    if (!n) return function() {
                        return !1
                    };
                    var o = +n[1],
                        a = +n[2],
                        s = +n[3];
                    if (null != n[4]) return function(t) {
                        return t === e
                    };

                    function c(e) {
                        return r.add(e), !1
                    }

                    function l(e) {
                        return t.add(e), !0
                    }
                    return function(e) {
                        if (t.has(e)) return !0;
                        if (r.has(e)) return !1;
                        var n = e.match(i);
                        if (!n) return c(e);
                        var u = +n[1],
                            _ = +n[2],
                            d = +n[3];
                        return null != n[4] || o !== u ? c(e) : 0 === o ? a === _ && s <= d ? l(e) : c(e) : a <= _ ? l(e) : c(e)
                    }
                }(o),
                s = o.split(".")[0],
                c = Symbol.for("opentelemetry.js.api." + s),
                l = n;

            function u(e, t, r, n) {
                var i;
                void 0 === n && (n = !1);
                var a = l[c] = null !== (i = l[c]) && void 0 !== i ? i : {
                    version: o
                };
                if (!n && a[e]) {
                    var s = new Error("@opentelemetry/api: Attempted duplicate registration of API: " + e);
                    return r.error(s.stack || s.message), !1
                }
                if (a.version !== o) {
                    s = new Error("@opentelemetry/api: Registration of version v" + a.version + " for " + e + " does not match previously registered API v" + o);
                    return r.error(s.stack || s.message), !1
                }
                return a[e] = t, r.debug("@opentelemetry/api: Registered a global for " + e + " v" + o + "."), !0
            }

            function _(e) {
                var t, r, n = null === (t = l[c]) || void 0 === t ? void 0 : t.version;
                if (n && a(n)) return null === (r = l[c]) || void 0 === r ? void 0 : r[e]
            }

            function d(e, t) {
                t.debug("@opentelemetry/api: Unregistering a global for " + e + " v" + o + ".");
                var r = l[c];
                r && delete r[e]
            }
        },
        6664: (e, t, r) => {
            "use strict";
            r.d(t, {
                u: () => l
            });
            var n = r(75158),
                o = r(74975),
                i = r(67823),
                a = r(13299),
                s = r(44892),
                c = "trace",
                l = function() {
                    function e() {
                        this._proxyTracerProvider = new o.n, this.wrapSpanContext = i.IP, this.isSpanContextValid = i.YA, this.deleteSpan = a.EW, this.getSpan = a.fU, this.getActiveSpan = a.Bk, this.getSpanContext = a.w8, this.setSpan = a.Bx, this.setSpanContext = a.g_
                    }
                    return e.getInstance = function() {
                        return this._instance || (this._instance = new e), this._instance
                    }, e.prototype.setGlobalTracerProvider = function(e) {
                        var t = (0, n.$G)(c, this._proxyTracerProvider, s.K.instance());
                        return t && this._proxyTracerProvider.setDelegate(e), t
                    }, e.prototype.getTracerProvider = function() {
                        return (0, n.mS)(c) || this._proxyTracerProvider
                    }, e.prototype.getTracer = function(e, t) {
                        return this.getTracerProvider().getTracer(e, t)
                    }, e.prototype.disable = function() {
                        (0, n.kv)(c, s.K.instance()), this._proxyTracerProvider = new o.n
                    }, e
                }().getInstance()
        },
        31440: (e, t, r) => {
            "use strict";
            r.d(t, {
                d: () => o
            });
            var n = r(97872),
                o = function() {
                    function e(e) {
                        void 0 === e && (e = n.dM), this._spanContext = e
                    }
                    return e.prototype.spanContext = function() {
                        return this._spanContext
                    }, e.prototype.setAttribute = function(e, t) {
                        return this
                    }, e.prototype.setAttributes = function(e) {
                        return this
                    }, e.prototype.addEvent = function(e, t) {
                        return this
                    }, e.prototype.addLink = function(e) {
                        return this
                    }, e.prototype.addLinks = function(e) {
                        return this
                    }, e.prototype.setStatus = function(e) {
                        return this
                    }, e.prototype.updateName = function(e) {
                        return this
                    }, e.prototype.end = function(e) {}, e.prototype.isRecording = function() {
                        return !1
                    }, e.prototype.recordException = function(e, t) {}, e
                }()
        },
        79755: (e, t, r) => {
            "use strict";
            r.d(t, {
                o: () => c
            });
            var n = r(79100),
                o = r(13299),
                i = r(31440),
                a = r(67823),
                s = n._.getInstance(),
                c = function() {
                    function e() {}
                    return e.prototype.startSpan = function(e, t, r) {
                        if (void 0 === r && (r = s.active()), Boolean(null == t ? void 0 : t.root)) return new i.d;
                        var n, c = r && (0, o.w8)(r);
                        return "object" == typeof(n = c) && "string" == typeof n.spanId && "string" == typeof n.traceId && "number" == typeof n.traceFlags && (0, a.YA)(c) ? new i.d(c) : new i.d
                    }, e.prototype.startActiveSpan = function(e, t, r, n) {
                        var i, a, c;
                        if (!(arguments.length < 2)) {
                            2 === arguments.length ? c = t : 3 === arguments.length ? (i = t, c = r) : (i = t, a = r, c = n);
                            var l = null != a ? a : s.active(),
                                u = this.startSpan(e, i, l),
                                _ = (0, o.Bx)(l, u);
                            return s.with(_, c, void 0, u)
                        }
                    }, e
                }()
        },
        19505: (e, t, r) => {
            "use strict";
            r.d(t, {
                y: () => o
            });
            var n = new(r(79755).o),
                o = function() {
                    function e(e, t, r, n) {
                        this._provider = e, this.name = t, this.version = r, this.options = n
                    }
                    return e.prototype.startSpan = function(e, t, r) {
                        return this._getTracer().startSpan(e, t, r)
                    }, e.prototype.startActiveSpan = function(e, t, r, n) {
                        var o = this._getTracer();
                        return Reflect.apply(o.startActiveSpan, o, arguments)
                    }, e.prototype._getTracer = function() {
                        if (this._delegate) return this._delegate;
                        var e = this._provider.getDelegateTracer(this.name, this.version, this.options);
                        return e ? (this._delegate = e, this._delegate) : n
                    }, e
                }()
        },
        74975: (e, t, r) => {
            "use strict";
            r.d(t, {
                n: () => a
            });
            var n = r(19505),
                o = r(79755),
                i = new(function() {
                    function e() {}
                    return e.prototype.getTracer = function(e, t, r) {
                        return new o.o
                    }, e
                }()),
                a = function() {
                    function e() {}
                    return e.prototype.getTracer = function(e, t, r) {
                        var o;
                        return null !== (o = this.getDelegateTracer(e, t, r)) && void 0 !== o ? o : new n.y(this, e, t, r)
                    }, e.prototype.getDelegate = function() {
                        var e;
                        return null !== (e = this._delegate) && void 0 !== e ? e : i
                    }, e.prototype.setDelegate = function(e) {
                        this._delegate = e
                    }, e.prototype.getDelegateTracer = function(e, t, r) {
                        var n;
                        return null === (n = this._delegate) || void 0 === n ? void 0 : n.getTracer(e, t, r)
                    }, e
                }()
        },
        13299: (e, t, r) => {
            "use strict";
            r.d(t, {
                Bk: () => c,
                Bx: () => l,
                EW: () => u,
                fU: () => s,
                g_: () => _,
                w8: () => d
            });
            var n = r(38729),
                o = r(31440),
                i = r(79100),
                a = (0, n.n)("OpenTelemetry Context Key SPAN");

            function s(e) {
                return e.getValue(a) || void 0
            }

            function c() {
                return s(i._.getInstance().active())
            }

            function l(e, t) {
                return e.setValue(a, t)
            }

            function u(e) {
                return e.deleteValue(a)
            }

            function _(e, t) {
                return l(e, new o.d(t))
            }

            function d(e) {
                var t;
                return null === (t = s(e)) || void 0 === t ? void 0 : t.spanContext()
            }
        },
        97872: (e, t, r) => {
            "use strict";
            r.d(t, {
                RH: () => i,
                dM: () => a,
                w9: () => o
            });
            var n = r(47397),
                o = "0000000000000000",
                i = "00000000000000000000000000000000",
                a = {
                    traceId: i,
                    spanId: o,
                    traceFlags: n.X.NONE
                }
        },
        67823: (e, t, r) => {
            "use strict";
            r.d(t, {
                IP: () => u,
                YA: () => l,
                hX: () => s,
                wN: () => c
            });
            var n = r(97872),
                o = r(31440),
                i = /^([0-9a-f]{32})$/i,
                a = /^[0-9a-f]{16}$/i;

            function s(e) {
                return i.test(e) && e !== n.RH
            }

            function c(e) {
                return a.test(e) && e !== n.w9
            }

            function l(e) {
                return s(e.traceId) && c(e.spanId)
            }

            function u(e) {
                return new o.d(e)
            }
        },
        47397: (e, t, r) => {
            "use strict";
            var n;
            r.d(t, {
                    X: () => n
                }),
                function(e) {
                    e[e.NONE = 0] = "NONE", e[e.SAMPLED = 1] = "SAMPLED"
                }(n || (n = {}))
        },
        45588: (e, t, r) => {
            "use strict";

            function n() {
                return n = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
                    }
                    return e
                }, n.apply(this, arguments)
            }
            var o;
            r.d(t, {
                    AO: () => l,
                    B6: () => T,
                    Gh: () => I,
                    HS: () => N,
                    Oi: () => a,
                    Rr: () => u,
                    aE: () => J,
                    pX: () => L,
                    pb: () => R,
                    rc: () => o,
                    sC: () => i,
                    tH: () => AbortedDeferredError,
                    ue: () => f,
                    yD: () => M
                }),
                function(e) {
                    e.Pop = "POP", e.Push = "PUSH", e.Replace = "REPLACE"
                }(o || (o = {}));

            function i(e) {
                void 0 === e && (e = {});
                let t, {
                    initialEntries: r = ["/"],
                    initialIndex: n,
                    v5Compat: i = !1
                } = e;
                t = r.map(((e, t) => h(e, "string" == typeof e ? null : e.state, 0 === t ? "default" : void 0)));
                let a = p(null == n ? t.length - 1 : n),
                    _ = o.Pop,
                    d = null;

                function p(e) {
                    return Math.min(Math.max(e, 0), t.length - 1)
                }

                function f() {
                    return t[a]
                }

                function h(e, r, n) {
                    void 0 === r && (r = null);
                    let o = c(t ? f().pathname : "/", e, r, n);
                    return s("/" === o.pathname.charAt(0), "relative pathnames are not supported in memory history: " + JSON.stringify(e)), o
                }

                function m(e) {
                    return "string" == typeof e ? e : l(e)
                }
                return {
                    get index() {
                        return a
                    },
                    get action() {
                        return _
                    },
                    get location() {
                        return f()
                    },
                    createHref: m,
                    createURL(e) {
                        return new URL(m(e), "http://localhost")
                    },
                    encodeLocation(e) {
                        let t = "string" == typeof e ? u(e) : e;
                        return {
                            pathname: t.pathname || "",
                            search: t.search || "",
                            hash: t.hash || ""
                        }
                    },
                    push(e, r) {
                        _ = o.Push;
                        let n = h(e, r);
                        a += 1, t.splice(a, t.length, n), i && d && d({
                            action: _,
                            location: n,
                            delta: 1
                        })
                    },
                    replace(e, r) {
                        _ = o.Replace;
                        let n = h(e, r);
                        t[a] = n, i && d && d({
                            action: _,
                            location: n,
                            delta: 0
                        })
                    },
                    go(e) {
                        _ = o.Pop;
                        let r = p(a + e),
                            n = t[r];
                        a = r, d && d({
                            action: _,
                            location: n,
                            delta: e
                        })
                    },
                    listen(e) {
                        return d = e, () => {
                            d = null
                        }
                    }
                }
            }

            function a(e, t) {
                if (!1 === e || null == e) throw new Error(t)
            }

            function s(e, t) {
                if (!e) {
                    "undefined" != typeof console && console.warn(t);
                    try {
                        throw new Error(t)
                    } catch (e) {}
                }
            }

            function c(e, t, r, o) {
                return void 0 === r && (r = null), n({
                    pathname: "string" == typeof e ? e : e.pathname,
                    search: "",
                    hash: ""
                }, "string" == typeof t ? u(t) : t, {
                    state: r,
                    key: t && t.key || o || Math.random().toString(36).substr(2, 8)
                })
            }

            function l(e) {
                let {
                    pathname: t = "/",
                    search: r = "",
                    hash: n = ""
                } = e;
                return r && "?" !== r && (t += "?" === r.charAt(0) ? r : "?" + r), n && "#" !== n && (t += "#" === n.charAt(0) ? n : "#" + n), t
            }

            function u(e) {
                let t = {};
                if (e) {
                    let r = e.indexOf("#");
                    r >= 0 && (t.hash = e.substr(r), e = e.substr(0, r));
                    let n = e.indexOf("?");
                    n >= 0 && (t.search = e.substr(n), e = e.substr(0, n)), e && (t.pathname = e)
                }
                return t
            }
            var _;
            ! function(e) {
                e.data = "data", e.deferred = "deferred", e.redirect = "redirect", e.error = "error"
            }(_ || (_ = {}));
            const d = new Set(["lazy", "caseSensitive", "path", "id", "index", "children"]);

            function p(e, t, r, o) {
                return void 0 === r && (r = []), void 0 === o && (o = {}), e.map(((e, i) => {
                    let s = [...r, String(i)],
                        c = "string" == typeof e.id ? e.id : s.join("-");
                    if (a(!0 !== e.index || !e.children, "Cannot specify children on an index route"), a(!o[c], 'Found a route id collision on id "' + c + "\".  Route id's must be globally unique within Data Router usages"), function(e) {
                            return !0 === e.index
                        }(e)) {
                        let r = n({}, e, t(e), {
                            id: c
                        });
                        return o[c] = r, r
                    } {
                        let r = n({}, e, t(e), {
                            id: c,
                            children: void 0
                        });
                        return o[c] = r, e.children && (r.children = p(e.children, t, s, o)), r
                    }
                }))
            }

            function f(e, t, r) {
                return void 0 === r && (r = "/"), h(e, t, r, !1)
            }

            function h(e, t, r, n) {
                let o = R(("string" == typeof t ? u(t) : t).pathname || "/", r);
                if (null == o) return null;
                let i = m(e);
                ! function(e) {
                    e.sort(((e, t) => e.score !== t.score ? t.score - e.score : function(e, t) {
                        let r = e.length === t.length && e.slice(0, -1).every(((e, r) => e === t[r]));
                        return r ? e[e.length - 1] - t[t.length - 1] : 0
                    }(e.routesMeta.map((e => e.childrenIndex)), t.routesMeta.map((e => e.childrenIndex)))))
                }(i);
                let a = null;
                for (let e = 0; null == a && e < i.length; ++e) {
                    let t = A(o);
                    a = E(i[e], t, n)
                }
                return a
            }

            function m(e, t, r, n) {
                void 0 === t && (t = []), void 0 === r && (r = []), void 0 === n && (n = "");
                let o = (e, o, i) => {
                    let s = {
                        relativePath: void 0 === i ? e.path || "" : i,
                        caseSensitive: !0 === e.caseSensitive,
                        childrenIndex: o,
                        route: e
                    };
                    s.relativePath.startsWith("/") && (a(s.relativePath.startsWith(n), 'Absolute route path "' + s.relativePath + '" nested under path "' + n + '" is not valid. An absolute child route path must start with the combined path of all its parent routes.'), s.relativePath = s.relativePath.slice(n.length));
                    let c = N([n, s.relativePath]),
                        l = r.concat(s);
                    e.children && e.children.length > 0 && (a(!0 !== e.index, 'Index routes must not have child routes. Please remove all child routes from route path "' + c + '".'), m(e.children, t, l, c)), (null != e.path || e.index) && t.push({
                        path: c,
                        score: C(c, e.index),
                        routesMeta: l
                    })
                };
                return e.forEach(((e, t) => {
                    var r;
                    if ("" !== e.path && null != (r = e.path) && r.includes("?"))
                        for (let r of y(e.path)) o(e, t, r);
                    else o(e, t)
                })), t
            }

            function y(e) {
                let t = e.split("/");
                if (0 === t.length) return [];
                let [r, ...n] = t, o = r.endsWith("?"), i = r.replace(/\?$/, "");
                if (0 === n.length) return o ? [i, ""] : [i];
                let a = y(n.join("/")),
                    s = [];
                return s.push(...a.map((e => "" === e ? i : [i, e].join("/")))), o && s.push(...a), s.map((t => e.startsWith("/") && "" === t ? "/" : t))
            }
            const g = /^:[\w-]+$/,
                v = 3,
                b = 2,
                w = 1,
                k = 10,
                S = -2,
                x = e => "*" === e;

            function C(e, t) {
                let r = e.split("/"),
                    n = r.length;
                return r.some(x) && (n += S), t && (n += b), r.filter((e => !x(e))).reduce(((e, t) => e + (g.test(t) ? v : "" === t ? w : k)), n)
            }

            function E(e, t, r) {
                void 0 === r && (r = !1);
                let {
                    routesMeta: n
                } = e, o = {}, i = "/", a = [];
                for (let e = 0; e < n.length; ++e) {
                    let s = n[e],
                        c = e === n.length - 1,
                        l = "/" === i ? t : t.slice(i.length) || "/",
                        u = T({
                            path: s.relativePath,
                            caseSensitive: s.caseSensitive,
                            end: c
                        }, l),
                        _ = s.route;
                    if (!u && c && r && !n[n.length - 1].route.index && (u = T({
                            path: s.relativePath,
                            caseSensitive: s.caseSensitive,
                            end: !1
                        }, l)), !u) return null;
                    Object.assign(o, u.params), a.push({
                        params: o,
                        pathname: N([i, u.pathname]),
                        pathnameBase: F(N([i, u.pathnameBase])),
                        route: _
                    }), "/" !== u.pathnameBase && (i = N([i, u.pathnameBase]))
                }
                return a
            }

            function T(e, t) {
                "string" == typeof e && (e = {
                    path: e,
                    caseSensitive: !1,
                    end: !0
                });
                let [r, n] = function(e, t, r) {
                    void 0 === t && (t = !1);
                    void 0 === r && (r = !0);
                    s("*" === e || !e.endsWith("*") || e.endsWith("/*"), 'Route path "' + e + '" will be treated as if it were "' + e.replace(/\*$/, "/*") + '" because the `*` character must always follow a `/` in the pattern. To get rid of this warning, please change the route path to "' + e.replace(/\*$/, "/*") + '".');
                    let n = [],
                        o = "^" + e.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^${}|()[\]]/g, "\\$&").replace(/\/:([\w-]+)(\?)?/g, ((e, t, r) => (n.push({
                            paramName: t,
                            isOptional: null != r
                        }), r ? "/?([^\\/]+)?" : "/([^\\/]+)")));
                    e.endsWith("*") ? (n.push({
                        paramName: "*"
                    }), o += "*" === e || "/*" === e ? "(.*)$" : "(?:\\/(.+)|\\/*)$") : r ? o += "\\/*$" : "" !== e && "/" !== e && (o += "(?:(?=\\/|$))");
                    let i = new RegExp(o, t ? void 0 : "i");
                    return [i, n]
                }(e.path, e.caseSensitive, e.end), o = t.match(r);
                if (!o) return null;
                let i = o[0],
                    a = i.replace(/(.)\/+$/, "$1"),
                    c = o.slice(1);
                return {
                    params: n.reduce(((e, t, r) => {
                        let {
                            paramName: n,
                            isOptional: o
                        } = t;
                        if ("*" === n) {
                            let e = c[r] || "";
                            a = i.slice(0, i.length - e.length).replace(/(.)\/+$/, "$1")
                        }
                        const s = c[r];
                        return e[n] = o && !s ? void 0 : (s || "").replace(/%2F/g, "/"), e
                    }), {}),
                    pathname: i,
                    pathnameBase: a,
                    pattern: e
                }
            }

            function A(e) {
                try {
                    return e.split("/").map((e => decodeURIComponent(e).replace(/\//g, "%2F"))).join("/")
                } catch (t) {
                    return s(!1, 'The URL path "' + e + '" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent encoding (' + t + ")."), e
                }
            }

            function R(e, t) {
                if ("/" === t) return e;
                if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
                let r = t.endsWith("/") ? t.length - 1 : t.length,
                    n = e.charAt(r);
                return n && "/" !== n ? null : e.slice(r) || "/"
            }

            function O(e, t, r, n) {
                return "Cannot include a '" + e + "' character in a manually specified `to." + t + "` field [" + JSON.stringify(n) + "].  Please separate it out to the `to." + r + '` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.'
            }

            function P(e) {
                return e.filter(((e, t) => 0 === t || e.route.path && e.route.path.length > 0))
            }

            function M(e, t) {
                let r = P(e);
                return t ? r.map(((t, r) => r === e.length - 1 ? t.pathname : t.pathnameBase)) : r.map((e => e.pathnameBase))
            }

            function I(e, t, r, o) {
                let i;
                void 0 === o && (o = !1), "string" == typeof e ? i = u(e) : (i = n({}, e), a(!i.pathname || !i.pathname.includes("?"), O("?", "pathname", "search", i)), a(!i.pathname || !i.pathname.includes("#"), O("#", "pathname", "hash", i)), a(!i.search || !i.search.includes("#"), O("#", "search", "hash", i)));
                let s, c = "" === e || "" === i.pathname,
                    l = c ? "/" : i.pathname;
                if (null == l) s = r;
                else {
                    let e = t.length - 1;
                    if (!o && l.startsWith("..")) {
                        let t = l.split("/");
                        for (;
                            ".." === t[0];) t.shift(), e -= 1;
                        i.pathname = t.join("/")
                    }
                    s = e >= 0 ? t[e] : "/"
                }
                let _ = function(e, t) {
                        void 0 === t && (t = "/");
                        let {
                            pathname: r,
                            search: n = "",
                            hash: o = ""
                        } = "string" == typeof e ? u(e) : e, i = r ? r.startsWith("/") ? r : function(e, t) {
                            let r = t.replace(/\/+$/, "").split("/");
                            return e.split("/").forEach((e => {
                                ".." === e ? r.length > 1 && r.pop() : "." !== e && r.push(e)
                            })), r.length > 1 ? r.join("/") : "/"
                        }(r, t) : t;
                        return {
                            pathname: i,
                            search: D(n),
                            hash: j(o)
                        }
                    }(i, s),
                    d = l && "/" !== l && l.endsWith("/"),
                    p = (c || "." === l) && r.endsWith("/");
                return _.pathname.endsWith("/") || !d && !p || (_.pathname += "/"), _
            }
            const N = e => e.join("/").replace(/\/\/+/g, "/"),
                F = e => e.replace(/\/+$/, "").replace(/^\/*/, "/"),
                D = e => e && "?" !== e ? e.startsWith("?") ? e : "?" + e : "",
                j = e => e && "#" !== e ? e.startsWith("#") ? e : "#" + e : "";
            class AbortedDeferredError extends Error {}
            class ErrorResponseImpl {
                constructor(e, t, r, n) {
                    void 0 === n && (n = !1), this.status = e, this.statusText = t || "", this.internal = n, r instanceof Error ? (this.data = r.toString(), this.error = r) : this.data = r
                }
            }

            function L(e) {
                return null != e && "number" == typeof e.status && "string" == typeof e.statusText && "boolean" == typeof e.internal && "data" in e
            }
            const W = ["post", "put", "patch", "delete"],
                z = new Set(W),
                U = ["get", ...W],
                H = new Set(U),
                q = new Set([301, 302, 303, 307, 308]),
                B = new Set([307, 308]),
                $ = {
                    state: "idle",
                    location: void 0,
                    formMethod: void 0,
                    formAction: void 0,
                    formEncType: void 0,
                    formData: void 0,
                    json: void 0,
                    text: void 0
                },
                G = {
                    state: "idle",
                    data: void 0,
                    formMethod: void 0,
                    formAction: void 0,
                    formEncType: void 0,
                    formData: void 0,
                    json: void 0,
                    text: void 0
                },
                V = {
                    state: "unblocked",
                    proceed: void 0,
                    reset: void 0,
                    location: void 0
                },
                Y = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
                X = e => ({
                    hasErrorBoundary: Boolean(e.hasErrorBoundary)
                }),
                K = "remix-router-transitions";

            function J(e) {
                const t = e.window ? e.window : "undefined" != typeof window ? window : void 0,
                    r = void 0 !== t && void 0 !== t.document && void 0 !== t.document.createElement,
                    i = !r;
                let l;
                if (a(e.routes.length > 0, "You must provide a non-empty routes array to createRouter"), e.mapRouteProperties) l = e.mapRouteProperties;
                else if (e.detectErrorBoundary) {
                    let t = e.detectErrorBoundary;
                    l = e => ({
                        hasErrorBoundary: t(e)
                    })
                } else l = X;
                let u, d, m, y = {},
                    g = p(e.routes, l, void 0, y),
                    v = e.basename || "/",
                    b = e.unstable_dataStrategy || se,
                    w = e.unstable_patchRoutesOnMiss,
                    k = n({
                        v7_fetcherPersist: !1,
                        v7_normalizeFormMethod: !1,
                        v7_partialHydration: !1,
                        v7_prependBasename: !1,
                        v7_relativeSplatPath: !1,
                        unstable_skipActionErrorRevalidation: !1
                    }, e.future),
                    S = null,
                    x = new Set,
                    C = null,
                    E = null,
                    T = null,
                    A = null != e.hydrationData,
                    O = f(g, e.history.location, v),
                    P = null;
                if (null == O && !w) {
                    let t = we(404, {
                            pathname: e.history.location.pathname
                        }),
                        {
                            matches: r,
                            route: n
                        } = be(g);
                    O = r, P = {
                        [n.id]: t
                    }
                }
                if (O)
                    if (O.some((e => e.route.lazy))) d = !1;
                    else if (O.some((e => e.route.loader)))
                    if (k.v7_partialHydration) {
                        let t = e.hydrationData ? e.hydrationData.loaderData : null,
                            r = e.hydrationData ? e.hydrationData.errors : null,
                            n = e => !e.route.loader || ("function" != typeof e.route.loader || !0 !== e.route.loader.hydrate) && (t && void 0 !== t[e.route.id] || r && void 0 !== r[e.route.id]);
                        if (r) {
                            let e = O.findIndex((e => void 0 !== r[e.route.id]));
                            d = O.slice(0, e + 1).every(n)
                        } else d = O.every(n)
                    } else d = null != e.hydrationData;
                else d = !0;
                else d = !1, O = [];
                let M, I = {
                        historyAction: e.history.action,
                        location: e.history.location,
                        matches: O,
                        initialized: d,
                        navigation: $,
                        restoreScrollPosition: null == e.hydrationData && null,
                        preventScrollReset: !1,
                        revalidation: "idle",
                        loaderData: e.hydrationData && e.hydrationData.loaderData || {},
                        actionData: e.hydrationData && e.hydrationData.actionData || null,
                        errors: e.hydrationData && e.hydrationData.errors || P,
                        fetchers: new Map,
                        blockers: new Map
                    },
                    N = o.Pop,
                    F = !1,
                    D = !1,
                    j = new Map,
                    W = null,
                    z = !1,
                    U = !1,
                    H = [],
                    q = [],
                    J = new Map,
                    ee = 0,
                    re = -1,
                    ne = new Map,
                    ae = new Set,
                    pe = new Map,
                    fe = new Map,
                    he = new Set,
                    Se = new Map,
                    Ae = new Map,
                    Re = new Map,
                    Ie = !1;

                function We(e, t) {
                    void 0 === t && (t = {}), I = n({}, I, e);
                    let r = [],
                        o = [];
                    k.v7_fetcherPersist && I.fetchers.forEach(((e, t) => {
                        "idle" === e.state && (he.has(t) ? o.push(t) : r.push(t))
                    })), [...x].forEach((e => e(I, {
                        deletedFetchers: o,
                        unstable_viewTransitionOpts: t.viewTransitionOpts,
                        unstable_flushSync: !0 === t.flushSync
                    }))), k.v7_fetcherPersist && (r.forEach((e => I.fetchers.delete(e))), o.forEach((e => Ke(e))))
                }

                function ze(t, r, i) {
                    var a, s;
                    let c, {
                            flushSync: l
                        } = void 0 === i ? {} : i,
                        _ = null != I.actionData && null != I.navigation.formMethod && Oe(I.navigation.formMethod) && "loading" === I.navigation.state && !0 !== (null == (a = t.state) ? void 0 : a._isRedirect);
                    c = r.actionData ? Object.keys(r.actionData).length > 0 ? r.actionData : null : _ ? I.actionData : null;
                    let d = r.loaderData ? ye(I.loaderData, r.loaderData, r.matches || [], r.errors) : I.loaderData,
                        p = I.blockers;
                    p.size > 0 && (p = new Map(p), p.forEach(((e, t) => p.set(t, V))));
                    let f, h = !0 === F || null != I.navigation.formMethod && Oe(I.navigation.formMethod) && !0 !== (null == (s = t.state) ? void 0 : s._isRedirect);
                    if (u && (g = u, u = void 0), z || N === o.Pop || (N === o.Push ? e.history.push(t, t.state) : N === o.Replace && e.history.replace(t, t.state)), N === o.Pop) {
                        let e = j.get(I.location.pathname);
                        e && e.has(t.pathname) ? f = {
                            currentLocation: I.location,
                            nextLocation: t
                        } : j.has(t.pathname) && (f = {
                            currentLocation: t,
                            nextLocation: I.location
                        })
                    } else if (D) {
                        let e = j.get(I.location.pathname);
                        e ? e.add(t.pathname) : (e = new Set([t.pathname]), j.set(I.location.pathname, e)), f = {
                            currentLocation: I.location,
                            nextLocation: t
                        }
                    }
                    We(n({}, r, {
                        actionData: c,
                        loaderData: d,
                        historyAction: N,
                        location: t,
                        initialized: !0,
                        navigation: $,
                        revalidation: "idle",
                        restoreScrollPosition: ct(t, r.matches || I.matches),
                        preventScrollReset: h,
                        blockers: p
                    }), {
                        viewTransitionOpts: f,
                        flushSync: !0 === l
                    }), N = o.Pop, F = !1, D = !1, z = !1, U = !1, H = [], q = []
                }
                async function Ue(t, r, i) {
                    M && M.abort(), M = null, N = t, z = !0 === (i && i.startUninterruptedRevalidation),
                        function(e, t) {
                            if (C && T) {
                                let r = st(e, t);
                                C[r] = T()
                            }
                        }(I.location, I.matches), F = !0 === (i && i.preventScrollReset), D = !0 === (i && i.enableViewTransition);
                    let a = u || g,
                        s = i && i.overrideNavigation,
                        c = f(a, r, v),
                        l = !0 === (i && i.flushSync),
                        d = lt(c, a, r.pathname);
                    if (d.active && d.matches && (c = d.matches), !c) {
                        let {
                            error: e,
                            notFoundMatches: t,
                            route: n
                        } = ot(r.pathname);
                        return void ze(r, {
                            matches: t,
                            loaderData: {},
                            errors: {
                                [n.id]: e
                            }
                        }, {
                            flushSync: l
                        })
                    }
                    if (I.initialized && !U && function(e, t) {
                            if (e.pathname !== t.pathname || e.search !== t.search) return !1;
                            if ("" === e.hash) return "" !== t.hash;
                            if (e.hash === t.hash) return !0;
                            if ("" !== t.hash) return !0;
                            return !1
                        }(I.location, r) && !(i && i.submission && Oe(i.submission.formMethod))) return void ze(r, {
                        matches: c
                    }, {
                        flushSync: l
                    });
                    M = new AbortController;
                    let p, h = de(e.history, r, M.signal, i && i.submission);
                    if (i && i.pendingError) p = [ve(c).route.id, {
                        type: _.error,
                        error: i.pendingError
                    }];
                    else if (i && i.submission && Oe(i.submission.formMethod)) {
                        let t = await async function(e, t, r, n, i, a) {
                            void 0 === a && (a = {});
                            Ge();
                            let s, c = function(e, t) {
                                let r = {
                                    state: "submitting",
                                    location: e,
                                    formMethod: t.formMethod,
                                    formAction: t.formAction,
                                    formEncType: t.formEncType,
                                    formData: t.formData,
                                    json: t.json,
                                    text: t.text
                                };
                                return r
                            }(t, r);
                            if (We({
                                    navigation: c
                                }, {
                                    flushSync: !0 === a.flushSync
                                }), i) {
                                let r = await ut(n, t.pathname, e.signal);
                                if ("aborted" === r.type) return {
                                    shortCircuited: !0
                                };
                                if ("error" === r.type) {
                                    let {
                                        error: e,
                                        notFoundMatches: n,
                                        route: o
                                    } = it(t.pathname, r);
                                    return {
                                        matches: n,
                                        pendingActionResult: [o.id, {
                                            type: _.error,
                                            error: e
                                        }]
                                    }
                                }
                                if (!r.matches) {
                                    let {
                                        notFoundMatches: e,
                                        error: r,
                                        route: n
                                    } = ot(t.pathname);
                                    return {
                                        matches: e,
                                        pendingActionResult: [n.id, {
                                            type: _.error,
                                            error: r
                                        }]
                                    }
                                }
                                n = r.matches
                            }
                            let l = Ne(n, t);
                            if (l.route.action || l.route.lazy) {
                                if (s = (await Be("action", e, [l], n))[0], e.signal.aborted) return {
                                    shortCircuited: !0
                                }
                            } else s = {
                                type: _.error,
                                error: we(405, {
                                    method: e.method,
                                    pathname: t.pathname,
                                    routeId: l.route.id
                                })
                            };
                            if (Te(s)) {
                                let t;
                                if (a && null != a.replace) t = a.replace;
                                else {
                                    t = _e(s.response.headers.get("Location"), new URL(e.url), v) === I.location.pathname + I.location.search
                                }
                                return await qe(e, s, {
                                    submission: r,
                                    replace: t
                                }), {
                                    shortCircuited: !0
                                }
                            }
                            if (Ce(s)) throw we(400, {
                                type: "defer-action"
                            });
                            if (Ee(s)) {
                                let e = ve(n, l.route.id);
                                return !0 !== (a && a.replace) && (N = o.Push), {
                                    matches: n,
                                    pendingActionResult: [e.route.id, s]
                                }
                            }
                            return {
                                matches: n,
                                pendingActionResult: [l.route.id, s]
                            }
                        }(h, r, i.submission, c, d.active, {
                            replace: i.replace,
                            flushSync: l
                        });
                        if (t.shortCircuited) return;
                        if (t.pendingActionResult) {
                            let [e, n] = t.pendingActionResult;
                            if (Ee(n) && L(n.error) && 404 === n.error.status) return M = null, void ze(r, {
                                matches: t.matches,
                                loaderData: {},
                                errors: {
                                    [e]: n.error
                                }
                            })
                        }
                        c = t.matches || c, p = t.pendingActionResult, s = De(r, i.submission), l = !1, d.active = !1, h = de(e.history, h.url, h.signal)
                    }
                    let {
                        shortCircuited: m,
                        matches: y,
                        loaderData: b,
                        errors: w
                    } = await async function(t, r, o, i, a, s, c, l, _, d, p) {
                        let f = a || De(r, s),
                            h = s || c || Fe(f),
                            m = !(z || k.v7_partialHydration && _);
                        if (i) {
                            if (m) {
                                let e = He(p);
                                We(n({
                                    navigation: f
                                }, void 0 !== e ? {
                                    actionData: e
                                } : {}), {
                                    flushSync: d
                                })
                            }
                            let e = await ut(o, r.pathname, t.signal);
                            if ("aborted" === e.type) return {
                                shortCircuited: !0
                            };
                            if ("error" === e.type) {
                                let {
                                    error: t,
                                    notFoundMatches: n,
                                    route: o
                                } = it(r.pathname, e);
                                return {
                                    matches: n,
                                    loaderData: {},
                                    errors: {
                                        [o.id]: t
                                    }
                                }
                            }
                            if (!e.matches) {
                                let {
                                    error: e,
                                    notFoundMatches: t,
                                    route: n
                                } = ot(r.pathname);
                                return {
                                    matches: t,
                                    loaderData: {},
                                    errors: {
                                        [n.id]: e
                                    }
                                }
                            }
                            o = e.matches
                        }
                        let y = u || g,
                            [b, w] = te(e.history, I, o, h, r, k.v7_partialHydration && !0 === _, k.unstable_skipActionErrorRevalidation, U, H, q, he, pe, ae, y, v, p);
                        if (at((e => !(o && o.some((t => t.route.id === e))) || b && b.some((t => t.route.id === e)))), re = ++ee, 0 === b.length && 0 === w.length) {
                            let e = Ze();
                            return ze(r, n({
                                matches: o,
                                loaderData: {},
                                errors: p && Ee(p[1]) ? {
                                    [p[0]]: p[1].error
                                } : null
                            }, ge(p), e ? {
                                fetchers: new Map(I.fetchers)
                            } : {}), {
                                flushSync: d
                            }), {
                                shortCircuited: !0
                            }
                        }
                        if (m) {
                            let e = {};
                            if (!i) {
                                e.navigation = f;
                                let t = He(p);
                                void 0 !== t && (e.actionData = t)
                            }
                            w.length > 0 && (e.fetchers = function(e) {
                                return e.forEach((e => {
                                    let t = I.fetchers.get(e.key),
                                        r = je(void 0, t ? t.data : void 0);
                                    I.fetchers.set(e.key, r)
                                })), new Map(I.fetchers)
                            }(w)), We(e, {
                                flushSync: d
                            })
                        }
                        w.forEach((e => {
                            J.has(e.key) && Je(e.key), e.controller && J.set(e.key, e.controller)
                        }));
                        let S = () => w.forEach((e => Je(e.key)));
                        M && M.signal.addEventListener("abort", S);
                        let {
                            loaderResults: x,
                            fetcherResults: C
                        } = await $e(I.matches, o, b, w, t);
                        if (t.signal.aborted) return {
                            shortCircuited: !0
                        };
                        M && M.signal.removeEventListener("abort", S);
                        w.forEach((e => J.delete(e.key)));
                        let E = ke([...x, ...C]);
                        if (E) {
                            if (E.idx >= b.length) {
                                let e = w[E.idx - b.length].key;
                                ae.add(e)
                            }
                            return await qe(t, E.result, {
                                replace: l
                            }), {
                                shortCircuited: !0
                            }
                        }
                        let {
                            loaderData: T,
                            errors: A
                        } = me(I, o, b, x, p, w, C, Se);
                        Se.forEach(((e, t) => {
                            e.subscribe((r => {
                                (r || e.done) && Se.delete(t)
                            }))
                        })), k.v7_partialHydration && _ && I.errors && Object.entries(I.errors).filter((e => {
                            let [t] = e;
                            return !b.some((e => e.route.id === t))
                        })).forEach((e => {
                            let [t, r] = e;
                            A = Object.assign(A || {}, {
                                [t]: r
                            })
                        }));
                        let R = Ze(),
                            O = et(re),
                            P = R || O || w.length > 0;
                        return n({
                            matches: o,
                            loaderData: T,
                            errors: A
                        }, P ? {
                            fetchers: new Map(I.fetchers)
                        } : {})
                    }(h, r, c, d.active, s, i && i.submission, i && i.fetcherSubmission, i && i.replace, i && !0 === i.initialHydration, l, p);
                    m || (M = null, ze(r, n({
                        matches: y || c
                    }, ge(p), {
                        loaderData: b,
                        errors: w
                    })))
                }

                function He(e) {
                    return e && !Ee(e[1]) ? {
                        [e[0]]: e[1].data
                    } : I.actionData ? 0 === Object.keys(I.actionData).length ? null : I.actionData : void 0
                }
                async function qe(i, s, l) {
                    let {
                        submission: u,
                        fetcherSubmission: _,
                        replace: d
                    } = void 0 === l ? {} : l;
                    s.response.headers.has("X-Remix-Revalidate") && (U = !0);
                    let p = s.response.headers.get("Location");
                    a(p, "Expected a Location header on the redirect Response"), p = _e(p, new URL(i.url), v);
                    let f = c(I.location, p, {
                        _isRedirect: !0
                    });
                    if (r) {
                        let r = !1;
                        if (s.response.headers.has("X-Remix-Reload-Document")) r = !0;
                        else if (Y.test(p)) {
                            const n = e.history.createURL(p);
                            r = n.origin !== t.location.origin || null == R(n.pathname, v)
                        }
                        if (r) return void(d ? t.location.replace(p) : t.location.assign(p))
                    }
                    M = null;
                    let h = !0 === d ? o.Replace : o.Push,
                        {
                            formMethod: m,
                            formAction: y,
                            formEncType: g
                        } = I.navigation;
                    !u && !_ && m && y && g && (u = Fe(I.navigation));
                    let b = u || _;
                    if (B.has(s.response.status) && b && Oe(b.formMethod)) await Ue(h, f, {
                        submission: n({}, b, {
                            formAction: p
                        }),
                        preventScrollReset: F
                    });
                    else {
                        let e = De(f, u);
                        await Ue(h, f, {
                            overrideNavigation: e,
                            fetcherSubmission: _,
                            preventScrollReset: F
                        })
                    }
                }
                async function Be(e, t, r, n) {
                    try {
                        let o = await ce(b, e, t, r, n, y, l);
                        return await Promise.all(o.map(((e, o) => {
                            if (xe(e)) {
                                let i = e.result;
                                return {
                                    type: _.redirect,
                                    response: ue(i, t, r[o].route.id, n, v, k.v7_relativeSplatPath)
                                }
                            }
                            return le(e)
                        })))
                    } catch (e) {
                        return r.map((() => ({
                            type: _.error,
                            error: e
                        })))
                    }
                }
                async function $e(t, r, n, o, i) {
                    let [a, ...s] = await Promise.all([n.length ? Be("loader", i, n, r) : [], ...o.map((t => {
                        if (t.matches && t.match && t.controller) {
                            return Be("loader", de(e.history, t.path, t.controller.signal), [t.match], t.matches).then((e => e[0]))
                        }
                        return Promise.resolve({
                            type: _.error,
                            error: we(404, {
                                pathname: t.path
                            })
                        })
                    }))]);
                    return await Promise.all([Pe(t, n, a, a.map((() => i.signal)), !1, I.loaderData), Pe(t, o.map((e => e.match)), s, o.map((e => e.controller ? e.controller.signal : null)), !0)]), {
                        loaderResults: a,
                        fetcherResults: s
                    }
                }

                function Ge() {
                    U = !0, H.push(...at()), pe.forEach(((e, t) => {
                        J.has(t) && (q.push(t), Je(t))
                    }))
                }

                function Ve(e, t, r) {
                    void 0 === r && (r = {}), I.fetchers.set(e, t), We({
                        fetchers: new Map(I.fetchers)
                    }, {
                        flushSync: !0 === (r && r.flushSync)
                    })
                }

                function Ye(e, t, r, n) {
                    void 0 === n && (n = {});
                    let o = ve(I.matches, t);
                    Ke(e), We({
                        errors: {
                            [o.route.id]: r
                        },
                        fetchers: new Map(I.fetchers)
                    }, {
                        flushSync: !0 === (n && n.flushSync)
                    })
                }

                function Xe(e) {
                    return k.v7_fetcherPersist && (fe.set(e, (fe.get(e) || 0) + 1), he.has(e) && he.delete(e)), I.fetchers.get(e) || G
                }

                function Ke(e) {
                    let t = I.fetchers.get(e);
                    !J.has(e) || t && "loading" === t.state && ne.has(e) || Je(e), pe.delete(e), ne.delete(e), ae.delete(e), he.delete(e), I.fetchers.delete(e)
                }

                function Je(e) {
                    let t = J.get(e);
                    a(t, "Expected fetch controller: " + e), t.abort(), J.delete(e)
                }

                function Qe(e) {
                    for (let t of e) {
                        let e = Le(Xe(t).data);
                        I.fetchers.set(t, e)
                    }
                }

                function Ze() {
                    let e = [],
                        t = !1;
                    for (let r of ae) {
                        let n = I.fetchers.get(r);
                        a(n, "Expected fetcher: " + r), "loading" === n.state && (ae.delete(r), e.push(r), t = !0)
                    }
                    return Qe(e), t
                }

                function et(e) {
                    let t = [];
                    for (let [r, n] of ne)
                        if (n < e) {
                            let e = I.fetchers.get(r);
                            a(e, "Expected fetcher: " + r), "loading" === e.state && (Je(r), ne.delete(r), t.push(r))
                        }
                    return Qe(t), t.length > 0
                }

                function tt(e) {
                    I.blockers.delete(e), Ae.delete(e)
                }

                function rt(e, t) {
                    let r = I.blockers.get(e) || V;
                    a("unblocked" === r.state && "blocked" === t.state || "blocked" === r.state && "blocked" === t.state || "blocked" === r.state && "proceeding" === t.state || "blocked" === r.state && "unblocked" === t.state || "proceeding" === r.state && "unblocked" === t.state, "Invalid blocker state transition: " + r.state + " -> " + t.state);
                    let n = new Map(I.blockers);
                    n.set(e, t), We({
                        blockers: n
                    })
                }

                function nt(e) {
                    let {
                        currentLocation: t,
                        nextLocation: r,
                        historyAction: n
                    } = e;
                    if (0 === Ae.size) return;
                    Ae.size > 1 && s(!1, "A router only supports one blocker at a time");
                    let o = Array.from(Ae.entries()),
                        [i, a] = o[o.length - 1],
                        c = I.blockers.get(i);
                    return c && "proceeding" === c.state ? void 0 : a({
                        currentLocation: t,
                        nextLocation: r,
                        historyAction: n
                    }) ? i : void 0
                }

                function ot(e) {
                    let t = we(404, {
                            pathname: e
                        }),
                        r = u || g,
                        {
                            matches: n,
                            route: o
                        } = be(r);
                    return at(), {
                        notFoundMatches: n,
                        route: o,
                        error: t
                    }
                }

                function it(e, t) {
                    let r = t.partialMatches,
                        n = r[r.length - 1].route;
                    return {
                        notFoundMatches: r,
                        route: n,
                        error: we(400, {
                            type: "route-discovery",
                            routeId: n.id,
                            pathname: e,
                            message: null != t.error && "message" in t.error ? t.error : String(t.error)
                        })
                    }
                }

                function at(e) {
                    let t = [];
                    return Se.forEach(((r, n) => {
                        e && !e(n) || (r.cancel(), t.push(n), Se.delete(n))
                    })), t
                }

                function st(e, t) {
                    if (E) {
                        return E(e, t.map((e => function(e, t) {
                            let {
                                route: r,
                                pathname: n,
                                params: o
                            } = e;
                            return {
                                id: r.id,
                                pathname: n,
                                params: o,
                                data: t[r.id],
                                handle: r.handle
                            }
                        }(e, I.loaderData)))) || e.key
                    }
                    return e.key
                }

                function ct(e, t) {
                    if (C) {
                        let r = st(e, t),
                            n = C[r];
                        if ("number" == typeof n) return n
                    }
                    return null
                }

                function lt(e, t, r) {
                    if (w) {
                        if (!e) {
                            return {
                                active: !0,
                                matches: h(t, r, v, !0) || []
                            }
                        }
                        if ("*" === e[e.length - 1].route.path) {
                            return {
                                active: !0,
                                matches: h(t, r, v, !0)
                            }
                        }
                    }
                    return {
                        active: !1,
                        matches: null
                    }
                }
                async function ut(e, t, r) {
                    let n = e,
                        o = n.length > 0 ? n[n.length - 1].route : null;
                    for (;;) {
                        try {
                            await oe(w, t, n, g || u, y, l, Re, r)
                        } catch (e) {
                            return {
                                type: "error",
                                error: e,
                                partialMatches: n
                            }
                        }
                        if (r.aborted) return {
                            type: "aborted"
                        };
                        let e = u || g,
                            i = f(e, t, v),
                            a = !1;
                        if (i) {
                            let e = i[i.length - 1].route;
                            if (e.index) return {
                                type: "success",
                                matches: i
                            };
                            if (e.path && e.path.length > 0) {
                                if ("*" !== e.path) return {
                                    type: "success",
                                    matches: i
                                };
                                a = !0
                            }
                        }
                        let s = h(e, t, v, !0);
                        if (!s || n.map((e => e.route.id)).join("-") === s.map((e => e.route.id)).join("-")) return {
                            type: "success",
                            matches: a ? i : null
                        };
                        if (n = s, o = n[n.length - 1].route, "*" === o.path) return {
                            type: "success",
                            matches: n
                        }
                    }
                }
                return m = {
                    get basename() {
                        return v
                    },
                    get future() {
                        return k
                    },
                    get state() {
                        return I
                    },
                    get routes() {
                        return g
                    },
                    get window() {
                        return t
                    },
                    initialize: function() {
                        if (S = e.history.listen((t => {
                                let {
                                    action: r,
                                    location: n,
                                    delta: o
                                } = t;
                                if (Ie) return void(Ie = !1);
                                s(0 === Ae.size || null != o, "You are trying to use a blocker on a POP navigation to a location that was not created by @remix-run/router. This will fail silently in production. This can happen if you are navigating outside the router via `window.history.pushState`/`window.location.hash` instead of using router navigation APIs.  This can also happen if you are using createHashRouter and the user manually changes the URL.");
                                let i = nt({
                                    currentLocation: I.location,
                                    nextLocation: n,
                                    historyAction: r
                                });
                                return i && null != o ? (Ie = !0, e.history.go(-1 * o), void rt(i, {
                                    state: "blocked",
                                    location: n,
                                    proceed() {
                                        rt(i, {
                                            state: "proceeding",
                                            proceed: void 0,
                                            reset: void 0,
                                            location: n
                                        }), e.history.go(o)
                                    },
                                    reset() {
                                        let e = new Map(I.blockers);
                                        e.set(i, V), We({
                                            blockers: e
                                        })
                                    }
                                })) : Ue(r, n)
                            })), r) {
                            ! function(e, t) {
                                try {
                                    let r = e.sessionStorage.getItem(K);
                                    if (r) {
                                        let e = JSON.parse(r);
                                        for (let [r, n] of Object.entries(e || {})) n && Array.isArray(n) && t.set(r, new Set(n || []))
                                    }
                                } catch (e) {}
                            }(t, j);
                            let e = () => function(e, t) {
                                if (t.size > 0) {
                                    let r = {};
                                    for (let [e, n] of t) r[e] = [...n];
                                    try {
                                        e.sessionStorage.setItem(K, JSON.stringify(r))
                                    } catch (e) {
                                        s(!1, "Failed to save applied view transitions in sessionStorage (" + e + ").")
                                    }
                                }
                            }(t, j);
                            t.addEventListener("pagehide", e), W = () => t.removeEventListener("pagehide", e)
                        }
                        return I.initialized || Ue(o.Pop, I.location, {
                            initialHydration: !0
                        }), m
                    },
                    subscribe: function(e) {
                        return x.add(e), () => x.delete(e)
                    },
                    enableScrollRestoration: function(e, t, r) {
                        if (C = e, T = t, E = r || null, !A && I.navigation === $) {
                            A = !0;
                            let e = ct(I.location, I.matches);
                            null != e && We({
                                restoreScrollPosition: e
                            })
                        }
                        return () => {
                            C = null, T = null, E = null
                        }
                    },
                    navigate: async function t(r, i) {
                        if ("number" == typeof r) return void e.history.go(r);
                        let a = Q(I.location, I.matches, v, k.v7_prependBasename, r, k.v7_relativeSplatPath, null == i ? void 0 : i.fromRouteId, null == i ? void 0 : i.relative),
                            {
                                path: s,
                                submission: l,
                                error: u
                            } = Z(k.v7_normalizeFormMethod, !1, a, i),
                            _ = I.location,
                            d = c(I.location, s, i && i.state);
                        d = n({}, d, e.history.encodeLocation(d));
                        let p = i && null != i.replace ? i.replace : void 0,
                            f = o.Push;
                        !0 === p ? f = o.Replace : !1 === p || null != l && Oe(l.formMethod) && l.formAction === I.location.pathname + I.location.search && (f = o.Replace);
                        let h = i && "preventScrollReset" in i ? !0 === i.preventScrollReset : void 0,
                            m = !0 === (i && i.unstable_flushSync),
                            y = nt({
                                currentLocation: _,
                                nextLocation: d,
                                historyAction: f
                            });
                        if (!y) return await Ue(f, d, {
                            submission: l,
                            pendingError: u,
                            preventScrollReset: h,
                            replace: i && i.replace,
                            enableViewTransition: i && i.unstable_viewTransition,
                            flushSync: m
                        });
                        rt(y, {
                            state: "blocked",
                            location: d,
                            proceed() {
                                rt(y, {
                                    state: "proceeding",
                                    proceed: void 0,
                                    reset: void 0,
                                    location: d
                                }), t(r, i)
                            },
                            reset() {
                                let e = new Map(I.blockers);
                                e.set(y, V), We({
                                    blockers: e
                                })
                            }
                        })
                    },
                    fetch: function(t, r, n, o) {
                        if (i) throw new Error("router.fetch() was called during the server render, but it shouldn't be. You are likely calling a useFetcher() method in the body of your component. Try moving it to a useEffect or a callback.");
                        J.has(t) && Je(t);
                        let s = !0 === (o && o.unstable_flushSync),
                            c = u || g,
                            l = Q(I.location, I.matches, v, k.v7_prependBasename, n, k.v7_relativeSplatPath, r, null == o ? void 0 : o.relative),
                            _ = f(c, l, v),
                            d = lt(_, c, l);
                        if (d.active && d.matches && (_ = d.matches), !_) return void Ye(t, r, we(404, {
                            pathname: l
                        }), {
                            flushSync: s
                        });
                        let {
                            path: p,
                            submission: h,
                            error: m
                        } = Z(k.v7_normalizeFormMethod, !0, l, o);
                        if (m) return void Ye(t, r, m, {
                            flushSync: s
                        });
                        let y = Ne(_, p);
                        F = !0 === (o && o.preventScrollReset), h && Oe(h.formMethod) ? async function(t, r, n, o, i, s, c, l) {
                            function _(e) {
                                if (!e.route.action && !e.route.lazy) {
                                    let e = we(405, {
                                        method: l.formMethod,
                                        pathname: n,
                                        routeId: r
                                    });
                                    return Ye(t, r, e, {
                                        flushSync: c
                                    }), !0
                                }
                                return !1
                            }
                            if (Ge(), pe.delete(t), !s && _(o)) return;
                            let d = I.fetchers.get(t);
                            Ve(t, function(e, t) {
                                let r = {
                                    state: "submitting",
                                    formMethod: e.formMethod,
                                    formAction: e.formAction,
                                    formEncType: e.formEncType,
                                    formData: e.formData,
                                    json: e.json,
                                    text: e.text,
                                    data: t ? t.data : void 0
                                };
                                return r
                            }(l, d), {
                                flushSync: c
                            });
                            let p = new AbortController,
                                h = de(e.history, n, p.signal, l);
                            if (s) {
                                let e = await ut(i, n, h.signal);
                                if ("aborted" === e.type) return;
                                if ("error" === e.type) {
                                    let {
                                        error: o
                                    } = it(n, e);
                                    return void Ye(t, r, o, {
                                        flushSync: c
                                    })
                                }
                                if (!e.matches) return void Ye(t, r, we(404, {
                                    pathname: n
                                }), {
                                    flushSync: c
                                });
                                if (_(o = Ne(i = e.matches, n))) return
                            }
                            J.set(t, p);
                            let m = ee,
                                y = await Be("action", h, [o], i),
                                b = y[0];
                            if (h.signal.aborted) return void(J.get(t) === p && J.delete(t));
                            if (k.v7_fetcherPersist && he.has(t)) {
                                if (Te(b) || Ee(b)) return void Ve(t, Le(void 0))
                            } else {
                                if (Te(b)) return J.delete(t), re > m ? void Ve(t, Le(void 0)) : (ae.add(t), Ve(t, je(l)), qe(h, b, {
                                    fetcherSubmission: l
                                }));
                                if (Ee(b)) return void Ye(t, r, b.error)
                            }
                            if (Ce(b)) throw we(400, {
                                type: "defer-action"
                            });
                            let w = I.navigation.location || I.location,
                                S = de(e.history, w, p.signal),
                                x = u || g,
                                C = "idle" !== I.navigation.state ? f(x, I.navigation.location, v) : I.matches;
                            a(C, "Didn't find any matches after fetcher action");
                            let E = ++ee;
                            ne.set(t, E);
                            let T = je(l, b.data);
                            I.fetchers.set(t, T);
                            let [A, R] = te(e.history, I, C, l, w, !1, k.unstable_skipActionErrorRevalidation, U, H, q, he, pe, ae, x, v, [o.route.id, b]);
                            R.filter((e => e.key !== t)).forEach((e => {
                                let t = e.key,
                                    r = I.fetchers.get(t),
                                    n = je(void 0, r ? r.data : void 0);
                                I.fetchers.set(t, n), J.has(t) && Je(t), e.controller && J.set(t, e.controller)
                            })), We({
                                fetchers: new Map(I.fetchers)
                            });
                            let O = () => R.forEach((e => Je(e.key)));
                            p.signal.addEventListener("abort", O);
                            let {
                                loaderResults: P,
                                fetcherResults: F
                            } = await $e(I.matches, C, A, R, S);
                            if (p.signal.aborted) return;
                            p.signal.removeEventListener("abort", O), ne.delete(t), J.delete(t), R.forEach((e => J.delete(e.key)));
                            let D = ke([...P, ...F]);
                            if (D) {
                                if (D.idx >= A.length) {
                                    let e = R[D.idx - A.length].key;
                                    ae.add(e)
                                }
                                return qe(S, D.result)
                            }
                            let {
                                loaderData: j,
                                errors: L
                            } = me(I, I.matches, A, P, void 0, R, F, Se);
                            if (I.fetchers.has(t)) {
                                let e = Le(b.data);
                                I.fetchers.set(t, e)
                            }
                            et(E), "loading" === I.navigation.state && E > re ? (a(N, "Expected pending action"), M && M.abort(), ze(I.navigation.location, {
                                matches: C,
                                loaderData: j,
                                errors: L,
                                fetchers: new Map(I.fetchers)
                            })) : (We({
                                errors: L,
                                loaderData: ye(I.loaderData, j, C, L),
                                fetchers: new Map(I.fetchers)
                            }), U = !1)
                        }(t, r, p, y, _, d.active, s, h) : (pe.set(t, {
                            routeId: r,
                            path: p
                        }), async function(t, r, n, o, i, s, c, l) {
                            let u = I.fetchers.get(t);
                            Ve(t, je(l, u ? u.data : void 0), {
                                flushSync: c
                            });
                            let _ = new AbortController,
                                d = de(e.history, n, _.signal);
                            if (s) {
                                let e = await ut(i, n, d.signal);
                                if ("aborted" === e.type) return;
                                if ("error" === e.type) {
                                    let {
                                        error: o
                                    } = it(n, e);
                                    return void Ye(t, r, o, {
                                        flushSync: c
                                    })
                                }
                                if (!e.matches) return void Ye(t, r, we(404, {
                                    pathname: n
                                }), {
                                    flushSync: c
                                });
                                o = Ne(i = e.matches, n)
                            }
                            J.set(t, _);
                            let p = ee,
                                f = await Be("loader", d, [o], i),
                                h = f[0];
                            Ce(h) && (h = await Me(h, d.signal, !0) || h);
                            J.get(t) === _ && J.delete(t);
                            if (d.signal.aborted) return;
                            if (he.has(t)) return void Ve(t, Le(void 0));
                            if (Te(h)) return re > p ? void Ve(t, Le(void 0)) : (ae.add(t), void await qe(d, h));
                            if (Ee(h)) return void Ye(t, r, h.error);
                            a(!Ce(h), "Unhandled fetcher deferred data"), Ve(t, Le(h.data))
                        }(t, r, p, y, _, d.active, s, h))
                    },
                    revalidate: function() {
                        Ge(), We({
                            revalidation: "loading"
                        }), "submitting" !== I.navigation.state && ("idle" !== I.navigation.state ? Ue(N || I.historyAction, I.navigation.location, {
                            overrideNavigation: I.navigation
                        }) : Ue(I.historyAction, I.location, {
                            startUninterruptedRevalidation: !0
                        }))
                    },
                    createHref: t => e.history.createHref(t),
                    encodeLocation: t => e.history.encodeLocation(t),
                    getFetcher: Xe,
                    deleteFetcher: function(e) {
                        if (k.v7_fetcherPersist) {
                            let t = (fe.get(e) || 0) - 1;
                            t <= 0 ? (fe.delete(e), he.add(e)) : fe.set(e, t)
                        } else Ke(e);
                        We({
                            fetchers: new Map(I.fetchers)
                        })
                    },
                    dispose: function() {
                        S && S(), W && W(), x.clear(), M && M.abort(), I.fetchers.forEach(((e, t) => Ke(t))), I.blockers.forEach(((e, t) => tt(t)))
                    },
                    getBlocker: function(e, t) {
                        let r = I.blockers.get(e) || V;
                        return Ae.get(e) !== t && Ae.set(e, t), r
                    },
                    deleteBlocker: tt,
                    patchRoutes(e, t) {
                        return ie(e, t, g || u, y, l)
                    },
                    _internalFetchControllers: J,
                    _internalActiveDeferreds: Se,
                    _internalSetRoutes: function(e) {
                        y = {}, u = p(e, l, void 0, y)
                    }
                }, m
            }
            Symbol("deferred");

            function Q(e, t, r, n, o, i, a, s) {
                let c, u;
                if (a) {
                    c = [];
                    for (let e of t)
                        if (c.push(e), e.route.id === a) {
                            u = e;
                            break
                        }
                } else c = t, u = t[t.length - 1];
                let _ = I(o || ".", M(c, i), R(e.pathname, r) || e.pathname, "path" === s);
                return null == o && (_.search = e.search, _.hash = e.hash), null != o && "" !== o && "." !== o || !u || !u.route.index || Ie(_.search) || (_.search = _.search ? _.search.replace(/^\?/, "?index&") : "?index"), n && "/" !== r && (_.pathname = "/" === _.pathname ? r : N([r, _.pathname])), l(_)
            }

            function Z(e, t, r, n) {
                if (!n || ! function(e) {
                        return null != e && ("formData" in e && null != e.formData || "body" in e && void 0 !== e.body)
                    }(n)) return {
                    path: r
                };
                if (n.formMethod && !Re(n.formMethod)) return {
                    path: r,
                    error: we(405, {
                        method: n.formMethod
                    })
                };
                let o, i, s = () => ({
                        path: r,
                        error: we(400, {
                            type: "invalid-body"
                        })
                    }),
                    c = n.formMethod || "get",
                    _ = e ? c.toUpperCase() : c.toLowerCase(),
                    d = Se(r);
                if (void 0 !== n.body) {
                    if ("text/plain" === n.formEncType) {
                        if (!Oe(_)) return s();
                        let e = "string" == typeof n.body ? n.body : n.body instanceof FormData || n.body instanceof URLSearchParams ? Array.from(n.body.entries()).reduce(((e, t) => {
                            let [r, n] = t;
                            return "" + e + r + "=" + n + "\n"
                        }), "") : String(n.body);
                        return {
                            path: r,
                            submission: {
                                formMethod: _,
                                formAction: d,
                                formEncType: n.formEncType,
                                formData: void 0,
                                json: void 0,
                                text: e
                            }
                        }
                    }
                    if ("application/json" === n.formEncType) {
                        if (!Oe(_)) return s();
                        try {
                            let e = "string" == typeof n.body ? JSON.parse(n.body) : n.body;
                            return {
                                path: r,
                                submission: {
                                    formMethod: _,
                                    formAction: d,
                                    formEncType: n.formEncType,
                                    formData: void 0,
                                    json: e,
                                    text: void 0
                                }
                            }
                        } catch (e) {
                            return s()
                        }
                    }
                }
                if (a("function" == typeof FormData, "FormData is not available in this environment"), n.formData) o = pe(n.formData), i = n.formData;
                else if (n.body instanceof FormData) o = pe(n.body), i = n.body;
                else if (n.body instanceof URLSearchParams) o = n.body, i = fe(o);
                else if (null == n.body) o = new URLSearchParams, i = new FormData;
                else try {
                    o = new URLSearchParams(n.body), i = fe(o)
                } catch (e) {
                    return s()
                }
                let p = {
                    formMethod: _,
                    formAction: d,
                    formEncType: n && n.formEncType || "application/x-www-form-urlencoded",
                    formData: i,
                    json: void 0,
                    text: void 0
                };
                if (Oe(p.formMethod)) return {
                    path: r,
                    submission: p
                };
                let f = u(r);
                return t && f.search && Ie(f.search) && o.append("index", ""), f.search = "?" + o, {
                    path: l(f),
                    submission: p
                }
            }

            function ee(e, t) {
                let r = e;
                if (t) {
                    let n = e.findIndex((e => e.route.id === t));
                    n >= 0 && (r = e.slice(0, n))
                }
                return r
            }

            function te(e, t, r, o, i, a, s, c, l, u, _, d, p, h, m, y) {
                let g = y ? Ee(y[1]) ? y[1].error : y[1].data : void 0,
                    v = e.createURL(t.location),
                    b = e.createURL(i),
                    w = y && Ee(y[1]) ? y[0] : void 0,
                    k = w ? ee(r, w) : r,
                    S = y ? y[1].statusCode : void 0,
                    x = s && S && S >= 400,
                    C = k.filter(((e, r) => {
                        let {
                            route: i
                        } = e;
                        if (i.lazy) return !0;
                        if (null == i.loader) return !1;
                        if (a) return !("function" == typeof i.loader && !i.loader.hydrate) || void 0 === t.loaderData[i.id] && (!t.errors || void 0 === t.errors[i.id]);
                        if (function(e, t, r) {
                                let n = !t || r.route.id !== t.route.id,
                                    o = void 0 === e[r.route.id];
                                return n || o
                            }(t.loaderData, t.matches[r], e) || l.some((t => t === e.route.id))) return !0;
                        let s = t.matches[r],
                            u = e;
                        return ne(e, n({
                            currentUrl: v,
                            currentParams: s.params,
                            nextUrl: b,
                            nextParams: u.params
                        }, o, {
                            actionResult: g,
                            unstable_actionStatus: S,
                            defaultShouldRevalidate: !x && (c || v.pathname + v.search === b.pathname + b.search || v.search !== b.search || re(s, u))
                        }))
                    })),
                    E = [];
                return d.forEach(((e, i) => {
                    if (a || !r.some((t => t.route.id === e.routeId)) || _.has(i)) return;
                    let s = f(h, e.path, m);
                    if (!s) return void E.push({
                        key: i,
                        routeId: e.routeId,
                        path: e.path,
                        matches: null,
                        match: null,
                        controller: null
                    });
                    let l = t.fetchers.get(i),
                        d = Ne(s, e.path),
                        y = !1;
                    y = !p.has(i) && (!!u.includes(i) || (l && "idle" !== l.state && void 0 === l.data ? c : ne(d, n({
                        currentUrl: v,
                        currentParams: t.matches[t.matches.length - 1].params,
                        nextUrl: b,
                        nextParams: r[r.length - 1].params
                    }, o, {
                        actionResult: g,
                        unstable_actionStatus: S,
                        defaultShouldRevalidate: !x && c
                    })))), y && E.push({
                        key: i,
                        routeId: e.routeId,
                        path: e.path,
                        matches: s,
                        match: d,
                        controller: new AbortController
                    })
                })), [C, E]
            }

            function re(e, t) {
                let r = e.route.path;
                return e.pathname !== t.pathname || null != r && r.endsWith("*") && e.params["*"] !== t.params["*"]
            }

            function ne(e, t) {
                if (e.route.shouldRevalidate) {
                    let r = e.route.shouldRevalidate(t);
                    if ("boolean" == typeof r) return r
                }
                return t.defaultShouldRevalidate
            }
            async function oe(e, t, r, n, o, i, a, s) {
                let c = [t, ...r.map((e => e.route.id))].join("-");
                try {
                    let u = a.get(c);
                    u || (u = e({
                        path: t,
                        matches: r,
                        patch: (e, t) => {
                            s.aborted || ie(e, t, n, o, i)
                        }
                    }), a.set(c, u)), u && ("object" == typeof(l = u) && null != l && "then" in l) && await u
                } finally {
                    a.delete(c)
                }
                var l
            }

            function ie(e, t, r, n, o) {
                if (e) {
                    var i;
                    let r = n[e];
                    a(r, "No route found to patch children into: routeId = " + e);
                    let s = p(t, o, [e, "patch", String((null == (i = r.children) ? void 0 : i.length) || "0")], n);
                    r.children ? r.children.push(...s) : r.children = s
                } else {
                    let e = p(t, o, ["patch", String(r.length || "0")], n);
                    r.push(...e)
                }
            }
            async function ae(e, t, r) {
                if (!e.lazy) return;
                let o = await e.lazy();
                if (!e.lazy) return;
                let i = r[e.id];
                a(i, "No route found in manifest");
                let c = {};
                for (let e in o) {
                    let t = void 0 !== i[e] && "hasErrorBoundary" !== e;
                    s(!t, 'Route "' + i.id + '" has a static property "' + e + '" defined but its lazy function is also returning a value for this property. The lazy route property "' + e + '" will be ignored.'), t || d.has(e) || (c[e] = o[e])
                }
                Object.assign(i, c), Object.assign(i, n({}, t(i), {
                    lazy: void 0
                }))
            }

            function se(e) {
                return Promise.all(e.matches.map((e => e.resolve())))
            }
            async function ce(e, t, r, o, i, s, c, l) {
                let u = o.reduce(((e, t) => e.add(t.route.id)), new Set),
                    d = new Set,
                    p = await e({
                        matches: i.map((e => {
                            let o = u.has(e.route.id);
                            return n({}, e, {
                                shouldLoad: o,
                                resolve: n => (d.add(e.route.id), o ? async function(e, t, r, n, o, i, s) {
                                    let c, l, u = n => {
                                        let o, a = new Promise(((e, t) => o = t));
                                        l = () => o(), t.signal.addEventListener("abort", l);
                                        let c, u = o => "function" != typeof n ? Promise.reject(new Error('You cannot call the handler for a route which defines a boolean "' + e + '" [routeId: ' + r.route.id + "]")) : n({
                                            request: t,
                                            params: r.params,
                                            context: s
                                        }, ...void 0 !== o ? [o] : []);
                                        return c = i ? i((e => u(e))) : (async () => {
                                            try {
                                                return {
                                                    type: "data",
                                                    result: await u()
                                                }
                                            } catch (e) {
                                                return {
                                                    type: "error",
                                                    result: e
                                                }
                                            }
                                        })(), Promise.race([c, a])
                                    };
                                    try {
                                        let i = r.route[e];
                                        if (r.route.lazy)
                                            if (i) {
                                                let e, [t] = await Promise.all([u(i).catch((t => {
                                                    e = t
                                                })), ae(r.route, o, n)]);
                                                if (void 0 !== e) throw e;
                                                c = t
                                            } else {
                                                if (await ae(r.route, o, n), i = r.route[e], !i) {
                                                    if ("action" === e) {
                                                        let e = new URL(t.url),
                                                            n = e.pathname + e.search;
                                                        throw we(405, {
                                                            method: t.method,
                                                            pathname: n,
                                                            routeId: r.route.id
                                                        })
                                                    }
                                                    return {
                                                        type: _.data,
                                                        result: void 0
                                                    }
                                                }
                                                c = await u(i)
                                            }
                                        else {
                                            if (!i) {
                                                let e = new URL(t.url);
                                                throw we(404, {
                                                    pathname: e.pathname + e.search
                                                })
                                            }
                                            c = await u(i)
                                        }
                                        a(void 0 !== c.result, "You defined " + ("action" === e ? "an action" : "a loader") + ' for route "' + r.route.id + "\" but didn't return anything from your `" + e + "` function. Please return a value or `null`.")
                                    } catch (e) {
                                        return {
                                            type: _.error,
                                            result: e
                                        }
                                    } finally {
                                        l && t.signal.removeEventListener("abort", l)
                                    }
                                    return c
                                }(t, r, e, s, c, n, l) : Promise.resolve({
                                    type: _.data,
                                    result: void 0
                                }))
                            })
                        })),
                        request: r,
                        params: i[0].params,
                        context: l
                    });
                return i.forEach((e => a(d.has(e.route.id), '`match.resolve()` was not called for route id "' + e.route.id + '". You must call `match.resolve()` on every match passed to `dataStrategy` to ensure all routes are properly loaded.'))), p.filter(((e, t) => u.has(i[t].route.id)))
            }
            async function le(e) {
                let {
                    result: t,
                    type: r,
                    status: n
                } = e;
                if (Ae(t)) {
                    let e;
                    try {
                        let r = t.headers.get("Content-Type");
                        e = r && /\bapplication\/json\b/.test(r) ? null == t.body ? null : await t.json() : await t.text()
                    } catch (e) {
                        return {
                            type: _.error,
                            error: e
                        }
                    }
                    return r === _.error ? {
                        type: _.error,
                        error: new ErrorResponseImpl(t.status, t.statusText, e),
                        statusCode: t.status,
                        headers: t.headers
                    } : {
                        type: _.data,
                        data: e,
                        statusCode: t.status,
                        headers: t.headers
                    }
                }
                return r === _.error ? {
                    type: _.error,
                    error: t,
                    statusCode: L(t) ? t.status : n
                } : function(e) {
                    let t = e;
                    return t && "object" == typeof t && "object" == typeof t.data && "function" == typeof t.subscribe && "function" == typeof t.cancel && "function" == typeof t.resolveData
                }(t) ? {
                    type: _.deferred,
                    deferredData: t,
                    statusCode: null == (o = t.init) ? void 0 : o.status,
                    headers: (null == (i = t.init) ? void 0 : i.headers) && new Headers(t.init.headers)
                } : {
                    type: _.data,
                    data: t,
                    statusCode: n
                };
                var o, i
            }

            function ue(e, t, r, n, o, i) {
                let s = e.headers.get("Location");
                if (a(s, "Redirects returned/thrown from loaders/actions must have a Location header"), !Y.test(s)) {
                    let a = n.slice(0, n.findIndex((e => e.route.id === r)) + 1);
                    s = Q(new URL(t.url), a, o, !0, s, i), e.headers.set("Location", s)
                }
                return e
            }

            function _e(e, t, r) {
                if (Y.test(e)) {
                    let n = e,
                        o = n.startsWith("//") ? new URL(t.protocol + n) : new URL(n),
                        i = null != R(o.pathname, r);
                    if (o.origin === t.origin && i) return o.pathname + o.search + o.hash
                }
                return e
            }

            function de(e, t, r, n) {
                let o = e.createURL(Se(t)).toString(),
                    i = {
                        signal: r
                    };
                if (n && Oe(n.formMethod)) {
                    let {
                        formMethod: e,
                        formEncType: t
                    } = n;
                    i.method = e.toUpperCase(), "application/json" === t ? (i.headers = new Headers({
                        "Content-Type": t
                    }), i.body = JSON.stringify(n.json)) : "text/plain" === t ? i.body = n.text : "application/x-www-form-urlencoded" === t && n.formData ? i.body = pe(n.formData) : i.body = n.formData
                }
                return new Request(o, i)
            }

            function pe(e) {
                let t = new URLSearchParams;
                for (let [r, n] of e.entries()) t.append(r, "string" == typeof n ? n : n.name);
                return t
            }

            function fe(e) {
                let t = new FormData;
                for (let [r, n] of e.entries()) t.append(r, n);
                return t
            }

            function he(e, t, r, n, o, i) {
                let s, c = {},
                    l = null,
                    u = !1,
                    _ = {},
                    d = n && Ee(n[1]) ? n[1].error : void 0;
                return r.forEach(((r, n) => {
                    let p = t[n].route.id;
                    if (a(!Te(r), "Cannot handle redirect results in processLoaderData"), Ee(r)) {
                        let t = r.error;
                        if (void 0 !== d && (t = d, d = void 0), l = l || {}, i) l[p] = t;
                        else {
                            let r = ve(e, p);
                            null == l[r.route.id] && (l[r.route.id] = t)
                        }
                        c[p] = void 0, u || (u = !0, s = L(r.error) ? r.error.status : 500), r.headers && (_[p] = r.headers)
                    } else Ce(r) ? (o.set(p, r.deferredData), c[p] = r.deferredData.data, null == r.statusCode || 200 === r.statusCode || u || (s = r.statusCode), r.headers && (_[p] = r.headers)) : (c[p] = r.data, r.statusCode && 200 !== r.statusCode && !u && (s = r.statusCode), r.headers && (_[p] = r.headers))
                })), void 0 !== d && n && (l = {
                    [n[0]]: d
                }, c[n[0]] = void 0), {
                    loaderData: c,
                    errors: l,
                    statusCode: s || 200,
                    loaderHeaders: _
                }
            }

            function me(e, t, r, o, i, s, c, l) {
                let {
                    loaderData: u,
                    errors: _
                } = he(t, r, o, i, l, !1);
                for (let t = 0; t < s.length; t++) {
                    let {
                        key: r,
                        match: o,
                        controller: i
                    } = s[t];
                    a(void 0 !== c && void 0 !== c[t], "Did not find corresponding fetcher result");
                    let l = c[t];
                    if (!i || !i.signal.aborted)
                        if (Ee(l)) {
                            let t = ve(e.matches, null == o ? void 0 : o.route.id);
                            _ && _[t.route.id] || (_ = n({}, _, {
                                [t.route.id]: l.error
                            })), e.fetchers.delete(r)
                        } else if (Te(l)) a(!1, "Unhandled fetcher revalidation redirect");
                    else if (Ce(l)) a(!1, "Unhandled fetcher deferred data");
                    else {
                        let t = Le(l.data);
                        e.fetchers.set(r, t)
                    }
                }
                return {
                    loaderData: u,
                    errors: _
                }
            }

            function ye(e, t, r, o) {
                let i = n({}, t);
                for (let n of r) {
                    let r = n.route.id;
                    if (t.hasOwnProperty(r) ? void 0 !== t[r] && (i[r] = t[r]) : void 0 !== e[r] && n.route.loader && (i[r] = e[r]), o && o.hasOwnProperty(r)) break
                }
                return i
            }

            function ge(e) {
                return e ? Ee(e[1]) ? {
                    actionData: {}
                } : {
                    actionData: {
                        [e[0]]: e[1].data
                    }
                } : {}
            }

            function ve(e, t) {
                return (t ? e.slice(0, e.findIndex((e => e.route.id === t)) + 1) : [...e]).reverse().find((e => !0 === e.route.hasErrorBoundary)) || e[0]
            }

            function be(e) {
                let t = 1 === e.length ? e[0] : e.find((e => e.index || !e.path || "/" === e.path)) || {
                    id: "__shim-error-route__"
                };
                return {
                    matches: [{
                        params: {},
                        pathname: "",
                        pathnameBase: "",
                        route: t
                    }],
                    route: t
                }
            }

            function we(e, t) {
                let {
                    pathname: r,
                    routeId: n,
                    method: o,
                    type: i,
                    message: a
                } = void 0 === t ? {} : t, s = "Unknown Server Error", c = "Unknown @remix-run/router error";
                return 400 === e ? (s = "Bad Request", "route-discovery" === i ? c = 'Unable to match URL "' + r + '" - the `children()` function for route `' + n + "` threw the following error:\n" + a : o && r && n ? c = "You made a " + o + ' request to "' + r + '" but did not provide a `loader` for route "' + n + '", so there is no way to handle the request.' : "defer-action" === i ? c = "defer() is not supported in actions" : "invalid-body" === i && (c = "Unable to encode submission body")) : 403 === e ? (s = "Forbidden", c = 'Route "' + n + '" does not match URL "' + r + '"') : 404 === e ? (s = "Not Found", c = 'No route matches URL "' + r + '"') : 405 === e && (s = "Method Not Allowed", o && r && n ? c = "You made a " + o.toUpperCase() + ' request to "' + r + '" but did not provide an `action` for route "' + n + '", so there is no way to handle the request.' : o && (c = 'Invalid request method "' + o.toUpperCase() + '"')), new ErrorResponseImpl(e || 500, s, new Error(c), !0)
            }

            function ke(e) {
                for (let t = e.length - 1; t >= 0; t--) {
                    let r = e[t];
                    if (Te(r)) return {
                        result: r,
                        idx: t
                    }
                }
            }

            function Se(e) {
                return l(n({}, "string" == typeof e ? u(e) : e, {
                    hash: ""
                }))
            }

            function xe(e) {
                return Ae(e.result) && q.has(e.result.status)
            }

            function Ce(e) {
                return e.type === _.deferred
            }

            function Ee(e) {
                return e.type === _.error
            }

            function Te(e) {
                return (e && e.type) === _.redirect
            }

            function Ae(e) {
                return null != e && "number" == typeof e.status && "string" == typeof e.statusText && "object" == typeof e.headers && void 0 !== e.body
            }

            function Re(e) {
                return H.has(e.toLowerCase())
            }

            function Oe(e) {
                return z.has(e.toLowerCase())
            }
            async function Pe(e, t, r, n, o, i) {
                for (let s = 0; s < r.length; s++) {
                    let c = r[s],
                        l = t[s];
                    if (!l) continue;
                    let u = e.find((e => e.route.id === l.route.id)),
                        _ = null != u && !re(u, l) && void 0 !== (i && i[l.route.id]);
                    if (Ce(c) && (o || _)) {
                        let e = n[s];
                        a(e, "Expected an AbortSignal for revalidating fetcher deferred result"), await Me(c, e, o).then((e => {
                            e && (r[s] = e || r[s])
                        }))
                    }
                }
            }
            async function Me(e, t, r) {
                if (void 0 === r && (r = !1), !await e.deferredData.resolveData(t)) {
                    if (r) try {
                        return {
                            type: _.data,
                            data: e.deferredData.unwrappedData
                        }
                    } catch (e) {
                        return {
                            type: _.error,
                            error: e
                        }
                    }
                    return {
                        type: _.data,
                        data: e.deferredData.data
                    }
                }
            }

            function Ie(e) {
                return new URLSearchParams(e).getAll("index").some((e => "" === e))
            }

            function Ne(e, t) {
                let r = "string" == typeof t ? u(t).search : t.search;
                if (e[e.length - 1].route.index && Ie(r || "")) return e[e.length - 1];
                let n = P(e);
                return n[n.length - 1]
            }

            function Fe(e) {
                let {
                    formMethod: t,
                    formAction: r,
                    formEncType: n,
                    text: o,
                    formData: i,
                    json: a
                } = e;
                if (t && r && n) return null != o ? {
                    formMethod: t,
                    formAction: r,
                    formEncType: n,
                    formData: void 0,
                    json: void 0,
                    text: o
                } : null != i ? {
                    formMethod: t,
                    formAction: r,
                    formEncType: n,
                    formData: i,
                    json: void 0,
                    text: void 0
                } : void 0 !== a ? {
                    formMethod: t,
                    formAction: r,
                    formEncType: n,
                    formData: void 0,
                    json: a,
                    text: void 0
                } : void 0
            }

            function De(e, t) {
                if (t) {
                    return {
                        state: "loading",
                        location: e,
                        formMethod: t.formMethod,
                        formAction: t.formAction,
                        formEncType: t.formEncType,
                        formData: t.formData,
                        json: t.json,
                        text: t.text
                    }
                }
                return {
                    state: "loading",
                    location: e,
                    formMethod: void 0,
                    formAction: void 0,
                    formEncType: void 0,
                    formData: void 0,
                    json: void 0,
                    text: void 0
                }
            }

            function je(e, t) {
                if (e) {
                    return {
                        state: "loading",
                        formMethod: e.formMethod,
                        formAction: e.formAction,
                        formEncType: e.formEncType,
                        formData: e.formData,
                        json: e.json,
                        text: e.text,
                        data: t
                    }
                }
                return {
                    state: "loading",
                    formMethod: void 0,
                    formAction: void 0,
                    formEncType: void 0,
                    formData: void 0,
                    json: void 0,
                    text: void 0,
                    data: t
                }
            }

            function Le(e) {
                return {
                    state: "idle",
                    formMethod: void 0,
                    formAction: void 0,
                    formEncType: void 0,
                    formData: void 0,
                    json: void 0,
                    text: void 0,
                    data: e
                }
            }
        },
        17336: (e, t, r) => {
            var n = r(75617);
            e.exports = function(e, t) {
                return new Promise((function(r, o) {
                    var i, a = t || {};

                    function s(e) {
                        o(e || new Error("Aborted"))
                    }

                    function c(e, t) {
                        e.bail ? s(e) : i.retry(e) ? a.onRetry && a.onRetry(e, t) : o(i.mainError())
                    }
                    "randomize" in a || (a.randomize = !0), (i = n.operation(a)).attempt((function(t) {
                        var n;
                        try {
                            n = e(s, t)
                        } catch (e) {
                            return void c(e, t)
                        }
                        Promise.resolve(n).then(r).catch((function(e) {
                            c(e, t)
                        }))
                    }))
                }))
            }
        },
        24601: (e, t, r) => {
            "use strict";
            var n = r(78420),
                o = r(13838),
                i = TypeError;
            e.exports = function(e) {
                if (n(e)) return e;
                throw i(o(e) + " is not a function")
            }
        },
        7473: (e, t, r) => {
            "use strict";
            var n = r(78420),
                o = String,
                i = TypeError;
            e.exports = function(e) {
                if ("object" == typeof e || n(e)) return e;
                throw i("Can't set " + o(e) + " as a prototype")
            }
        },
        65190: (e, t, r) => {
            "use strict";
            var n = r(47658),
                o = TypeError;
            e.exports = function(e, t) {
                if (n(t, e)) return e;
                throw o("Incorrect invocation")
            }
        },
        73938: (e, t, r) => {
            "use strict";
            var n = r(65335),
                o = String,
                i = TypeError;
            e.exports = function(e) {
                if (n(e)) return e;
                throw i(o(e) + " is not an object")
            }
        },
        58186: (e, t, r) => {
            "use strict";
            var n = r(5476),
                o = r(6539),
                i = r(23493),
                a = function(e) {
                    return function(t, r, a) {
                        var s, c = n(t),
                            l = i(c),
                            u = o(a, l);
                        if (e && r != r) {
                            for (; l > u;)
                                if ((s = c[u++]) != s) return !0
                        } else
                            for (; l > u; u++)
                                if ((e || u in c) && c[u] === r) return e || u || 0;
                        return !e && -1
                    }
                };
            e.exports = {
                includes: a(!0),
                indexOf: a(!1)
            }
        },
        18569: (e, t, r) => {
            "use strict";
            var n = r(30281),
                o = n({}.toString),
                i = n("".slice);
            e.exports = function(e) {
                return i(o(e), 8, -1)
            }
        },
        83062: (e, t, r) => {
            "use strict";
            var n = r(43129),
                o = r(78420),
                i = r(18569),
                a = r(31602)("toStringTag"),
                s = Object,
                c = "Arguments" === i(function() {
                    return arguments
                }());
            e.exports = n ? i : function(e) {
                var t, r, n;
                return void 0 === e ? "Undefined" : null === e ? "Null" : "string" == typeof(r = function(e, t) {
                    try {
                        return e[t]
                    } catch (e) {}
                }(t = s(e), a)) ? r : c ? i(t) : "Object" === (n = i(t)) && o(t.callee) ? "Arguments" : n
            }
        },
        84361: (e, t, r) => {
            "use strict";
            var n = r(36490),
                o = r(15816),
                i = r(97632),
                a = r(43610);
            e.exports = function(e, t, r) {
                for (var s = o(t), c = a.f, l = i.f, u = 0; u < s.length; u++) {
                    var _ = s[u];
                    n(e, _) || r && n(r, _) || c(e, _, l(t, _))
                }
            }
        },
        97712: (e, t, r) => {
            "use strict";
            var n = r(65077),
                o = r(43610),
                i = r(66843);
            e.exports = n ? function(e, t, r) {
                return o.f(e, t, i(1, r))
            } : function(e, t, r) {
                return e[t] = r, e
            }
        },
        66843: e => {
            "use strict";
            e.exports = function(e, t) {
                return {
                    enumerable: !(1 & e),
                    configurable: !(2 & e),
                    writable: !(4 & e),
                    value: t
                }
            }
        },
        7485: (e, t, r) => {
            "use strict";
            var n = r(78420),
                o = r(43610),
                i = r(48218),
                a = r(59430);
            e.exports = function(e, t, r, s) {
                s || (s = {});
                var c = s.enumerable,
                    l = void 0 !== s.name ? s.name : t;
                if (n(r) && i(r, l, s), s.global) c ? e[t] = r : a(t, r);
                else {
                    try {
                        s.unsafe ? e[t] && (c = !0) : delete e[t]
                    } catch (e) {}
                    c ? e[t] = r : o.f(e, t, {
                        value: r,
                        enumerable: !1,
                        configurable: !s.nonConfigurable,
                        writable: !s.nonWritable
                    })
                }
                return e
            }
        },
        59430: (e, t, r) => {
            "use strict";
            var n = r(30200),
                o = Object.defineProperty;
            e.exports = function(e, t) {
                try {
                    o(n, e, {
                        value: t,
                        configurable: !0,
                        writable: !0
                    })
                } catch (r) {
                    n[e] = t
                }
                return t
            }
        },
        65077: (e, t, r) => {
            "use strict";
            var n = r(92074);
            e.exports = !n((function() {
                return 7 !== Object.defineProperty({}, 1, {
                    get: function() {
                        return 7
                    }
                })[1]
            }))
        },
        96568: e => {
            "use strict";
            var t = "object" == typeof document && document.all,
                r = void 0 === t && void 0 !== t;
            e.exports = {
                all: t,
                IS_HTMLDDA: r
            }
        },
        23262: (e, t, r) => {
            "use strict";
            var n = r(30200),
                o = r(65335),
                i = n.document,
                a = o(i) && o(i.createElement);
            e.exports = function(e) {
                return a ? i.createElement(e) : {}
            }
        },
        26567: e => {
            "use strict";
            e.exports = {
                IndexSizeError: {
                    s: "INDEX_SIZE_ERR",
                    c: 1,
                    m: 1
                },
                DOMStringSizeError: {
                    s: "DOMSTRING_SIZE_ERR",
                    c: 2,
                    m: 0
                },
                HierarchyRequestError: {
                    s: "HIERARCHY_REQUEST_ERR",
                    c: 3,
                    m: 1
                },
                WrongDocumentError: {
                    s: "WRONG_DOCUMENT_ERR",
                    c: 4,
                    m: 1
                },
                InvalidCharacterError: {
                    s: "INVALID_CHARACTER_ERR",
                    c: 5,
                    m: 1
                },
                NoDataAllowedError: {
                    s: "NO_DATA_ALLOWED_ERR",
                    c: 6,
                    m: 0
                },
                NoModificationAllowedError: {
                    s: "NO_MODIFICATION_ALLOWED_ERR",
                    c: 7,
                    m: 1
                },
                NotFoundError: {
                    s: "NOT_FOUND_ERR",
                    c: 8,
                    m: 1
                },
                NotSupportedError: {
                    s: "NOT_SUPPORTED_ERR",
                    c: 9,
                    m: 1
                },
                InUseAttributeError: {
                    s: "INUSE_ATTRIBUTE_ERR",
                    c: 10,
                    m: 1
                },
                InvalidStateError: {
                    s: "INVALID_STATE_ERR",
                    c: 11,
                    m: 1
                },
                SyntaxError: {
                    s: "SYNTAX_ERR",
                    c: 12,
                    m: 1
                },
                InvalidModificationError: {
                    s: "INVALID_MODIFICATION_ERR",
                    c: 13,
                    m: 1
                },
                NamespaceError: {
                    s: "NAMESPACE_ERR",
                    c: 14,
                    m: 1
                },
                InvalidAccessError: {
                    s: "INVALID_ACCESS_ERR",
                    c: 15,
                    m: 1
                },
                ValidationError: {
                    s: "VALIDATION_ERR",
                    c: 16,
                    m: 0
                },
                TypeMismatchError: {
                    s: "TYPE_MISMATCH_ERR",
                    c: 17,
                    m: 1
                },
                SecurityError: {
                    s: "SECURITY_ERR",
                    c: 18,
                    m: 1
                },
                NetworkError: {
                    s: "NETWORK_ERR",
                    c: 19,
                    m: 1
                },
                AbortError: {
                    s: "ABORT_ERR",
                    c: 20,
                    m: 1
                },
                URLMismatchError: {
                    s: "URL_MISMATCH_ERR",
                    c: 21,
                    m: 1
                },
                QuotaExceededError: {
                    s: "QUOTA_EXCEEDED_ERR",
                    c: 22,
                    m: 1
                },
                TimeoutError: {
                    s: "TIMEOUT_ERR",
                    c: 23,
                    m: 1
                },
                InvalidNodeTypeError: {
                    s: "INVALID_NODE_TYPE_ERR",
                    c: 24,
                    m: 1
                },
                DataCloneError: {
                    s: "DATA_CLONE_ERR",
                    c: 25,
                    m: 1
                }
            }
        },
        47061: e => {
            "use strict";
            e.exports = "undefined" != typeof navigator && String(navigator.userAgent) || ""
        },
        6845: (e, t, r) => {
            "use strict";
            var n, o, i = r(30200),
                a = r(47061),
                s = i.process,
                c = i.Deno,
                l = s && s.versions || c && c.version,
                u = l && l.v8;
            u && (o = (n = u.split("."))[0] > 0 && n[0] < 4 ? 1 : +(n[0] + n[1])), !o && a && (!(n = a.match(/Edge\/(\d+)/)) || n[1] >= 74) && (n = a.match(/Chrome\/(\d+)/)) && (o = +n[1]), e.exports = o
        },
        30290: e => {
            "use strict";
            e.exports = ["constructor", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toLocaleString", "toString", "valueOf"]
        },
        46452: (e, t, r) => {
            "use strict";
            var n = r(30281),
                o = Error,
                i = n("".replace),
                a = String(o("zxcasd").stack),
                s = /\n\s*at [^:]*:[^\n]*/,
                c = s.test(a);
            e.exports = function(e, t) {
                if (c && "string" == typeof e && !o.prepareStackTrace)
                    for (; t--;) e = i(e, s, "");
                return e
            }
        },
        51605: (e, t, r) => {
            "use strict";
            var n = r(30200),
                o = r(97632).f,
                i = r(97712),
                a = r(7485),
                s = r(59430),
                c = r(84361),
                l = r(84977);
            e.exports = function(e, t) {
                var r, u, _, d, p, f = e.target,
                    h = e.global,
                    m = e.stat;
                if (r = h ? n : m ? n[f] || s(f, {}) : (n[f] || {}).prototype)
                    for (u in t) {
                        if (d = t[u], _ = e.dontCallGetSet ? (p = o(r, u)) && p.value : r[u], !l(h ? u : f + (m ? "." : "#") + u, e.forced) && void 0 !== _) {
                            if (typeof d == typeof _) continue;
                            c(d, _)
                        }(e.sham || _ && _.sham) && i(d, "sham", !0), a(r, u, d, e)
                    }
            }
        },
        92074: e => {
            "use strict";
            e.exports = function(e) {
                try {
                    return !!e()
                } catch (e) {
                    return !0
                }
            }
        },
        38823: (e, t, r) => {
            "use strict";
            var n = r(92074);
            e.exports = !n((function() {
                var e = function() {}.bind();
                return "function" != typeof e || e.hasOwnProperty("prototype")
            }))
        },
        72368: (e, t, r) => {
            "use strict";
            var n = r(38823),
                o = Function.prototype.call;
            e.exports = n ? o.bind(o) : function() {
                return o.apply(o, arguments)
            }
        },
        12071: (e, t, r) => {
            "use strict";
            var n = r(65077),
                o = r(36490),
                i = Function.prototype,
                a = n && Object.getOwnPropertyDescriptor,
                s = o(i, "name"),
                c = s && "something" === function() {}.name,
                l = s && (!n || n && a(i, "name").configurable);
            e.exports = {
                EXISTS: s,
                PROPER: c,
                CONFIGURABLE: l
            }
        },
        11385: (e, t, r) => {
            "use strict";
            var n = r(30281),
                o = r(24601);
            e.exports = function(e, t, r) {
                try {
                    return n(o(Object.getOwnPropertyDescriptor(e, t)[r]))
                } catch (e) {}
            }
        },
        30281: (e, t, r) => {
            "use strict";
            var n = r(38823),
                o = Function.prototype,
                i = o.call,
                a = n && o.bind.bind(i, i);
            e.exports = n ? a : function(e) {
                return function() {
                    return i.apply(e, arguments)
                }
            }
        },
        56492: (e, t, r) => {
            "use strict";
            var n = r(30200),
                o = r(78420);
            e.exports = function(e, t) {
                return arguments.length < 2 ? (r = n[e], o(r) ? r : void 0) : n[e] && n[e][t];
                var r
            }
        },
        46457: (e, t, r) => {
            "use strict";
            var n = r(24601),
                o = r(88406);
            e.exports = function(e, t) {
                var r = e[t];
                return o(r) ? void 0 : n(r)
            }
        },
        30200: function(e, t, r) {
            "use strict";
            var n = function(e) {
                return e && e.Math === Math && e
            };
            e.exports = n("object" == typeof globalThis && globalThis) || n("object" == typeof window && window) || n("object" == typeof self && self) || n("object" == typeof r.g && r.g) || function() {
                return this
            }() || this || Function("return this")()
        },
        36490: (e, t, r) => {
            "use strict";
            var n = r(30281),
                o = r(92612),
                i = n({}.hasOwnProperty);
            e.exports = Object.hasOwn || function(e, t) {
                return i(o(e), t)
            }
        },
        67708: e => {
            "use strict";
            e.exports = {}
        },
        87694: (e, t, r) => {
            "use strict";
            var n = r(65077),
                o = r(92074),
                i = r(23262);
            e.exports = !n && !o((function() {
                return 7 !== Object.defineProperty(i("div"), "a", {
                    get: function() {
                        return 7
                    }
                }).a
            }))
        },
        48664: (e, t, r) => {
            "use strict";
            var n = r(30281),
                o = r(92074),
                i = r(18569),
                a = Object,
                s = n("".split);
            e.exports = o((function() {
                return !a("z").propertyIsEnumerable(0)
            })) ? function(e) {
                return "String" === i(e) ? s(e, "") : a(e)
            } : a
        },
        93054: (e, t, r) => {
            "use strict";
            var n = r(78420),
                o = r(65335),
                i = r(39686);
            e.exports = function(e, t, r) {
                var a, s;
                return i && n(a = t.constructor) && a !== r && o(s = a.prototype) && s !== r.prototype && i(e, s), e
            }
        },
        69965: (e, t, r) => {
            "use strict";
            var n = r(30281),
                o = r(78420),
                i = r(49310),
                a = n(Function.toString);
            o(i.inspectSource) || (i.inspectSource = function(e) {
                return a(e)
            }), e.exports = i.inspectSource
        },
        99206: (e, t, r) => {
            "use strict";
            var n, o, i, a = r(8369),
                s = r(30200),
                c = r(65335),
                l = r(97712),
                u = r(36490),
                _ = r(49310),
                d = r(25904),
                p = r(67708),
                f = "Object already initialized",
                h = s.TypeError,
                m = s.WeakMap;
            if (a || _.state) {
                var y = _.state || (_.state = new m);
                y.get = y.get, y.has = y.has, y.set = y.set, n = function(e, t) {
                    if (y.has(e)) throw h(f);
                    return t.facade = e, y.set(e, t), t
                }, o = function(e) {
                    return y.get(e) || {}
                }, i = function(e) {
                    return y.has(e)
                }
            } else {
                var g = d("state");
                p[g] = !0, n = function(e, t) {
                    if (u(e, g)) throw h(f);
                    return t.facade = e, l(e, g, t), t
                }, o = function(e) {
                    return u(e, g) ? e[g] : {}
                }, i = function(e) {
                    return u(e, g)
                }
            }
            e.exports = {
                set: n,
                get: o,
                has: i,
                enforce: function(e) {
                    return i(e) ? o(e) : n(e, {})
                },
                getterFor: function(e) {
                    return function(t) {
                        var r;
                        if (!c(t) || (r = o(t)).type !== e) throw h("Incompatible receiver, " + e + " required");
                        return r
                    }
                }
            }
        },
        78420: (e, t, r) => {
            "use strict";
            var n = r(96568),
                o = n.all;
            e.exports = n.IS_HTMLDDA ? function(e) {
                return "function" == typeof e || e === o
            } : function(e) {
                return "function" == typeof e
            }
        },
        84977: (e, t, r) => {
            "use strict";
            var n = r(92074),
                o = r(78420),
                i = /#|\.prototype\./,
                a = function(e, t) {
                    var r = c[s(e)];
                    return r === u || r !== l && (o(t) ? n(t) : !!t)
                },
                s = a.normalize = function(e) {
                    return String(e).replace(i, ".").toLowerCase()
                },
                c = a.data = {},
                l = a.NATIVE = "N",
                u = a.POLYFILL = "P";
            e.exports = a
        },
        88406: e => {
            "use strict";
            e.exports = function(e) {
                return null == e
            }
        },
        65335: (e, t, r) => {
            "use strict";
            var n = r(78420),
                o = r(96568),
                i = o.all;
            e.exports = o.IS_HTMLDDA ? function(e) {
                return "object" == typeof e ? null !== e : n(e) || e === i
            } : function(e) {
                return "object" == typeof e ? null !== e : n(e)
            }
        },
        6926: e => {
            "use strict";
            e.exports = !1
        },
        32328: (e, t, r) => {
            "use strict";
            var n = r(56492),
                o = r(78420),
                i = r(47658),
                a = r(5225),
                s = Object;
            e.exports = a ? function(e) {
                return "symbol" == typeof e
            } : function(e) {
                var t = n("Symbol");
                return o(t) && i(t.prototype, s(e))
            }
        },
        23493: (e, t, r) => {
            "use strict";
            var n = r(33747);
            e.exports = function(e) {
                return n(e.length)
            }
        },
        48218: (e, t, r) => {
            "use strict";
            var n = r(30281),
                o = r(92074),
                i = r(78420),
                a = r(36490),
                s = r(65077),
                c = r(12071).CONFIGURABLE,
                l = r(69965),
                u = r(99206),
                _ = u.enforce,
                d = u.get,
                p = String,
                f = Object.defineProperty,
                h = n("".slice),
                m = n("".replace),
                y = n([].join),
                g = s && !o((function() {
                    return 8 !== f((function() {}), "length", {
                        value: 8
                    }).length
                })),
                v = String(String).split("String"),
                b = e.exports = function(e, t, r) {
                    "Symbol(" === h(p(t), 0, 7) && (t = "[" + m(p(t), /^Symbol\(([^)]*)\)/, "$1") + "]"), r && r.getter && (t = "get " + t), r && r.setter && (t = "set " + t), (!a(e, "name") || c && e.name !== t) && (s ? f(e, "name", {
                        value: t,
                        configurable: !0
                    }) : e.name = t), g && r && a(r, "arity") && e.length !== r.arity && f(e, "length", {
                        value: r.arity
                    });
                    try {
                        r && a(r, "constructor") && r.constructor ? s && f(e, "prototype", {
                            writable: !1
                        }) : e.prototype && (e.prototype = void 0)
                    } catch (e) {}
                    var n = _(e);
                    return a(n, "source") || (n.source = y(v, "string" == typeof t ? t : "")), e
                };
            Function.prototype.toString = b((function() {
                return i(this) && d(this).source || l(this)
            }), "toString")
        },
        19830: e => {
            "use strict";
            var t = Math.ceil,
                r = Math.floor;
            e.exports = Math.trunc || function(e) {
                var n = +e;
                return (n > 0 ? r : t)(n)
            }
        },
        20610: (e, t, r) => {
            "use strict";
            var n = r(95362);
            e.exports = function(e, t) {
                return void 0 === e ? arguments.length < 2 ? "" : t : n(e)
            }
        },
        43610: (e, t, r) => {
            "use strict";
            var n = r(65077),
                o = r(87694),
                i = r(94491),
                a = r(73938),
                s = r(86032),
                c = TypeError,
                l = Object.defineProperty,
                u = Object.getOwnPropertyDescriptor,
                _ = "enumerable",
                d = "configurable",
                p = "writable";
            t.f = n ? i ? function(e, t, r) {
                if (a(e), t = s(t), a(r), "function" == typeof e && "prototype" === t && "value" in r && p in r && !r[p]) {
                    var n = u(e, t);
                    n && n[p] && (e[t] = r.value, r = {
                        configurable: d in r ? r[d] : n[d],
                        enumerable: _ in r ? r[_] : n[_],
                        writable: !1
                    })
                }
                return l(e, t, r)
            } : l : function(e, t, r) {
                if (a(e), t = s(t), a(r), o) try {
                    return l(e, t, r)
                } catch (e) {}
                if ("get" in r || "set" in r) throw c("Accessors not supported");
                return "value" in r && (e[t] = r.value), e
            }
        },
        97632: (e, t, r) => {
            "use strict";
            var n = r(65077),
                o = r(72368),
                i = r(9304),
                a = r(66843),
                s = r(5476),
                c = r(86032),
                l = r(36490),
                u = r(87694),
                _ = Object.getOwnPropertyDescriptor;
            t.f = n ? _ : function(e, t) {
                if (e = s(e), t = c(t), u) try {
                    return _(e, t)
                } catch (e) {}
                if (l(e, t)) return a(!o(i.f, e, t), e[t])
            }
        },
        64789: (e, t, r) => {
            "use strict";
            var n = r(16347),
                o = r(30290).concat("length", "prototype");
            t.f = Object.getOwnPropertyNames || function(e) {
                return n(e, o)
            }
        },
        18916: (e, t) => {
            "use strict";
            t.f = Object.getOwnPropertySymbols
        },
        47658: (e, t, r) => {
            "use strict";
            var n = r(30281);
            e.exports = n({}.isPrototypeOf)
        },
        16347: (e, t, r) => {
            "use strict";
            var n = r(30281),
                o = r(36490),
                i = r(5476),
                a = r(58186).indexOf,
                s = r(67708),
                c = n([].push);
            e.exports = function(e, t) {
                var r, n = i(e),
                    l = 0,
                    u = [];
                for (r in n) !o(s, r) && o(n, r) && c(u, r);
                for (; t.length > l;) o(n, r = t[l++]) && (~a(u, r) || c(u, r));
                return u
            }
        },
        9304: (e, t) => {
            "use strict";
            var r = {}.propertyIsEnumerable,
                n = Object.getOwnPropertyDescriptor,
                o = n && !r.call({
                    1: 2
                }, 1);
            t.f = o ? function(e) {
                var t = n(this, e);
                return !!t && t.enumerable
            } : r
        },
        39686: (e, t, r) => {
            "use strict";
            var n = r(11385),
                o = r(73938),
                i = r(7473);
            e.exports = Object.setPrototypeOf || ("__proto__" in {} ? function() {
                var e, t = !1,
                    r = {};
                try {
                    (e = n(Object.prototype, "__proto__", "set"))(r, []), t = r instanceof Array
                } catch (e) {}
                return function(r, n) {
                    return o(r), i(n), t ? e(r, n) : r.__proto__ = n, r
                }
            }() : void 0)
        },
        69751: (e, t, r) => {
            "use strict";
            var n = r(72368),
                o = r(78420),
                i = r(65335),
                a = TypeError;
            e.exports = function(e, t) {
                var r, s;
                if ("string" === t && o(r = e.toString) && !i(s = n(r, e))) return s;
                if (o(r = e.valueOf) && !i(s = n(r, e))) return s;
                if ("string" !== t && o(r = e.toString) && !i(s = n(r, e))) return s;
                throw a("Can't convert object to primitive value")
            }
        },
        15816: (e, t, r) => {
            "use strict";
            var n = r(56492),
                o = r(30281),
                i = r(64789),
                a = r(18916),
                s = r(73938),
                c = o([].concat);
            e.exports = n("Reflect", "ownKeys") || function(e) {
                var t = i.f(s(e)),
                    r = a.f;
                return r ? c(t, r(e)) : t
            }
        },
        71229: (e, t, r) => {
            "use strict";
            var n = r(88406),
                o = TypeError;
            e.exports = function(e) {
                if (n(e)) throw o("Can't call method on " + e);
                return e
            }
        },
        25904: (e, t, r) => {
            "use strict";
            var n = r(50002),
                o = r(50665),
                i = n("keys");
            e.exports = function(e) {
                return i[e] || (i[e] = o(e))
            }
        },
        49310: (e, t, r) => {
            "use strict";
            var n = r(30200),
                o = r(59430),
                i = "__core-js_shared__",
                a = n[i] || o(i, {});
            e.exports = a
        },
        50002: (e, t, r) => {
            "use strict";
            var n = r(6926),
                o = r(49310);
            (e.exports = function(e, t) {
                return o[e] || (o[e] = void 0 !== t ? t : {})
            })("versions", []).push({
                version: "3.32.1",
                mode: n ? "pure" : "global",
                copyright: "© 2014-2023 Denis Pushkarev (zloirock.ru)",
                license: "https://github.com/zloirock/core-js/blob/v3.32.1/LICENSE",
                source: "https://github.com/zloirock/core-js"
            })
        },
        82072: (e, t, r) => {
            "use strict";
            var n = r(6845),
                o = r(92074),
                i = r(30200).String;
            e.exports = !!Object.getOwnPropertySymbols && !o((function() {
                var e = Symbol("symbol detection");
                return !i(e) || !(Object(e) instanceof Symbol) || !Symbol.sham && n && n < 41
            }))
        },
        6539: (e, t, r) => {
            "use strict";
            var n = r(79328),
                o = Math.max,
                i = Math.min;
            e.exports = function(e, t) {
                var r = n(e);
                return r < 0 ? o(r + t, 0) : i(r, t)
            }
        },
        5476: (e, t, r) => {
            "use strict";
            var n = r(48664),
                o = r(71229);
            e.exports = function(e) {
                return n(o(e))
            }
        },
        79328: (e, t, r) => {
            "use strict";
            var n = r(19830);
            e.exports = function(e) {
                var t = +e;
                return t != t || 0 === t ? 0 : n(t)
            }
        },
        33747: (e, t, r) => {
            "use strict";
            var n = r(79328),
                o = Math.min;
            e.exports = function(e) {
                return e > 0 ? o(n(e), 9007199254740991) : 0
            }
        },
        92612: (e, t, r) => {
            "use strict";
            var n = r(71229),
                o = Object;
            e.exports = function(e) {
                return o(n(e))
            }
        },
        50874: (e, t, r) => {
            "use strict";
            var n = r(72368),
                o = r(65335),
                i = r(32328),
                a = r(46457),
                s = r(69751),
                c = r(31602),
                l = TypeError,
                u = c("toPrimitive");
            e.exports = function(e, t) {
                if (!o(e) || i(e)) return e;
                var r, c = a(e, u);
                if (c) {
                    if (void 0 === t && (t = "default"), r = n(c, e, t), !o(r) || i(r)) return r;
                    throw l("Can't convert object to primitive value")
                }
                return void 0 === t && (t = "number"), s(e, t)
            }
        },
        86032: (e, t, r) => {
            "use strict";
            var n = r(50874),
                o = r(32328);
            e.exports = function(e) {
                var t = n(e, "string");
                return o(t) ? t : t + ""
            }
        },
        43129: (e, t, r) => {
            "use strict";
            var n = {};
            n[r(31602)("toStringTag")] = "z", e.exports = "[object z]" === String(n)
        },
        95362: (e, t, r) => {
            "use strict";
            var n = r(83062),
                o = String;
            e.exports = function(e) {
                if ("Symbol" === n(e)) throw TypeError("Cannot convert a Symbol value to a string");
                return o(e)
            }
        },
        13838: e => {
            "use strict";
            var t = String;
            e.exports = function(e) {
                try {
                    return t(e)
                } catch (e) {
                    return "Object"
                }
            }
        },
        50665: (e, t, r) => {
            "use strict";
            var n = r(30281),
                o = 0,
                i = Math.random(),
                a = n(1..toString);
            e.exports = function(e) {
                return "Symbol(" + (void 0 === e ? "" : e) + ")_" + a(++o + i, 36)
            }
        },
        5225: (e, t, r) => {
            "use strict";
            var n = r(82072);
            e.exports = n && !Symbol.sham && "symbol" == typeof Symbol.iterator
        },
        94491: (e, t, r) => {
            "use strict";
            var n = r(65077),
                o = r(92074);
            e.exports = n && o((function() {
                return 42 !== Object.defineProperty((function() {}), "prototype", {
                    value: 42,
                    writable: !1
                }).prototype
            }))
        },
        8369: (e, t, r) => {
            "use strict";
            var n = r(30200),
                o = r(78420),
                i = n.WeakMap;
            e.exports = o(i) && /native code/.test(String(i))
        },
        31602: (e, t, r) => {
            "use strict";
            var n = r(30200),
                o = r(50002),
                i = r(36490),
                a = r(50665),
                s = r(82072),
                c = r(5225),
                l = n.Symbol,
                u = o("wks"),
                _ = c ? l.for || l : l && l.withoutSetter || a;
            e.exports = function(e) {
                return i(u, e) || (u[e] = s && i(l, e) ? l[e] : _("Symbol." + e)), u[e]
            }
        },
        99078: (e, t, r) => {
            "use strict";
            var n = r(51605),
                o = r(30200),
                i = r(56492),
                a = r(66843),
                s = r(43610).f,
                c = r(36490),
                l = r(65190),
                u = r(93054),
                _ = r(20610),
                d = r(26567),
                p = r(46452),
                f = r(65077),
                h = r(6926),
                m = "DOMException",
                y = i("Error"),
                g = i(m),
                v = function() {
                    l(this, b);
                    var e = arguments.length,
                        t = _(e < 1 ? void 0 : arguments[0]),
                        r = _(e < 2 ? void 0 : arguments[1], "Error"),
                        n = new g(t, r),
                        o = y(t);
                    return o.name = m, s(n, "stack", a(1, p(o.stack, 1))), u(n, this, v), n
                },
                b = v.prototype = g.prototype,
                w = "stack" in y(m),
                k = "stack" in new g(1, 2),
                S = g && f && Object.getOwnPropertyDescriptor(o, m),
                x = !(!S || S.writable && S.configurable),
                C = w && !x && !k;
            n({
                global: !0,
                constructor: !0,
                forced: h || C
            }, {
                DOMException: C ? v : g
            });
            var E = i(m),
                T = E.prototype;
            if (T.constructor !== E)
                for (var A in h || s(T, "constructor", a(1, E)), d)
                    if (c(d, A)) {
                        var R = d[A],
                            O = R.s;
                        c(E, O) || s(E, O, a(6, R.c))
                    }
        },
        28e3: e => {
            var t = 1e3,
                r = 60 * t,
                n = 60 * r,
                o = 24 * n,
                i = 7 * o,
                a = 365.25 * o;

            function s(e, t, r, n) {
                var o = t >= 1.5 * r;
                return Math.round(e / r) + " " + n + (o ? "s" : "")
            }
            e.exports = function(e, c) {
                c = c || {};
                var l = typeof e;
                if ("string" === l && e.length > 0) return function(e) {
                    if ((e = String(e)).length > 100) return;
                    var s = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(e);
                    if (!s) return;
                    var c = parseFloat(s[1]);
                    switch ((s[2] || "ms").toLowerCase()) {
                        case "years":
                        case "year":
                        case "yrs":
                        case "yr":
                        case "y":
                            return c * a;
                        case "weeks":
                        case "week":
                        case "w":
                            return c * i;
                        case "days":
                        case "day":
                        case "d":
                            return c * o;
                        case "hours":
                        case "hour":
                        case "hrs":
                        case "hr":
                        case "h":
                            return c * n;
                        case "minutes":
                        case "minute":
                        case "mins":
                        case "min":
                        case "m":
                            return c * r;
                        case "seconds":
                        case "second":
                        case "secs":
                        case "sec":
                        case "s":
                            return c * t;
                        case "milliseconds":
                        case "millisecond":
                        case "msecs":
                        case "msec":
                        case "ms":
                            return c;
                        default:
                            return
                    }
                }(e);
                if ("number" === l && isFinite(e)) return c.long ? function(e) {
                    var i = Math.abs(e);
                    if (i >= o) return s(e, i, o, "day");
                    if (i >= n) return s(e, i, n, "hour");
                    if (i >= r) return s(e, i, r, "minute");
                    if (i >= t) return s(e, i, t, "second");
                    return e + " ms"
                }(e) : function(e) {
                    var i = Math.abs(e);
                    if (i >= o) return Math.round(e / o) + "d";
                    if (i >= n) return Math.round(e / n) + "h";
                    if (i >= r) return Math.round(e / r) + "m";
                    if (i >= t) return Math.round(e / t) + "s";
                    return e + "ms"
                }(e);
                throw new Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(e))
            }
        },
        17833: (e, t, r) => {
            t.formatArgs = function(t) {
                if (t[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + t[0] + (this.useColors ? "%c " : " ") + "+" + e.exports.humanize(this.diff), !this.useColors) return;
                const r = "color: " + this.color;
                t.splice(1, 0, r, "color: inherit");
                let n = 0,
                    o = 0;
                t[0].replace(/%[a-zA-Z%]/g, (e => {
                    "%%" !== e && (n++, "%c" === e && (o = n))
                })), t.splice(o, 0, r)
            }, t.save = function(e) {
                try {
                    e ? t.storage.setItem("debug", e) : t.storage.removeItem("debug")
                } catch (e) {}
            }, t.load = function() {
                let e;
                try {
                    e = t.storage.getItem("debug")
                } catch (e) {}!e && "undefined" != typeof process && "env" in process && (e = process.env.DEBUG);
                return e
            }, t.useColors = function() {
                if ("undefined" != typeof window && window.process && ("renderer" === window.process.type || window.process.__nwjs)) return !0;
                if ("undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) return !1;
                return "undefined" != typeof document && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || "undefined" != typeof window && window.console && (window.console.firebug || window.console.exception && window.console.table) || "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) && parseInt(RegExp.$1, 10) >= 31 || "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/)
            }, t.storage = function() {
                try {
                    return localStorage
                } catch (e) {}
            }(), t.destroy = (() => {
                let e = !1;
                return () => {
                    e || (e = !0, console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."))
                }
            })(), t.colors = ["#0000CC", "#0000FF", "#0033CC", "#0033FF", "#0066CC", "#0066FF", "#0099CC", "#0099FF", "#00CC00", "#00CC33", "#00CC66", "#00CC99", "#00CCCC", "#00CCFF", "#3300CC", "#3300FF", "#3333CC", "#3333FF", "#3366CC", "#3366FF", "#3399CC", "#3399FF", "#33CC00", "#33CC33", "#33CC66", "#33CC99", "#33CCCC", "#33CCFF", "#6600CC", "#6600FF", "#6633CC", "#6633FF", "#66CC00", "#66CC33", "#9900CC", "#9900FF", "#9933CC", "#9933FF", "#99CC00", "#99CC33", "#CC0000", "#CC0033", "#CC0066", "#CC0099", "#CC00CC", "#CC00FF", "#CC3300", "#CC3333", "#CC3366", "#CC3399", "#CC33CC", "#CC33FF", "#CC6600", "#CC6633", "#CC9900", "#CC9933", "#CCCC00", "#CCCC33", "#FF0000", "#FF0033", "#FF0066", "#FF0099", "#FF00CC", "#FF00FF", "#FF3300", "#FF3333", "#FF3366", "#FF3399", "#FF33CC", "#FF33FF", "#FF6600", "#FF6633", "#FF9900", "#FF9933", "#FFCC00", "#FFCC33"], t.log = console.debug || console.log || (() => {}), e.exports = r(40736)(t);
            const {
                formatters: n
            } = e.exports;
            n.j = function(e) {
                try {
                    return JSON.stringify(e)
                } catch (e) {
                    return "[UnexpectedJSONParseError]: " + e.message
                }
            }
        },
        40736: (e, t, r) => {
            e.exports = function(e) {
                function t(e) {
                    let r, o, i, a = null;

                    function s(...e) {
                        if (!s.enabled) return;
                        const n = s,
                            o = Number(new Date),
                            i = o - (r || o);
                        n.diff = i, n.prev = r, n.curr = o, r = o, e[0] = t.coerce(e[0]), "string" != typeof e[0] && e.unshift("%O");
                        let a = 0;
                        e[0] = e[0].replace(/%([a-zA-Z%])/g, ((r, o) => {
                            if ("%%" === r) return "%";
                            a++;
                            const i = t.formatters[o];
                            if ("function" == typeof i) {
                                const t = e[a];
                                r = i.call(n, t), e.splice(a, 1), a--
                            }
                            return r
                        })), t.formatArgs.call(n, e);
                        (n.log || t.log).apply(n, e)
                    }
                    return s.namespace = e, s.useColors = t.useColors(), s.color = t.selectColor(e), s.extend = n, s.destroy = t.destroy, Object.defineProperty(s, "enabled", {
                        enumerable: !0,
                        configurable: !1,
                        get: () => null !== a ? a : (o !== t.namespaces && (o = t.namespaces, i = t.enabled(e)), i),
                        set: e => {
                            a = e
                        }
                    }), "function" == typeof t.init && t.init(s), s
                }

                function n(e, r) {
                    const n = t(this.namespace + (void 0 === r ? ":" : r) + e);
                    return n.log = this.log, n
                }

                function o(e) {
                    return e.toString().substring(2, e.toString().length - 2).replace(/\.\*\?$/, "*")
                }
                return t.debug = t, t.default = t, t.coerce = function(e) {
                    if (e instanceof Error) return e.stack || e.message;
                    return e
                }, t.disable = function() {
                    const e = [...t.names.map(o), ...t.skips.map(o).map((e => "-" + e))].join(",");
                    return t.enable(""), e
                }, t.enable = function(e) {
                    let r;
                    t.save(e), t.namespaces = e, t.names = [], t.skips = [];
                    const n = ("string" == typeof e ? e : "").split(/[\s,]+/),
                        o = n.length;
                    for (r = 0; r < o; r++) n[r] && ("-" === (e = n[r].replace(/\*/g, ".*?"))[0] ? t.skips.push(new RegExp("^" + e.slice(1) + "$")) : t.names.push(new RegExp("^" + e + "$")))
                }, t.enabled = function(e) {
                    if ("*" === e[e.length - 1]) return !0;
                    let r, n;
                    for (r = 0, n = t.skips.length; r < n; r++)
                        if (t.skips[r].test(e)) return !1;
                    for (r = 0, n = t.names.length; r < n; r++)
                        if (t.names[r].test(e)) return !0;
                    return !1
                }, t.humanize = r(28e3), t.destroy = function() {
                    console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.")
                }, Object.keys(e).forEach((r => {
                    t[r] = e[r]
                })), t.names = [], t.skips = [], t.formatters = {}, t.selectColor = function(e) {
                    let r = 0;
                    for (let t = 0; t < e.length; t++) r = (r << 5) - r + e.charCodeAt(t), r |= 0;
                    return t.colors[Math.abs(r) % t.colors.length]
                }, t.enable(t.load()), t
            }
        },
        29698: (e, t) => {
            "use strict";
            var r = Symbol.for("react.transitional.element"),
                n = Symbol.for("react.fragment");

            function o(e, t, n) {
                var o = null;
                if (void 0 !== n && (o = "" + n), void 0 !== t.key && (o = "" + t.key), "key" in t)
                    for (var i in n = {}, t) "key" !== i && (n[i] = t[i]);
                else n = t;
                return t = n.ref, {
                    $$typeof: r,
                    type: e,
                    key: o,
                    ref: void 0 !== t ? t : null,
                    props: n
                }
            }
            t.Fragment = n, t.jsx = o, t.jsxs = o
        },
        29869: (e, t) => {
            "use strict";
            var r = Symbol.for("react.transitional.element"),
                n = Symbol.for("react.portal"),
                o = Symbol.for("react.fragment"),
                i = Symbol.for("react.strict_mode"),
                a = Symbol.for("react.profiler"),
                s = Symbol.for("react.consumer"),
                c = Symbol.for("react.context"),
                l = Symbol.for("react.forward_ref"),
                u = Symbol.for("react.suspense"),
                _ = Symbol.for("react.memo"),
                d = Symbol.for("react.lazy"),
                p = Symbol.for("react.activity"),
                f = Symbol.iterator;
            var h = {
                    isMounted: function() {
                        return !1
                    },
                    enqueueForceUpdate: function() {},
                    enqueueReplaceState: function() {},
                    enqueueSetState: function() {}
                },
                m = Object.assign,
                y = {};

            function g(e, t, r) {
                this.props = e, this.context = t, this.refs = y, this.updater = r || h
            }

            function v() {}

            function b(e, t, r) {
                this.props = e, this.context = t, this.refs = y, this.updater = r || h
            }
            g.prototype.isReactComponent = {}, g.prototype.setState = function(e, t) {
                if ("object" != typeof e && "function" != typeof e && null != e) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
                this.updater.enqueueSetState(this, e, t, "setState")
            }, g.prototype.forceUpdate = function(e) {
                this.updater.enqueueForceUpdate(this, e, "forceUpdate")
            }, v.prototype = g.prototype;
            var w = b.prototype = new v;
            w.constructor = b, m(w, g.prototype), w.isPureReactComponent = !0;
            var k = Array.isArray;

            function S() {}
            var x = {
                    H: null,
                    A: null,
                    T: null,
                    S: null
                },
                C = Object.prototype.hasOwnProperty;

            function E(e, t, n) {
                var o = n.ref;
                return {
                    $$typeof: r,
                    type: e,
                    key: t,
                    ref: void 0 !== o ? o : null,
                    props: n
                }
            }

            function T(e) {
                return "object" == typeof e && null !== e && e.$$typeof === r
            }
            var A = /\/+/g;

            function R(e, t) {
                return "object" == typeof e && null !== e && null != e.key ? (r = "" + e.key, n = {
                    "=": "=0",
                    ":": "=2"
                }, "$" + r.replace(/[=:]/g, (function(e) {
                    return n[e]
                }))) : t.toString(36);
                var r, n
            }

            function O(e, t, o, i, a) {
                var s = typeof e;
                "undefined" !== s && "boolean" !== s || (e = null);
                var c, l, u = !1;
                if (null === e) u = !0;
                else switch (s) {
                    case "bigint":
                    case "string":
                    case "number":
                        u = !0;
                        break;
                    case "object":
                        switch (e.$$typeof) {
                            case r:
                            case n:
                                u = !0;
                                break;
                            case d:
                                return O((u = e._init)(e._payload), t, o, i, a)
                        }
                }
                if (u) return a = a(e), u = "" === i ? "." + R(e, 0) : i, k(a) ? (o = "", null != u && (o = u.replace(A, "$&/") + "/"), O(a, t, o, "", (function(e) {
                    return e
                }))) : null != a && (T(a) && (c = a, l = o + (null == a.key || e && e.key === a.key ? "" : ("" + a.key).replace(A, "$&/") + "/") + u, a = E(c.type, l, c.props)), t.push(a)), 1;
                u = 0;
                var _, p = "" === i ? "." : i + ":";
                if (k(e))
                    for (var h = 0; h < e.length; h++) u += O(i = e[h], t, o, s = p + R(i, h), a);
                else if ("function" == typeof(h = null === (_ = e) || "object" != typeof _ ? null : "function" == typeof(_ = f && _[f] || _["@@iterator"]) ? _ : null))
                    for (e = h.call(e), h = 0; !(i = e.next()).done;) u += O(i = i.value, t, o, s = p + R(i, h++), a);
                else if ("object" === s) {
                    if ("function" == typeof e.then) return O(function(e) {
                        switch (e.status) {
                            case "fulfilled":
                                return e.value;
                            case "rejected":
                                throw e.reason;
                            default:
                                switch ("string" == typeof e.status ? e.then(S, S) : (e.status = "pending", e.then((function(t) {
                                    "pending" === e.status && (e.status = "fulfilled", e.value = t)
                                }), (function(t) {
                                    "pending" === e.status && (e.status = "rejected", e.reason = t)
                                }))), e.status) {
                                    case "fulfilled":
                                        return e.value;
                                    case "rejected":
                                        throw e.reason
                                }
                        }
                        throw e
                    }(e), t, o, i, a);
                    throw t = String(e), Error("Objects are not valid as a React child (found: " + ("[object Object]" === t ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.")
                }
                return u
            }

            function P(e, t, r) {
                if (null == e) return e;
                var n = [],
                    o = 0;
                return O(e, n, "", "", (function(e) {
                    return t.call(r, e, o++)
                })), n
            }

            function M(e) {
                if (-1 === e._status) {
                    var t = e._result;
                    (t = t()).then((function(t) {
                        0 !== e._status && -1 !== e._status || (e._status = 1, e._result = t)
                    }), (function(t) {
                        0 !== e._status && -1 !== e._status || (e._status = 2, e._result = t)
                    })), -1 === e._status && (e._status = 0, e._result = t)
                }
                if (1 === e._status) return e._result.default;
                throw e._result
            }
            var I = "function" == typeof reportError ? reportError : function(e) {
                    if ("object" == typeof window && "function" == typeof window.ErrorEvent) {
                        var t = new window.ErrorEvent("error", {
                            bubbles: !0,
                            cancelable: !0,
                            message: "object" == typeof e && null !== e && "string" == typeof e.message ? String(e.message) : String(e),
                            error: e
                        });
                        if (!window.dispatchEvent(t)) return
                    } else if ("object" == typeof process && "function" == typeof process.emit) return void process.emit("uncaughtException", e);
                    console.error(e)
                },
                N = {
                    map: P,
                    forEach: function(e, t, r) {
                        P(e, (function() {
                            t.apply(this, arguments)
                        }), r)
                    },
                    count: function(e) {
                        var t = 0;
                        return P(e, (function() {
                            t++
                        })), t
                    },
                    toArray: function(e) {
                        return P(e, (function(e) {
                            return e
                        })) || []
                    },
                    only: function(e) {
                        if (!T(e)) throw Error("React.Children.only expected to receive a single React element child.");
                        return e
                    }
                };
            t.Activity = p, t.Children = N, t.Component = g, t.Fragment = o, t.Profiler = a, t.PureComponent = b, t.StrictMode = i, t.Suspense = u, t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = x, t.__COMPILER_RUNTIME = {
                __proto__: null,
                c: function(e) {
                    return x.H.useMemoCache(e)
                }
            }, t.cache = function(e) {
                return function() {
                    return e.apply(null, arguments)
                }
            }, t.cacheSignal = function() {
                return null
            }, t.cloneElement = function(e, t, r) {
                if (null == e) throw Error("The argument must be a React element, but you passed " + e + ".");
                var n = m({}, e.props),
                    o = e.key;
                if (null != t)
                    for (i in void 0 !== t.key && (o = "" + t.key), t) !C.call(t, i) || "key" === i || "__self" === i || "__source" === i || "ref" === i && void 0 === t.ref || (n[i] = t[i]);
                var i = arguments.length - 2;
                if (1 === i) n.children = r;
                else if (1 < i) {
                    for (var a = Array(i), s = 0; s < i; s++) a[s] = arguments[s + 2];
                    n.children = a
                }
                return E(e.type, o, n)
            }, t.createContext = function(e) {
                return (e = {
                    $$typeof: c,
                    _currentValue: e,
                    _currentValue2: e,
                    _threadCount: 0,
                    Provider: null,
                    Consumer: null
                }).Provider = e, e.Consumer = {
                    $$typeof: s,
                    _context: e
                }, e
            }, t.createElement = function(e, t, r) {
                var n, o = {},
                    i = null;
                if (null != t)
                    for (n in void 0 !== t.key && (i = "" + t.key), t) C.call(t, n) && "key" !== n && "__self" !== n && "__source" !== n && (o[n] = t[n]);
                var a = arguments.length - 2;
                if (1 === a) o.children = r;
                else if (1 < a) {
                    for (var s = Array(a), c = 0; c < a; c++) s[c] = arguments[c + 2];
                    o.children = s
                }
                if (e && e.defaultProps)
                    for (n in a = e.defaultProps) void 0 === o[n] && (o[n] = a[n]);
                return E(e, i, o)
            }, t.createRef = function() {
                return {
                    current: null
                }
            }, t.forwardRef = function(e) {
                return {
                    $$typeof: l,
                    render: e
                }
            }, t.isValidElement = T, t.lazy = function(e) {
                return {
                    $$typeof: d,
                    _payload: {
                        _status: -1,
                        _result: e
                    },
                    _init: M
                }
            }, t.memo = function(e, t) {
                return {
                    $$typeof: _,
                    type: e,
                    compare: void 0 === t ? null : t
                }
            }, t.startTransition = function(e) {
                var t = x.T,
                    r = {};
                x.T = r;
                try {
                    var n = e(),
                        o = x.S;
                    null !== o && o(r, n), "object" == typeof n && null !== n && "function" == typeof n.then && n.then(S, I)
                } catch (e) {
                    I(e)
                } finally {
                    null !== t && null !== r.types && (t.types = r.types), x.T = t
                }
            }, t.unstable_useCacheRefresh = function() {
                return x.H.useCacheRefresh()
            }, t.use = function(e) {
                return x.H.use(e)
            }, t.useActionState = function(e, t, r) {
                return x.H.useActionState(e, t, r)
            }, t.useCallback = function(e, t) {
                return x.H.useCallback(e, t)
            }, t.useContext = function(e) {
                return x.H.useContext(e)
            }, t.useDebugValue = function() {}, t.useDeferredValue = function(e, t) {
                return x.H.useDeferredValue(e, t)
            }, t.useEffect = function(e, t) {
                return x.H.useEffect(e, t)
            }, t.useEffectEvent = function(e) {
                return x.H.useEffectEvent(e)
            }, t.useId = function() {
                return x.H.useId()
            }, t.useImperativeHandle = function(e, t, r) {
                return x.H.useImperativeHandle(e, t, r)
            }, t.useInsertionEffect = function(e, t) {
                return x.H.useInsertionEffect(e, t)
            }, t.useLayoutEffect = function(e, t) {
                return x.H.useLayoutEffect(e, t)
            }, t.useMemo = function(e, t) {
                return x.H.useMemo(e, t)
            }, t.useOptimistic = function(e, t) {
                return x.H.useOptimistic(e, t)
            }, t.useReducer = function(e, t, r) {
                return x.H.useReducer(e, t, r)
            }, t.useRef = function(e) {
                return x.H.useRef(e)
            }, t.useState = function(e) {
                return x.H.useState(e)
            }, t.useSyncExternalStore = function(e, t, r) {
                return x.H.useSyncExternalStore(e, t, r)
            }, t.useTransition = function() {
                return x.H.useTransition()
            }, t.version = "19.2.7"
        },
        96540: (e, t, r) => {
            "use strict";
            e.exports = r(29869)
        },
        74848: (e, t, r) => {
            "use strict";
            e.exports = r(29698)
        },
        10661: (e, t) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.createCacheKeyComparator = o, t.defaultEqualityCheck = void 0, t.defaultMemoize = function(e, t) {
                var i = "object" == typeof t ? t : {
                        equalityCheck: t
                    },
                    a = i.equalityCheck,
                    s = void 0 === a ? n : a,
                    c = i.maxSize,
                    l = void 0 === c ? 1 : c,
                    u = i.resultEqualityCheck,
                    _ = o(s),
                    d = 1 === l ? (p = _, {
                        get: function(e) {
                            return f && p(f.key, e) ? f.value : r
                        },
                        put: function(e, t) {
                            f = {
                                key: e,
                                value: t
                            }
                        },
                        getEntries: function() {
                            return f ? [f] : []
                        },
                        clear: function() {
                            f = void 0
                        }
                    }) : function(e, t) {
                        var n = [];

                        function o(e) {
                            var o = n.findIndex((function(r) {
                                return t(e, r.key)
                            }));
                            if (o > -1) {
                                var i = n[o];
                                return o > 0 && (n.splice(o, 1), n.unshift(i)), i.value
                            }
                            return r
                        }

                        function i(t, i) {
                            o(t) === r && (n.unshift({
                                key: t,
                                value: i
                            }), n.length > e && n.pop())
                        }

                        function a() {
                            return n
                        }

                        function s() {
                            n = []
                        }
                        return {
                            get: o,
                            put: i,
                            getEntries: a,
                            clear: s
                        }
                    }(l, _);
                var p, f;

                function h() {
                    var t = d.get(arguments);
                    if (t === r) {
                        if (t = e.apply(null, arguments), u) {
                            var n = d.getEntries().find((function(e) {
                                return u(e.value, t)
                            }));
                            n && (t = n.value)
                        }
                        d.put(arguments, t)
                    }
                    return t
                }
                return h.clearCache = function() {
                    return d.clear()
                }, h
            };
            var r = "NOT_FOUND";
            var n = function(e, t) {
                return e === t
            };

            function o(e) {
                return function(t, r) {
                    if (null === t || null === r || t.length !== r.length) return !1;
                    for (var n = t.length, o = 0; o < n; o++)
                        if (!e(t[o], r[o])) return !1;
                    return !0
                }
            }
            t.defaultEqualityCheck = n
        },
        97132: (e, t, r) => {
            "use strict";
            t.Mz = void 0, t.j8 = void 0;
            var n = r(10661);

            function o(e) {
                for (var t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++) r[n - 1] = arguments[n];
                return function() {
                    for (var t = arguments.length, n = new Array(t), o = 0; o < t; o++) n[o] = arguments[o];
                    var i, a = 0,
                        s = {
                            memoizeOptions: void 0
                        },
                        c = n.pop();
                    if ("object" == typeof c && (s = c, c = n.pop()), "function" != typeof c) throw new Error("createSelector expects an output function after the inputs, but received: [" + typeof c + "]");
                    var l = s.memoizeOptions,
                        u = void 0 === l ? r : l,
                        _ = Array.isArray(u) ? u : [u],
                        d = function(e) {
                            var t = Array.isArray(e[0]) ? e[0] : e;
                            if (!t.every((function(e) {
                                    return "function" == typeof e
                                }))) {
                                var r = t.map((function(e) {
                                    return "function" == typeof e ? "function " + (e.name || "unnamed") + "()" : typeof e
                                })).join(", ");
                                throw new Error("createSelector expects all input-selectors to be functions, but received the following types: [" + r + "]")
                            }
                            return t
                        }(n),
                        p = e.apply(void 0, [function() {
                            return a++, c.apply(null, arguments)
                        }].concat(_)),
                        f = e((function() {
                            for (var e = [], t = d.length, r = 0; r < t; r++) e.push(d[r].apply(null, arguments));
                            return i = p.apply(null, e)
                        }));
                    return Object.assign(f, {
                        resultFunc: c,
                        memoizedResultFunc: p,
                        dependencies: d,
                        lastResult: function() {
                            return i
                        },
                        recomputations: function() {
                            return a
                        },
                        resetRecomputations: function() {
                            return a = 0
                        }
                    }), f
                }
            }
            var i = o(n.defaultMemoize);
            t.Mz = i;
            t.j8 = function(e, t) {
                if (void 0 === t && (t = i), "object" != typeof e) throw new Error("createStructuredSelector expects first argument to be an object where each property is a selector, instead received a " + typeof e);
                var r = Object.keys(e),
                    n = t(r.map((function(t) {
                        return e[t]
                    })), (function() {
                        for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                        return t.reduce((function(e, t, n) {
                            return e[r[n]] = t, e
                        }), {})
                    }));
                return n
            }
        },
        75617: (e, t, r) => {
            e.exports = r(58303)
        },
        58303: (e, t, r) => {
            var n = r(93961);
            t.operation = function(e) {
                var r = t.timeouts(e);
                return new n(r, {
                    forever: e && (e.forever || e.retries === 1 / 0),
                    unref: e && e.unref,
                    maxRetryTime: e && e.maxRetryTime
                })
            }, t.timeouts = function(e) {
                if (e instanceof Array) return [].concat(e);
                var t = {
                    retries: 10,
                    factor: 2,
                    minTimeout: 1e3,
                    maxTimeout: 1 / 0,
                    randomize: !1
                };
                for (var r in e) t[r] = e[r];
                if (t.minTimeout > t.maxTimeout) throw new Error("minTimeout is greater than maxTimeout");
                for (var n = [], o = 0; o < t.retries; o++) n.push(this.createTimeout(o, t));
                return e && e.forever && !n.length && n.push(this.createTimeout(o, t)), n.sort((function(e, t) {
                    return e - t
                })), n
            }, t.createTimeout = function(e, t) {
                var r = t.randomize ? Math.random() + 1 : 1,
                    n = Math.round(r * Math.max(t.minTimeout, 1) * Math.pow(t.factor, e));
                return n = Math.min(n, t.maxTimeout)
            }, t.wrap = function(e, r, n) {
                if (r instanceof Array && (n = r, r = null), !n)
                    for (var o in n = [], e) "function" == typeof e[o] && n.push(o);
                for (var i = 0; i < n.length; i++) {
                    var a = n[i],
                        s = e[a];
                    e[a] = function(n) {
                        var o = t.operation(r),
                            i = Array.prototype.slice.call(arguments, 1),
                            a = i.pop();
                        i.push((function(e) {
                            o.retry(e) || (e && (arguments[0] = o.mainError()), a.apply(this, arguments))
                        })), o.attempt((function() {
                            n.apply(e, i)
                        }))
                    }.bind(e, s), e[a].options = r
                }
            }
        },
        93961: e => {
            function t(e, t) {
                "boolean" == typeof t && (t = {
                    forever: t
                }), this._originalTimeouts = JSON.parse(JSON.stringify(e)), this._timeouts = e, this._options = t || {}, this._maxRetryTime = t && t.maxRetryTime || 1 / 0, this._fn = null, this._errors = [], this._attempts = 1, this._operationTimeout = null, this._operationTimeoutCb = null, this._timeout = null, this._operationStart = null, this._timer = null, this._options.forever && (this._cachedTimeouts = this._timeouts.slice(0))
            }
            e.exports = t, t.prototype.reset = function() {
                this._attempts = 1, this._timeouts = this._originalTimeouts.slice(0)
            }, t.prototype.stop = function() {
                this._timeout && clearTimeout(this._timeout), this._timer && clearTimeout(this._timer), this._timeouts = [], this._cachedTimeouts = null
            }, t.prototype.retry = function(e) {
                if (this._timeout && clearTimeout(this._timeout), !e) return !1;
                var t = (new Date).getTime();
                if (e && t - this._operationStart >= this._maxRetryTime) return this._errors.push(e), this._errors.unshift(new Error("RetryOperation timeout occurred")), !1;
                this._errors.push(e);
                var r = this._timeouts.shift();
                if (void 0 === r) {
                    if (!this._cachedTimeouts) return !1;
                    this._errors.splice(0, this._errors.length - 1), r = this._cachedTimeouts.slice(-1)
                }
                var n = this;
                return this._timer = setTimeout((function() {
                    n._attempts++, n._operationTimeoutCb && (n._timeout = setTimeout((function() {
                        n._operationTimeoutCb(n._attempts)
                    }), n._operationTimeout), n._options.unref && n._timeout.unref()), n._fn(n._attempts)
                }), r), this._options.unref && this._timer.unref(), !0
            }, t.prototype.attempt = function(e, t) {
                this._fn = e, t && (t.timeout && (this._operationTimeout = t.timeout), t.cb && (this._operationTimeoutCb = t.cb));
                var r = this;
                this._operationTimeoutCb && (this._timeout = setTimeout((function() {
                    r._operationTimeoutCb()
                }), r._operationTimeout)), this._operationStart = (new Date).getTime(), this._fn(this._attempts)
            }, t.prototype.try = function(e) {
                console.log("Using RetryOperation.try() is deprecated"), this.attempt(e)
            }, t.prototype.start = function(e) {
                console.log("Using RetryOperation.start() is deprecated"), this.attempt(e)
            }, t.prototype.start = t.prototype.try, t.prototype.errors = function() {
                return this._errors
            }, t.prototype.attempts = function() {
                return this._attempts
            }, t.prototype.mainError = function() {
                if (0 === this._errors.length) return null;
                for (var e = {}, t = null, r = 0, n = 0; n < this._errors.length; n++) {
                    var o = this._errors[n],
                        i = o.message,
                        a = (e[i] || 0) + 1;
                    e[i] = a, a >= r && (t = o, r = a)
                }
                return t
            }
        },
        67098: function(e, t, r) {
            "use strict";
            var n;
            ! function() {
                if ("function" != typeof o) {
                    var o = function(e) {
                        return e
                    };
                    o.nonNative = !0
                }
                const i = o("plaintext"),
                    a = o("html"),
                    s = o("comment"),
                    c = /<(\w*)>/g,
                    l = /<\/?([^\s\/>]+)/;

                function u(e, t, r) {
                    return d(e = e || "", _(t = t || [], r = r || ""))
                }

                function _(e, t) {
                    return {
                        allowable_tags: e = function(e) {
                            let t = new Set;
                            if ("string" == typeof e) {
                                let r;
                                for (; r = c.exec(e);) t.add(r[1])
                            } else o.nonNative || "function" != typeof e[o.iterator] ? "function" == typeof e.forEach && e.forEach(t.add, t) : t = new Set(e);
                            return t
                        }(e),
                        tag_replacement: t,
                        state: i,
                        tag_buffer: "",
                        depth: 0,
                        in_quote_char: ""
                    }
                }

                function d(e, t) {
                    if ("string" != typeof e) throw new TypeError("'html' parameter must be a string");
                    let r = t.allowable_tags,
                        n = t.tag_replacement,
                        o = t.state,
                        c = t.tag_buffer,
                        l = t.depth,
                        u = t.in_quote_char,
                        _ = "";
                    for (let t = 0, d = e.length; t < d; t++) {
                        let d = e[t];
                        if (o === i)
                            if ("<" === d) o = a, c += d;
                            else _ += d;
                        else if (o === a) switch (d) {
                            case "<":
                                if (u) break;
                                l++;
                                break;
                            case ">":
                                if (u) break;
                                if (l) {
                                    l--;
                                    break
                                }
                                u = "", o = i, c += ">", r.has(p(c)) ? _ += c : _ += n, c = "";
                                break;
                            case '"':
                            case "'":
                                u = d === u ? "" : u || d, c += d;
                                break;
                            case "-":
                                "<!-" === c && (o = s), c += d;
                                break;
                            case " ":
                            case "\n":
                                if ("<" === c) {
                                    o = i, _ += "< ", c = "";
                                    break
                                }
                                c += d;
                                break;
                            default:
                                c += d
                        } else if (o === s)
                            if (">" === d) "--" == c.slice(-2) && (o = i), c = "";
                            else c += d
                    }
                    return t.state = o, t.tag_buffer = c, t.depth = l, t.in_quote_char = u, _
                }

                function p(e) {
                    let t = l.exec(e);
                    return t ? t[1].toLowerCase() : null
                }
                u.init_streaming_mode = function(e, t) {
                    let r = _(e = e || [], t = t || "");
                    return function(e) {
                        return d(e || "", r)
                    }
                }, void 0 === (n = function() {
                    return u
                }.call(t, r, t, e)) || (e.exports = n)
            }()
        },
        85160: (e, t, r) => {
            "use strict";
            var n = r(96540);
            var o = "function" == typeof Object.is ? Object.is : function(e, t) {
                    return e === t && (0 !== e || 1 / e == 1 / t) || e != e && t != t
                },
                i = n.useSyncExternalStore,
                a = n.useRef,
                s = n.useEffect,
                c = n.useMemo,
                l = n.useDebugValue;
            t.useSyncExternalStoreWithSelector = function(e, t, r, n, u) {
                var _ = a(null);
                if (null === _.current) {
                    var d = {
                        hasValue: !1,
                        value: null
                    };
                    _.current = d
                } else d = _.current;
                _ = c((function() {
                    function e(e) {
                        if (!s) {
                            if (s = !0, i = e, e = n(e), void 0 !== u && d.hasValue) {
                                var t = d.value;
                                if (u(t, e)) return a = t
                            }
                            return a = e
                        }
                        if (t = a, o(i, e)) return t;
                        var r = n(e);
                        return void 0 !== u && u(t, r) ? (i = e, t) : (i = e, a = r)
                    }
                    var i, a, s = !1,
                        c = void 0 === r ? null : r;
                    return [function() {
                        return e(t())
                    }, null === c ? void 0 : function() {
                        return e(c())
                    }]
                }), [t, r, n, u]);
                var p = i(e, _[0], _[1]);
                return s((function() {
                    d.hasValue = !0, d.value = p
                }), [p]), l(p), p
            }
        },
        78418: (e, t, r) => {
            "use strict";
            e.exports = r(85160)
        },
        15452: (e, t, r) => {
            "use strict";
            r.d(t, {
                ch: () => xt,
                U1: () => Oe,
                VP: () => we,
                zD: () => Be,
                Nc: () => At,
                vy: () => Me,
                Z0: () => Ke,
                i0: () => Ne,
                sf: () => je
            });
            var n = Symbol.for("immer-nothing"),
                o = Symbol.for("immer-draftable"),
                i = Symbol.for("immer-state");

            function a(e, ...t) {
                throw new Error(`[Immer] minified error nr: ${e}. Full error at: https://bit.ly/3cXEKWf`)
            }
            var s = Object,
                c = s.getPrototypeOf,
                l = "constructor",
                u = "prototype",
                _ = "configurable",
                d = "enumerable",
                p = "writable",
                f = "value",
                h = e => !!e && !!e[i];

            function m(e) {
                return !!e && (v(e) || C(e) || !!e[o] || !!e[l] ? .[o] || E(e) || T(e))
            }
            var y = s[u][l].toString(),
                g = new WeakMap;

            function v(e) {
                if (!e || !A(e)) return !1;
                const t = c(e);
                if (null === t || t === s[u]) return !0;
                const r = s.hasOwnProperty.call(t, l) && t[l];
                if (r === Object) return !0;
                if (!R(r)) return !1;
                let n = g.get(r);
                return void 0 === n && (n = Function.toString.call(r), g.set(r, n)), n === y
            }

            function b(e, t, r = !0) {
                if (0 === w(e)) {
                    (r ? Reflect.ownKeys(e) : s.keys(e)).forEach((r => {
                        t(r, e[r], e)
                    }))
                } else e.forEach(((r, n) => t(n, r, e)))
            }

            function w(e) {
                const t = e[i];
                return t ? t.type_ : C(e) ? 1 : E(e) ? 2 : T(e) ? 3 : 0
            }
            var k = (e, t, r = w(e)) => 2 === r ? e.has(t) : s[u].hasOwnProperty.call(e, t),
                S = (e, t, r = w(e)) => 2 === r ? e.get(t) : e[t],
                x = (e, t, r, n = w(e)) => {
                    2 === n ? e.set(t, r) : 3 === n ? e.add(r) : e[t] = r
                };
            var C = Array.isArray,
                E = e => e instanceof Map,
                T = e => e instanceof Set,
                A = e => "object" == typeof e,
                R = e => "function" == typeof e,
                O = e => "boolean" == typeof e;
            var P = e => e.copy_ || e.base_,
                M = e => e.modified_ ? e.copy_ : e.base_;

            function I(e, t) {
                if (E(e)) return new Map(e);
                if (T(e)) return new Set(e);
                if (C(e)) return Array[u].slice.call(e);
                const r = v(e);
                if (!0 === t || "class_only" === t && !r) {
                    const t = s.getOwnPropertyDescriptors(e);
                    delete t[i];
                    let r = Reflect.ownKeys(t);
                    for (let n = 0; n < r.length; n++) {
                        const o = r[n],
                            i = t[o];
                        !1 === i[p] && (i[p] = !0, i[_] = !0), (i.get || i.set) && (t[o] = {
                            [_]: !0,
                            [p]: !0,
                            [d]: i[d],
                            [f]: e[o]
                        })
                    }
                    return s.create(c(e), t)
                } {
                    const t = c(e);
                    if (null !== t && r) return { ...e
                    };
                    const n = s.create(t);
                    return s.assign(n, e)
                }
            }

            function N(e, t = !1) {
                return D(e) || h(e) || !m(e) || (w(e) > 1 && s.defineProperties(e, {
                    set: F,
                    add: F,
                    clear: F,
                    delete: F
                }), s.freeze(e), t && b(e, ((e, t) => {
                    N(t, !0)
                }), !1)), e
            }
            var F = {
                [f]: function() {
                    a(2)
                }
            };

            function D(e) {
                return null === e || !A(e) || s.isFrozen(e)
            }
            var j = "MapSet",
                L = "Patches",
                W = "ArrayMethods",
                z = {};

            function U(e) {
                const t = z[e];
                return t || a(0), t
            }
            var H, q = e => !!z[e];
            var B = () => H;

            function $(e, t) {
                t && (e.patchPlugin_ = U(L), e.patches_ = [], e.inversePatches_ = [], e.patchListener_ = t)
            }

            function G(e) {
                V(e), e.drafts_.forEach(X), e.drafts_ = null
            }

            function V(e) {
                e === H && (H = e.parent_)
            }
            var Y = e => H = {
                drafts_: [],
                parent_: H,
                immer_: e,
                canAutoFreeze_: !0,
                unfinalizedDrafts_: 0,
                handledSet_: new Set,
                processedForPatches_: new Set,
                mapSetPlugin_: q(j) ? U(j) : void 0,
                arrayMethodsPlugin_: q(W) ? U(W) : void 0
            };

            function X(e) {
                const t = e[i];
                0 === t.type_ || 1 === t.type_ ? t.revoke_() : t.revoked_ = !0
            }

            function K(e, t) {
                t.unfinalizedDrafts_ = t.drafts_.length;
                const r = t.drafts_[0];
                if (void 0 !== e && e !== r) {
                    r[i].modified_ && (G(t), a(4)), m(e) && (e = J(t, e));
                    const {
                        patchPlugin_: n
                    } = t;
                    n && n.generateReplacementPatches_(r[i].base_, e, t)
                } else e = J(t, r);
                return function(e, t, r = !1) {
                    !e.parent_ && e.immer_.autoFreeze_ && e.canAutoFreeze_ && N(t, r)
                }(t, e, !0), G(t), t.patches_ && t.patchListener_(t.patches_, t.inversePatches_), e !== n ? e : void 0
            }

            function J(e, t) {
                if (D(t)) return t;
                const r = t[i];
                if (!r) {
                    return oe(t, e.handledSet_, e)
                }
                if (!Z(r, e)) return t;
                if (!r.modified_) return r.base_;
                if (!r.finalized_) {
                    const {
                        callbacks_: t
                    } = r;
                    if (t)
                        for (; t.length > 0;) {
                            t.pop()(e)
                        }
                    re(r, e)
                }
                return r.copy_
            }

            function Q(e) {
                e.finalized_ = !0, e.scope_.unfinalizedDrafts_--
            }
            var Z = (e, t) => e.scope_ === t,
                ee = [];

            function te(e, t, r, n) {
                const o = P(e),
                    i = e.type_;
                if (void 0 !== n) {
                    if (S(o, n, i) === t) return void x(o, n, r, i)
                }
                if (!e.draftLocations_) {
                    const t = e.draftLocations_ = new Map;
                    b(o, ((e, r) => {
                        if (h(r)) {
                            const n = t.get(r) || [];
                            n.push(e), t.set(r, n)
                        }
                    }))
                }
                const a = e.draftLocations_.get(t) ? ? ee;
                for (const e of a) x(o, e, r, i)
            }

            function re(e, t) {
                if (e.modified_ && !e.finalized_ && (3 === e.type_ || 1 === e.type_ && e.allIndicesReassigned_ || (e.assigned_ ? .size ? ? 0) > 0)) {
                    const {
                        patchPlugin_: r
                    } = t;
                    if (r) {
                        const n = r.getPath(e);
                        n && r.generatePatches_(e, n, t)
                    }
                    Q(e)
                }
            }

            function ne(e, t, r) {
                const {
                    scope_: n
                } = e;
                if (h(r)) {
                    const o = r[i];
                    Z(o, n) && o.callbacks_.push((function() {
                        ue(e);
                        const n = M(o);
                        te(e, r, n, t)
                    }))
                } else m(r) && e.callbacks_.push((function() {
                    const o = P(e);
                    3 === e.type_ ? o.has(r) && oe(r, n.handledSet_, n) : S(o, t, e.type_) === r && n.drafts_.length > 1 && !0 === (e.assigned_.get(t) ? ? !1) && e.copy_ && oe(S(e.copy_, t, e.type_), n.handledSet_, n)
                }))
            }

            function oe(e, t, r) {
                return !r.immer_.autoFreeze_ && r.unfinalizedDrafts_ < 1 || h(e) || t.has(e) || !m(e) || D(e) || (t.add(e), b(e, ((n, o) => {
                    if (h(o)) {
                        const t = o[i];
                        if (Z(t, r)) {
                            const r = M(t);
                            x(e, n, r, e.type_), Q(t)
                        }
                    } else m(o) && oe(o, t, r)
                }))), e
            }
            var ie = {
                    get(e, t) {
                        if (t === i) return e;
                        let r = e.scope_.arrayMethodsPlugin_;
                        const n = 1 === e.type_ && "string" == typeof t;
                        if (n && r ? .isArrayOperationMethod(t)) return r.createMethodInterceptor(e, t);
                        const o = P(e);
                        if (!k(o, t, e.type_)) return function(e, t, r) {
                            const n = ce(t, r);
                            return n ? f in n ? n[f] : n.get ? .call(e.draft_) : void 0
                        }(e, o, t);
                        const a = o[t];
                        if (e.finalized_ || !m(a)) return a;
                        if (n && e.operationMethod && r ? .isMutatingArrayMethod(e.operationMethod) && function(e) {
                                const t = +e;
                                return Number.isInteger(t) && String(t) === e
                            }(t)) return a;
                        if (a === se(e.base_, t)) {
                            ue(e);
                            const r = 1 === e.type_ ? +t : t,
                                n = _e(e.scope_, a, e, r);
                            return e.copy_[r] = n
                        }
                        return a
                    },
                    has(e, t) {
                        return t in P(e)
                    },
                    ownKeys(e) {
                        return Reflect.ownKeys(P(e))
                    },
                    set(e, t, r) {
                        const n = ce(P(e), t);
                        if (n ? .set) return n.set.call(e.draft_, r), !0;
                        if (!e.modified_) {
                            const n = se(P(e), t),
                                s = n ? .[i];
                            if (s && s.base_ === r) return e.copy_[t] = r, e.assigned_.set(t, !1), !0;
                            if (((o = r) === (a = n) ? 0 !== o || 1 / o == 1 / a : o != o && a != a) && (void 0 !== r || k(e.base_, t, e.type_))) return !0;
                            ue(e), le(e)
                        }
                        var o, a;
                        return e.copy_[t] === r && (void 0 !== r || t in e.copy_) || Number.isNaN(r) && Number.isNaN(e.copy_[t]) || (e.copy_[t] = r, e.assigned_.set(t, !0), ne(e, t, r)), !0
                    },
                    deleteProperty(e, t) {
                        return ue(e), void 0 !== se(e.base_, t) || t in e.base_ ? (e.assigned_.set(t, !1), le(e)) : e.assigned_.delete(t), e.copy_ && delete e.copy_[t], !0
                    },
                    getOwnPropertyDescriptor(e, t) {
                        const r = P(e),
                            n = Reflect.getOwnPropertyDescriptor(r, t);
                        return n ? {
                            [p]: !0,
                            [_]: 1 !== e.type_ || "length" !== t,
                            [d]: n[d],
                            [f]: r[t]
                        } : n
                    },
                    defineProperty() {
                        a(11)
                    },
                    getPrototypeOf(e) {
                        return c(e.base_)
                    },
                    setPrototypeOf() {
                        a(12)
                    }
                },
                ae = {};
            for (let e in ie) {
                let t = ie[e];
                ae[e] = function() {
                    const e = arguments;
                    return e[0] = e[0][0], t.apply(this, e)
                }
            }

            function se(e, t) {
                const r = e[i];
                return (r ? P(r) : e)[t]
            }

            function ce(e, t) {
                if (!(t in e)) return;
                let r = c(e);
                for (; r;) {
                    const e = Object.getOwnPropertyDescriptor(r, t);
                    if (e) return e;
                    r = c(r)
                }
            }

            function le(e) {
                e.modified_ || (e.modified_ = !0, e.parent_ && le(e.parent_))
            }

            function ue(e) {
                e.copy_ || (e.assigned_ = new Map, e.copy_ = I(e.base_, e.scope_.immer_.useStrictShallowCopy_))
            }
            ae.deleteProperty = function(e, t) {
                return ae.set.call(this, e, t, void 0)
            }, ae.set = function(e, t, r) {
                return ie.set.call(this, e[0], t, r, e[0])
            };

            function _e(e, t, r, n) {
                const [o, i] = E(t) ? U(j).proxyMap_(t, r) : T(t) ? U(j).proxySet_(t, r) : function(e, t) {
                    const r = C(e),
                        n = {
                            type_: r ? 1 : 0,
                            scope_: t ? t.scope_ : B(),
                            modified_: !1,
                            finalized_: !1,
                            assigned_: void 0,
                            parent_: t,
                            base_: e,
                            draft_: null,
                            copy_: null,
                            revoke_: null,
                            isManual_: !1,
                            callbacks_: void 0
                        };
                    let o = n,
                        i = ie;
                    r && (o = [n], i = ae);
                    const {
                        revoke: a,
                        proxy: s
                    } = Proxy.revocable(o, i);
                    return n.draft_ = s, n.revoke_ = a, [s, n]
                }(t, r);
                return (r ? .scope_ ? ? B()).drafts_.push(o), i.callbacks_ = r ? .callbacks_ ? ? [], i.key_ = n, r && void 0 !== n ? function(e, t, r) {
                    e.callbacks_.push((function(n) {
                        const o = t;
                        if (!o || !Z(o, n)) return;
                        n.mapSetPlugin_ ? .fixSetContents(o);
                        const i = M(o);
                        te(e, o.draft_ ? ? o, i, r), re(o, n)
                    }))
                }(r, i, n) : i.callbacks_.push((function(e) {
                    e.mapSetPlugin_ ? .fixSetContents(i);
                    const {
                        patchPlugin_: t
                    } = e;
                    i.modified_ && t && t.generatePatches_(i, [], e)
                })), o
            }

            function de(e) {
                if (!m(e) || D(e)) return e;
                const t = e[i];
                let r, n = !0;
                if (t) {
                    if (!t.modified_) return t.base_;
                    t.finalized_ = !0, r = I(e, t.scope_.immer_.useStrictShallowCopy_), n = t.scope_.immer_.shouldUseStrictIteration()
                } else r = I(e, !0);
                return b(r, ((e, t) => {
                    x(r, e, de(t))
                }), n), t && (t.finalized_ = !1), r
            }
            var pe = new class {
                    constructor(e) {
                        this.autoFreeze_ = !0, this.useStrictShallowCopy_ = !1, this.useStrictIteration_ = !1, this.produce = (e, t, r) => {
                            if (R(e) && !R(t)) {
                                const r = t;
                                t = e;
                                const n = this;
                                return function(e = r, ...o) {
                                    return n.produce(e, (e => t.call(this, e, ...o)))
                                }
                            }
                            let o;
                            if (R(t) || a(6), void 0 === r || R(r) || a(7), m(e)) {
                                const n = Y(this),
                                    i = _e(n, e, void 0);
                                let a = !0;
                                try {
                                    o = t(i), a = !1
                                } finally {
                                    a ? G(n) : V(n)
                                }
                                return $(n, r), K(o, n)
                            }
                            if (!e || !A(e)) {
                                if (o = t(e), void 0 === o && (o = e), o === n && (o = void 0), this.autoFreeze_ && N(o, !0), r) {
                                    const t = [],
                                        n = [];
                                    U(L).generateReplacementPatches_(e, o, {
                                        patches_: t,
                                        inversePatches_: n
                                    }), r(t, n)
                                }
                                return o
                            }
                            a(1)
                        }, this.produceWithPatches = (e, t) => {
                            if (R(e)) return (t, ...r) => this.produceWithPatches(t, (t => e(t, ...r)));
                            let r, n;
                            return [this.produce(e, t, ((e, t) => {
                                r = e, n = t
                            })), r, n]
                        }, O(e ? .autoFreeze) && this.setAutoFreeze(e.autoFreeze), O(e ? .useStrictShallowCopy) && this.setUseStrictShallowCopy(e.useStrictShallowCopy), O(e ? .useStrictIteration) && this.setUseStrictIteration(e.useStrictIteration)
                    }
                    createDraft(e) {
                        m(e) || a(8), h(e) && (e = function(e) {
                            h(e) || a(10);
                            return de(e)
                        }(e));
                        const t = Y(this),
                            r = _e(t, e, void 0);
                        return r[i].isManual_ = !0, V(t), r
                    }
                    finishDraft(e, t) {
                        const r = e && e[i];
                        r && r.isManual_ || a(9);
                        const {
                            scope_: n
                        } = r;
                        return $(n, t), K(void 0, n)
                    }
                    setAutoFreeze(e) {
                        this.autoFreeze_ = e
                    }
                    setUseStrictShallowCopy(e) {
                        this.useStrictShallowCopy_ = e
                    }
                    setUseStrictIteration(e) {
                        this.useStrictIteration_ = e
                    }
                    shouldUseStrictIteration() {
                        return this.useStrictIteration_
                    }
                    applyPatches(e, t) {
                        let r;
                        for (r = t.length - 1; r >= 0; r--) {
                            const n = t[r];
                            if (0 === n.path.length && "replace" === n.op) {
                                e = n.value;
                                break
                            }
                        }
                        r > -1 && (t = t.slice(r + 1));
                        const n = U(L).applyPatches_;
                        return h(e) ? n(e, t) : this.produce(e, (e => n(e, t)))
                    }
                },
                fe = pe.produce,
                he = r(14644);

            function me(e) {
                return ({
                    dispatch: t,
                    getState: r
                }) => n => o => "function" == typeof o ? o(t, r, e) : n(o)
            }
            var ye = me(),
                ge = me,
                ve = "undefined" != typeof window && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ : function() {
                    if (0 !== arguments.length) return "object" == typeof arguments[0] ? he.Zz : he.Zz.apply(null, arguments)
                },
                be = ("undefined" != typeof window && window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__, e => e && "function" == typeof e.match);

            function we(e, t) {
                function r(...r) {
                    if (t) {
                        let n = t(...r);
                        if (!n) throw new Error(Rt(0));
                        return {
                            type: e,
                            payload: n.payload,
                            ..."meta" in n && {
                                meta: n.meta
                            },
                            ..."error" in n && {
                                error: n.error
                            }
                        }
                    }
                    return {
                        type: e,
                        payload: r[0]
                    }
                }
                return r.toString = () => `${e}`, r.type = e, r.match = t => (0, he.ve)(t) && t.type === e, r
            }
            var ke = class _Tuple extends Array {
                constructor(...e) {
                    super(...e), Object.setPrototypeOf(this, _Tuple.prototype)
                }
                static get[Symbol.species]() {
                    return _Tuple
                }
                concat(...e) {
                    return super.concat.apply(this, e)
                }
                prepend(...e) {
                    return 1 === e.length && Array.isArray(e[0]) ? new _Tuple(...e[0].concat(this)) : new _Tuple(...e.concat(this))
                }
            };

            function Se(e) {
                return m(e) ? fe(e, (() => {})) : e
            }

            function xe(e, t, r) {
                return e.has(t) ? e.get(t) : e.set(t, r(t)).get(t)
            }
            var Ce = () => function(e) {
                    const {
                        thunk: t = !0,
                        immutableCheck: r = !0,
                        serializableCheck: n = !0,
                        actionCreatorCheck: o = !0
                    } = e ? ? {};
                    let i = new ke;
                    return t && ("boolean" == typeof t ? i.push(ye) : i.push(ge(t.extraArgument))), i
                },
                Ee = "RTK_autoBatch",
                Te = e => t => {
                    setTimeout(t, e)
                },
                Ae = (e = {
                    type: "raf"
                }) => t => (...r) => {
                    const n = t(...r);
                    let o = !0,
                        i = !1,
                        a = !1;
                    const s = new Set,
                        c = "tick" === e.type ? queueMicrotask : "raf" === e.type ? "undefined" != typeof window && window.requestAnimationFrame ? (l = window.requestAnimationFrame, u = 100, e => {
                            let t = !1;
                            const r = () => {
                                    t || (t = !0, cancelAnimationFrame(n), clearTimeout(o), e())
                                },
                                n = l(r),
                                o = setTimeout(r, u)
                        }) : Te(10) : "callback" === e.type ? e.queueNotification : Te(e.timeout);
                    var l, u;
                    const _ = () => {
                        a = !1, i && (i = !1, s.forEach((e => e())))
                    };
                    return Object.assign({}, n, {
                        subscribe(e) {
                            const t = n.subscribe((() => o && e()));
                            return s.add(e), () => {
                                t(), s.delete(e)
                            }
                        },
                        dispatch(e) {
                            try {
                                return o = !e ? .meta ? .[Ee], i = !o, i && (a || (a = !0, c(_))), n.dispatch(e)
                            } finally {
                                o = !0
                            }
                        }
                    })
                },
                Re = e => function(t) {
                    const {
                        autoBatch: r = !0
                    } = t ? ? {};
                    let n = new ke(e);
                    return r && n.push(Ae("object" == typeof r ? r : void 0)), n
                };

            function Oe(e) {
                const t = Ce(),
                    {
                        reducer: r,
                        middleware: n,
                        devTools: o = !0,
                        duplicateMiddlewareCheck: i = !0,
                        preloadedState: a,
                        enhancers: s
                    } = e || {};
                let c, l;
                if ("function" == typeof r) c = r;
                else {
                    if (!(0, he.Qd)(r)) throw new Error(Rt(1));
                    c = (0, he.HY)(r)
                }
                l = "function" == typeof n ? n(t) : t();
                let u = he.Zz;
                o && (u = ve({
                    trace: !1,
                    ..."object" == typeof o && o
                }));
                const _ = (0, he.Tw)(...l),
                    d = Re(_);
                const p = u(..."function" == typeof s ? s(d) : d());
                return (0, he.y$)(c, a, p)
            }

            function Pe(e) {
                const t = {},
                    r = [];
                let n;
                const o = {
                    addCase(e, r) {
                        const n = "string" == typeof e ? e : e.type;
                        if (!n) throw new Error(Rt(28));
                        if (n in t) throw new Error(Rt(29));
                        return t[n] = r, o
                    },
                    addAsyncThunk(e, n) {
                        return n.pending && (t[e.pending.type] = n.pending), n.rejected && (t[e.rejected.type] = n.rejected), n.fulfilled && (t[e.fulfilled.type] = n.fulfilled), n.settled && r.push({
                            matcher: e.settled,
                            reducer: n.settled
                        }), o
                    },
                    addMatcher(e, t) {
                        return r.push({
                            matcher: e,
                            reducer: t
                        }), o
                    },
                    addDefaultCase(e) {
                        return n = e, o
                    }
                };
                return e(o), [t, r, n]
            }

            function Me(e, t) {
                let r, [n, o, i] = Pe(t);
                if ("function" == typeof e) r = () => Se(e());
                else {
                    const t = Se(e);
                    r = () => t
                }

                function a(e = r(), t) {
                    let a = [n[t.type], ...o.filter((({
                        matcher: e
                    }) => e(t))).map((({
                        reducer: e
                    }) => e))];
                    return 0 === a.filter((e => !!e)).length && (a = [i]), a.reduce(((e, r) => {
                        if (r) {
                            if (h(e)) {
                                const n = r(e, t);
                                return void 0 === n ? e : n
                            }
                            if (m(e)) return fe(e, (e => r(e, t))); {
                                const n = r(e, t);
                                if (void 0 === n) {
                                    if (null === e) return e;
                                    throw Error("A case reducer on a non-draftable value must not return undefined")
                                }
                                return n
                            }
                        }
                        return e
                    }), e)
                }
                return a.getInitialState = r, a
            }
            var Ie = (e, t) => be(e) ? e.match(t) : e(t);

            function Ne(...e) {
                return t => e.some((e => Ie(e, t)))
            }

            function Fe(e, t) {
                if (!e || !e.meta) return !1;
                const r = "string" == typeof e.meta.requestId,
                    n = t.indexOf(e.meta.requestStatus) > -1;
                return r && n
            }

            function De(e) {
                return "function" == typeof e[0] && "pending" in e[0] && "fulfilled" in e[0] && "rejected" in e[0]
            }

            function je(...e) {
                return 0 === e.length ? e => Fe(e, ["fulfilled"]) : De(e) ? Ne(...e.map((e => e.fulfilled))) : je()(e[0])
            }
            var Le = (e = 21) => {
                    let t = "",
                        r = e;
                    for (; r--;) t += "ModuleSymbhasOwnPr-0123456789ABCDEFGHNRVfgctiUvz_KqYTJkLxpZXIjQW" [64 * Math.random() | 0];
                    return t
                },
                We = ["name", "message", "stack", "code"],
                ze = class {
                    constructor(e, t) {
                        this.payload = e, this.meta = t
                    }
                    payload;
                    meta;
                    _type
                },
                Ue = class {
                    constructor(e, t) {
                        this.payload = e, this.meta = t
                    }
                    payload;
                    meta;
                    _type
                },
                He = e => {
                    if ("object" == typeof e && null !== e) {
                        const t = {};
                        for (const r of We) "string" == typeof e[r] && (t[r] = e[r]);
                        return t
                    }
                    return {
                        message: String(e)
                    }
                },
                qe = "External signal was aborted",
                Be = (() => {
                    function e(e, t, r) {
                        const n = we(e + "/fulfilled", ((e, t, r, n) => ({
                                payload: e,
                                meta: { ...n || {},
                                    arg: r,
                                    requestId: t,
                                    requestStatus: "fulfilled"
                                }
                            }))),
                            o = we(e + "/pending", ((e, t, r) => ({
                                payload: void 0,
                                meta: { ...r || {},
                                    arg: t,
                                    requestId: e,
                                    requestStatus: "pending"
                                }
                            }))),
                            i = we(e + "/rejected", ((e, t, n, o, i) => ({
                                payload: o,
                                error: (r && r.serializeError || He)(e || "Rejected"),
                                meta: { ...i || {},
                                    arg: n,
                                    requestId: t,
                                    rejectedWithValue: !!o,
                                    requestStatus: "rejected",
                                    aborted: "AbortError" === e ? .name,
                                    condition: "ConditionError" === e ? .name
                                }
                            })));
                        return Object.assign((function(e, {
                            signal: a
                        } = {}) {
                            return (s, c, l) => {
                                const u = r ? .idGenerator ? r.idGenerator(e) : Le(),
                                    _ = new AbortController;
                                let d, p;

                                function f(e) {
                                    p = e, _.abort()
                                }
                                a && (a.aborted ? f(qe) : a.addEventListener("abort", (() => f(qe)), {
                                    once: !0
                                }));
                                const h = async function() {
                                    let a;
                                    try {
                                        let i = r ? .condition ? .(e, {
                                            getState: c,
                                            extra: l
                                        });
                                        if (null !== (h = i) && "object" == typeof h && "function" == typeof h.then && (i = await i), !1 === i || _.signal.aborted) throw {
                                            name: "ConditionError",
                                            message: "Aborted due to condition callback returning false."
                                        };
                                        const m = new Promise(((e, t) => {
                                            d = () => {
                                                t({
                                                    name: "AbortError",
                                                    message: p || "Aborted"
                                                })
                                            }, _.signal.addEventListener("abort", d, {
                                                once: !0
                                            })
                                        }));
                                        s(o(u, e, r ? .getPendingMeta ? .({
                                            requestId: u,
                                            arg: e
                                        }, {
                                            getState: c,
                                            extra: l
                                        }))), a = await Promise.race([m, Promise.resolve(t(e, {
                                            dispatch: s,
                                            getState: c,
                                            extra: l,
                                            requestId: u,
                                            signal: _.signal,
                                            abort: f,
                                            rejectWithValue: (e, t) => new ze(e, t),
                                            fulfillWithValue: (e, t) => new Ue(e, t)
                                        })).then((t => {
                                            if (t instanceof ze) throw t;
                                            return t instanceof Ue ? n(t.payload, u, e, t.meta) : n(t, u, e)
                                        }))])
                                    } catch (t) {
                                        a = t instanceof ze ? i(null, u, e, t.payload, t.meta) : i(t, u, e)
                                    } finally {
                                        d && _.signal.removeEventListener("abort", d)
                                    }
                                    var h;
                                    return r && !r.dispatchConditionRejection && i.match(a) && a.meta.condition || s(a), a
                                }();
                                return Object.assign(h, {
                                    abort: f,
                                    requestId: u,
                                    arg: e,
                                    unwrap() {
                                        return h.then($e)
                                    }
                                })
                            }
                        }), {
                            pending: o,
                            rejected: i,
                            fulfilled: n,
                            settled: Ne(i, n),
                            typePrefix: e
                        })
                    }
                    return e.withTypes = () => e, e
                })();

            function $e(e) {
                if (e.meta && e.meta.rejectedWithValue) throw e.payload;
                if (e.error) throw e.error;
                return e.payload
            }
            var Ge = Symbol.for("rtk-slice-createasyncthunk");

            function Ve(e, t) {
                return `${e}/${t}`
            }

            function Ye({
                creators: e
            } = {}) {
                const t = e ? .asyncThunk ? .[Ge];
                return function(e) {
                    const {
                        name: r,
                        reducerPath: n = r
                    } = e;
                    if (!r) throw new Error(Rt(11));
                    const o = ("function" == typeof e.reducers ? e.reducers(function() {
                            function e(e, t) {
                                return {
                                    _reducerDefinitionType: "asyncThunk",
                                    payloadCreator: e,
                                    ...t
                                }
                            }
                            return e.withTypes = () => e, {
                                reducer(e) {
                                    return Object.assign({
                                        [e.name](...t) {
                                            return e(...t)
                                        }
                                    }[e.name], {
                                        _reducerDefinitionType: "reducer"
                                    })
                                },
                                preparedReducer(e, t) {
                                    return {
                                        _reducerDefinitionType: "reducerWithPrepare",
                                        prepare: e,
                                        reducer: t
                                    }
                                },
                                asyncThunk: e
                            }
                        }()) : e.reducers) || {},
                        i = Object.keys(o),
                        a = {
                            sliceCaseReducersByName: {},
                            sliceCaseReducersByType: {},
                            actionCreators: {},
                            sliceMatchers: []
                        },
                        s = {
                            addCase(e, t) {
                                const r = "string" == typeof e ? e : e.type;
                                if (!r) throw new Error(Rt(12));
                                if (r in a.sliceCaseReducersByType) throw new Error(Rt(13));
                                return a.sliceCaseReducersByType[r] = t, s
                            },
                            addMatcher(e, t) {
                                return a.sliceMatchers.push({
                                    matcher: e,
                                    reducer: t
                                }), s
                            },
                            exposeAction(e, t) {
                                return a.actionCreators[e] = t, s
                            },
                            exposeCaseReducer(e, t) {
                                return a.sliceCaseReducersByName[e] = t, s
                            }
                        };

                    function c() {
                        const [t = {}, r = [], n] = "function" == typeof e.extraReducers ? Pe(e.extraReducers) : [e.extraReducers], o = { ...t,
                            ...a.sliceCaseReducersByType
                        };
                        return Me(e.initialState, (e => {
                            for (let t in o) e.addCase(t, o[t]);
                            for (let t of a.sliceMatchers) e.addMatcher(t.matcher, t.reducer);
                            for (let t of r) e.addMatcher(t.matcher, t.reducer);
                            n && e.addDefaultCase(n)
                        }))
                    }
                    i.forEach((n => {
                        const i = o[n],
                            a = {
                                reducerName: n,
                                type: Ve(r, n),
                                createNotation: "function" == typeof e.reducers
                            };
                        ! function(e) {
                            return "asyncThunk" === e._reducerDefinitionType
                        }(i) ? function({
                            type: e,
                            reducerName: t,
                            createNotation: r
                        }, n, o) {
                            let i, a;
                            if ("reducer" in n) {
                                if (r && ! function(e) {
                                        return "reducerWithPrepare" === e._reducerDefinitionType
                                    }(n)) throw new Error(Rt(17));
                                i = n.reducer, a = n.prepare
                            } else i = n;
                            o.addCase(e, i).exposeCaseReducer(t, i).exposeAction(t, a ? we(e, a) : we(e))
                        }(a, i, s) : function({
                            type: e,
                            reducerName: t
                        }, r, n, o) {
                            if (!o) throw new Error(Rt(18));
                            const {
                                payloadCreator: i,
                                fulfilled: a,
                                pending: s,
                                rejected: c,
                                settled: l,
                                options: u
                            } = r, _ = o(e, i, u);
                            n.exposeAction(t, _), a && n.addCase(_.fulfilled, a);
                            s && n.addCase(_.pending, s);
                            c && n.addCase(_.rejected, c);
                            l && n.addMatcher(_.settled, l);
                            n.exposeCaseReducer(t, {
                                fulfilled: a || Je,
                                pending: s || Je,
                                rejected: c || Je,
                                settled: l || Je
                            })
                        }(a, i, s, t)
                    }));
                    const l = e => e,
                        u = new Map,
                        _ = new WeakMap;
                    let d;

                    function p(e, t) {
                        return d || (d = c()), d(e, t)
                    }

                    function f() {
                        return d || (d = c()), d.getInitialState()
                    }

                    function h(t, r = !1) {
                        function n(e) {
                            let o = e[t];
                            return void 0 === o && r && (o = xe(_, n, f)), o
                        }

                        function o(t = l) {
                            const n = xe(u, r, (() => new WeakMap));
                            return xe(n, t, (() => {
                                const n = {};
                                for (const [o, i] of Object.entries(e.selectors ? ? {})) n[o] = Xe(i, t, (() => xe(_, t, f)), r);
                                return n
                            }))
                        }
                        return {
                            reducerPath: t,
                            getSelectors: o,
                            get selectors() {
                                return o(n)
                            },
                            selectSlice: n
                        }
                    }
                    const m = {
                        name: r,
                        reducer: p,
                        actions: a.actionCreators,
                        caseReducers: a.sliceCaseReducersByName,
                        getInitialState: f,
                        ...h(n),
                        injectInto(e, {
                            reducerPath: t,
                            ...r
                        } = {}) {
                            const o = t ? ? n;
                            return e.inject({
                                reducerPath: o,
                                reducer: p
                            }, r), { ...m,
                                ...h(o, !0)
                            }
                        }
                    };
                    return m
                }
            }

            function Xe(e, t, r, n) {
                function o(o, ...i) {
                    let a = t(o);
                    return void 0 === a && n && (a = r()), e(a, ...i)
                }
                return o.unwrapped = e, o
            }
            var Ke = Ye();

            function Je() {}
            var Qe = "listener",
                Ze = "completed",
                et = "cancelled",
                tt = `task-${et}`,
                rt = `task-${Ze}`,
                nt = `${Qe}-${et}`,
                ot = `${Qe}-${Ze}`,
                it = class {
                    constructor(e) {
                        this.code = e, this.message = `task ${et} (reason: ${e})`
                    }
                    code;
                    name = "TaskAbortError";
                    message
                },
                at = (e, t) => {
                    if ("function" != typeof e) throw new TypeError(Rt(32))
                },
                st = () => {},
                ct = (e, t = st) => (e.catch(t), e),
                lt = (e, t) => (e.addEventListener("abort", t, {
                    once: !0
                }), () => e.removeEventListener("abort", t)),
                ut = e => {
                    if (e.aborted) throw new it(e.reason)
                };

            function _t(e, t) {
                let r = st;
                return new Promise(((n, o) => {
                    const i = () => o(new it(e.reason));
                    e.aborted ? i() : (r = lt(e, i), t.finally((() => r())).then(n, o))
                })).finally((() => {
                    r = st
                }))
            }
            var dt = e => t => ct(_t(e, t).then((t => (ut(e), t)))),
                pt = e => {
                    const t = dt(e);
                    return e => t(new Promise((t => setTimeout(t, e))))
                },
                {
                    assign: ft
                } = Object,
                ht = {},
                mt = "listenerMiddleware",
                yt = (e, t) => (r, n) => {
                    at(r);
                    const o = new AbortController;
                    var i;
                    i = o, lt(e, (() => i.abort(e.reason)));
                    const a = (async (e, t) => {
                        try {
                            return await Promise.resolve(), {
                                status: "ok",
                                value: await e()
                            }
                        } catch (e) {
                            return {
                                status: e instanceof it ? "cancelled" : "rejected",
                                error: e
                            }
                        } finally {
                            t ? .()
                        }
                    })((async () => {
                        ut(e), ut(o.signal);
                        const t = await r({
                            pause: dt(o.signal),
                            delay: pt(o.signal),
                            signal: o.signal
                        });
                        return ut(o.signal), t
                    }), (() => o.abort(rt)));
                    return n ? .autoJoin && t.push(a.catch(st)), {
                        result: dt(e)(a),
                        cancel() {
                            o.abort(tt)
                        }
                    }
                },
                gt = (e, t) => (r, n) => ct((async (r, n) => {
                    ut(t);
                    let o = () => {};
                    const i = [new Promise(((t, n) => {
                        let i = e({
                            predicate: r,
                            effect: (e, r) => {
                                r.unsubscribe(), t([e, r.getState(), r.getOriginalState()])
                            }
                        });
                        o = () => {
                            i(), n()
                        }
                    }))];
                    null != n && i.push(new Promise((e => setTimeout(e, n, null))));
                    try {
                        const e = await _t(t, Promise.race(i));
                        return ut(t), e
                    } finally {
                        o()
                    }
                })(r, n)),
                vt = e => {
                    let {
                        type: t,
                        actionCreator: r,
                        matcher: n,
                        predicate: o,
                        effect: i
                    } = e;
                    if (t) o = we(t).match;
                    else if (r) t = r.type, o = r.match;
                    else if (n) o = n;
                    else if (!o) throw new Error(Rt(21));
                    return at(i), {
                        predicate: o,
                        type: t,
                        effect: i
                    }
                },
                bt = ft((e => {
                    const {
                        type: t,
                        predicate: r,
                        effect: n
                    } = vt(e);
                    return {
                        id: Le(),
                        effect: n,
                        type: t,
                        predicate: r,
                        pending: new Set,
                        unsubscribe: () => {
                            throw new Error(Rt(22))
                        }
                    }
                }), {
                    withTypes: () => bt
                }),
                wt = (e, t) => {
                    const {
                        type: r,
                        effect: n,
                        predicate: o
                    } = vt(t);
                    return Array.from(e.values()).find((e => ("string" == typeof r ? e.type === r : e.predicate === o) && e.effect === n))
                },
                kt = e => {
                    e.pending.forEach((e => {
                        e.abort(nt)
                    }))
                },
                St = (e, t, r) => {
                    try {
                        e(t, r)
                    } catch (e) {
                        setTimeout((() => {
                            throw e
                        }), 0)
                    }
                },
                xt = ft(we(`${mt}/add`), {
                    withTypes: () => xt
                }),
                Ct = we(`${mt}/removeAll`),
                Et = ft(we(`${mt}/remove`), {
                    withTypes: () => Et
                }),
                Tt = (...e) => {
                    console.error(`${mt}/error`, ...e)
                },
                At = (e = {}) => {
                    const t = new Map,
                        r = new Map,
                        {
                            extra: n,
                            onError: o = Tt
                        } = e;
                    at(o);
                    const i = e => (e => (e.unsubscribe = () => t.delete(e.id), t.set(e.id, e), t => {
                        e.unsubscribe(), t ? .cancelActive && kt(e)
                    }))(wt(t, e) ? ? bt(e));
                    ft(i, {
                        withTypes: () => i
                    });
                    const a = e => {
                        const r = wt(t, e);
                        return r && (r.unsubscribe(), e.cancelActive && kt(r)), !!r
                    };
                    ft(a, {
                        withTypes: () => a
                    });
                    const s = async (e, a, s, c) => {
                            const l = new AbortController,
                                u = gt(i, l.signal),
                                _ = [];
                            try {
                                e.pending.add(l), (e => {
                                    const t = r.get(e) ? ? 0;
                                    r.set(e, t + 1)
                                })(e), await Promise.resolve(e.effect(a, ft({}, s, {
                                    getOriginalState: c,
                                    condition: (e, t) => u(e, t).then(Boolean),
                                    take: u,
                                    delay: pt(l.signal),
                                    pause: dt(l.signal),
                                    extra: n,
                                    signal: l.signal,
                                    fork: yt(l.signal, _),
                                    unsubscribe: e.unsubscribe,
                                    subscribe: () => {
                                        t.set(e.id, e)
                                    },
                                    cancelActiveListeners: () => {
                                        e.pending.forEach(((e, t, r) => {
                                            e !== l && (e.abort(nt), r.delete(e))
                                        }))
                                    },
                                    cancel: () => {
                                        l.abort(nt), e.pending.delete(l)
                                    },
                                    throwIfCancelled: () => {
                                        ut(l.signal)
                                    }
                                })))
                            } catch (e) {
                                e instanceof it || St(o, e, {
                                    raisedBy: "effect"
                                })
                            } finally {
                                await Promise.all(_), l.abort(ot), (e => {
                                    const t = r.get(e) ? ? 1;
                                    1 === t ? r.delete(e) : r.set(e, t - 1)
                                })(e), e.pending.delete(l)
                            }
                        },
                        c = ((e, t) => () => {
                            for (const e of t.keys()) kt(e);
                            e.clear()
                        })(t, r);
                    return {
                        middleware: e => r => n => {
                            if (!(0, he.ve)(n)) return r(n);
                            if (xt.match(n)) return i(n.payload);
                            if (Ct.match(n)) return void c();
                            if (Et.match(n)) return a(n.payload);
                            let l = e.getState();
                            const u = () => {
                                if (l === ht) throw new Error(Rt(23));
                                return l
                            };
                            let _;
                            try {
                                if (_ = r(n), t.size > 0) {
                                    const r = e.getState(),
                                        i = Array.from(t.values());
                                    for (const t of i) {
                                        let i = !1;
                                        try {
                                            i = t.predicate(n, r, l)
                                        } catch (e) {
                                            i = !1, St(o, e, {
                                                raisedBy: "predicate"
                                            })
                                        }
                                        i && s(t, n, e, u)
                                    }
                                }
                            } finally {
                                l = ht
                            }
                            return _
                        },
                        startListening: i,
                        stopListening: a,
                        clearListeners: c
                    }
                };

            function Rt(e) {
                return `Minified Redux Toolkit error #${e}; visit https://redux-toolkit.js.org/Errors?code=${e} for the full message or use the non-minified dev environment for full errors. `
            }
        },
        8120: (e, t, r) => {
            "use strict";
            r.d(t, {
                Mz: () => l
            });

            function n(e, t = "expected a function, instead received " + typeof e) {
                if ("function" != typeof e) throw new TypeError(t)
            }
            var o = e => Array.isArray(e) ? e : [e];

            function i(e) {
                const t = Array.isArray(e[0]) ? e[0] : e;
                return function(e, t = "expected all items to be functions, instead received the following types: ") {
                    if (!e.every((e => "function" == typeof e))) {
                        const r = e.map((e => "function" == typeof e ? `function ${e.name||"unnamed"}()` : typeof e)).join(", ");
                        throw new TypeError(`${t}[${r}]`)
                    }
                }(t, "createSelector expects all input-selectors to be functions, but received the following types: "), t
            }
            Symbol(), Object.getPrototypeOf({});
            var a = "undefined" != typeof WeakRef ? WeakRef : class {
                constructor(e) {
                    this.value = e
                }
                deref() {
                    return this.value
                }
            };

            function s(e, t = {}) {
                let r = {
                    s: 0,
                    v: void 0,
                    o: null,
                    p: null
                };
                const {
                    resultEqualityCheck: n
                } = t;
                let o, i = 0;

                function s() {
                    let t = r;
                    const {
                        length: s
                    } = arguments;
                    for (let e = 0, r = s; e < r; e++) {
                        const r = arguments[e];
                        if ("function" == typeof r || "object" == typeof r && null !== r) {
                            let e = t.o;
                            null === e && (t.o = e = new WeakMap);
                            const n = e.get(r);
                            void 0 === n ? (t = {
                                s: 0,
                                v: void 0,
                                o: null,
                                p: null
                            }, e.set(r, t)) : t = n
                        } else {
                            let e = t.p;
                            null === e && (t.p = e = new Map);
                            const n = e.get(r);
                            void 0 === n ? (t = {
                                s: 0,
                                v: void 0,
                                o: null,
                                p: null
                            }, e.set(r, t)) : t = n
                        }
                    }
                    const c = t;
                    let l;
                    if (1 === t.s) l = t.v;
                    else if (l = e.apply(null, arguments), i++, n) {
                        const e = o ? .deref ? .() ? ? o;
                        null != e && n(e, l) && (l = e, 0 !== i && i--);
                        o = "object" == typeof l && null !== l || "function" == typeof l ? new a(l) : l
                    }
                    return c.s = 1, c.v = l, l
                }
                return s.clearCache = () => {
                    r = {
                        s: 0,
                        v: void 0,
                        o: null,
                        p: null
                    }, s.resetResultsCount()
                }, s.resultsCount = () => i, s.resetResultsCount = () => {
                    i = 0
                }, s
            }

            function c(e, ...t) {
                const r = "function" == typeof e ? {
                        memoize: e,
                        memoizeOptions: t
                    } : e,
                    a = (...e) => {
                        let t, a = 0,
                            c = 0,
                            l = {},
                            u = e.pop();
                        "object" == typeof u && (l = u, u = e.pop()), n(u, `createSelector expects an output function after the inputs, but received: [${typeof u}]`);
                        const _ = { ...r,
                                ...l
                            },
                            {
                                memoize: d,
                                memoizeOptions: p = [],
                                argsMemoize: f = s,
                                argsMemoizeOptions: h = [],
                                devModeChecks: m = {}
                            } = _,
                            y = o(p),
                            g = o(h),
                            v = i(e),
                            b = d((function() {
                                return a++, u.apply(null, arguments)
                            }), ...y);
                        const w = f((function() {
                            c++;
                            const e = function(e, t) {
                                const r = [],
                                    {
                                        length: n
                                    } = e;
                                for (let o = 0; o < n; o++) r.push(e[o].apply(null, t));
                                return r
                            }(v, arguments);
                            return t = b.apply(null, e), t
                        }), ...g);
                        return Object.assign(w, {
                            resultFunc: u,
                            memoizedResultFunc: b,
                            dependencies: v,
                            dependencyRecomputations: () => c,
                            resetDependencyRecomputations: () => {
                                c = 0
                            },
                            lastResult: () => t,
                            recomputations: () => a,
                            resetRecomputations: () => {
                                a = 0
                            },
                            memoize: d,
                            argsMemoize: f
                        })
                    };
                return Object.assign(a, {
                    withTypes: () => a
                }), a
            }
            var l = c(s),
                u = Object.assign(((e, t = l) => {
                    ! function(e, t = "expected an object, instead received " + typeof e) {
                        if ("object" != typeof e) throw new TypeError(t)
                    }(e, "createStructuredSelector expects first argument to be an object where each property is a selector, instead received a " + typeof e);
                    const r = Object.keys(e);
                    return t(r.map((t => e[t])), ((...e) => e.reduce(((e, t, n) => (e[r[n]] = t, e)), {})))
                }), {
                    withTypes: () => u
                })
        },
        82513: (e, t, r) => {
            "use strict";
            r.d(t, {
                G: () => EventSource
            });
            class ParseError extends Error {
                constructor(e, t) {
                    super(e), this.name = "ParseError", this.type = t.type, this.field = t.field, this.value = t.value, this.line = t.line
                }
            }

            function n(e) {}

            function o(e) {
                if ("function" == typeof e) throw new TypeError("`callbacks` must be an object, got a function instead. Did you mean `{onEvent: fn}`?");
                const {
                    onEvent: t = n,
                    onError: r = n,
                    onRetry: o = n,
                    onComment: i
                } = e;
                let a, s = "",
                    c = !0,
                    l = "",
                    u = "";

                function _(e) {
                    if ("" === e) return l.length > 0 && t({
                        id: a,
                        event: u || void 0,
                        data: l.endsWith("\n") ? l.slice(0, -1) : l
                    }), a = void 0, l = "", void(u = "");
                    if (e.startsWith(":")) return void(i && i(e.slice(e.startsWith(": ") ? 2 : 1)));
                    const r = e.indexOf(":");
                    if (-1 === r) d(e, "", e);
                    else {
                        const t = e.slice(0, r),
                            n = " " === e[r + 1] ? 2 : 1;
                        d(t, e.slice(r + n), e)
                    }
                }

                function d(e, t, n) {
                    switch (e) {
                        case "event":
                            u = t;
                            break;
                        case "data":
                            l = `${l}${t}\n`;
                            break;
                        case "id":
                            a = t.includes("\0") ? void 0 : t;
                            break;
                        case "retry":
                            /^\d+$/.test(t) ? o(parseInt(t, 10)) : r(new ParseError(`Invalid \`retry\` value: "${t}"`, {
                                type: "invalid-retry",
                                value: t,
                                line: n
                            }));
                            break;
                        default:
                            r(new ParseError(`Unknown field "${e.length>20?`${e.slice(0,20)}…`:e}"`, {
                                type: "unknown-field",
                                field: e,
                                value: t,
                                line: n
                            }))
                    }
                }
                return {
                    feed: function(e) {
                        const t = c ? e.replace(/^\xEF\xBB\xBF/, "") : e,
                            [r, n] = function(e) {
                                const t = [];
                                let r = "",
                                    n = 0;
                                for (; n < e.length;) {
                                    const o = e.indexOf("\r", n),
                                        i = e.indexOf("\n", n);
                                    let a = -1;
                                    if (-1 !== o && -1 !== i ? a = Math.min(o, i) : -1 !== o ? a = o === e.length - 1 ? -1 : o : -1 !== i && (a = i), -1 === a) {
                                        r = e.slice(n);
                                        break
                                    } {
                                        const r = e.slice(n, a);
                                        t.push(r), n = a + 1, "\r" === e[n - 1] && "\n" === e[n] && n++
                                    }
                                }
                                return [t, r]
                            }(`${s}${t}`);
                        for (const e of r) _(e);
                        s = n, c = !1
                    },
                    reset: function(e = {}) {
                        s && e.consume && _(s), c = !0, a = void 0, l = "", u = "", s = ""
                    }
                }
            }
            class ErrorEvent extends Event {
                constructor(e, t) {
                    var r, n;
                    super(e), this.code = null != (r = null == t ? void 0 : t.code) ? r : void 0, this.message = null != (n = null == t ? void 0 : t.message) ? n : void 0
                }[Symbol.for("nodejs.util.inspect.custom")](e, t, r) {
                    return r(a(this), t)
                }[Symbol.for("Deno.customInspect")](e, t) {
                    return e(a(this), t)
                }
            }

            function i(e) {
                return e instanceof Error ? "errors" in e && Array.isArray(e.errors) ? e.errors.map(i).join(", ") : "cause" in e && e.cause instanceof Error ? `${e}: ${i(e.cause)}` : e.message : `${e}`
            }

            function a(e) {
                return {
                    type: e.type,
                    message: e.message,
                    code: e.code,
                    defaultPrevented: e.defaultPrevented,
                    cancelable: e.cancelable,
                    timeStamp: e.timeStamp
                }
            }
            var s, c, l, u, _, d, p, f, h, m, y, g, v, b, w, k, S, x, C, E, T, A, R, O = e => {
                    throw TypeError(e)
                },
                P = (e, t, r) => t.has(e) || O("Cannot " + r),
                M = (e, t, r) => (P(e, t, "read from private field"), r ? r.call(e) : t.get(e)),
                I = (e, t, r) => t.has(e) ? O("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, r),
                N = (e, t, r, n) => (P(e, t, "write to private field"), t.set(e, r), r),
                F = (e, t, r) => (P(e, t, "access private method"), r);
            class EventSource extends EventTarget {
                constructor(e, t) {
                    var r, n;
                    super(), I(this, b), this.CONNECTING = 0, this.OPEN = 1, this.CLOSED = 2, I(this, s), I(this, c), I(this, l), I(this, u), I(this, _), I(this, d), I(this, p), I(this, f, null), I(this, h), I(this, m), I(this, y, null), I(this, g, null), I(this, v, null), I(this, k, (async e => {
                        var t;
                        M(this, m).reset();
                        const {
                            body: r,
                            redirected: n,
                            status: o,
                            headers: i
                        } = e;
                        if (204 === o) return F(this, b, T).call(this, "Server sent HTTP 204, not reconnecting", 204), void this.close();
                        if (N(this, l, n ? new URL(e.url) : void 0), 200 !== o) return void F(this, b, T).call(this, `Non-200 status code (${o})`, o);
                        if (!(i.get("content-type") || "").startsWith("text/event-stream")) return void F(this, b, T).call(this, 'Invalid content type, expected "text/event-stream"', o);
                        if (M(this, s) === this.CLOSED) return;
                        N(this, s, this.OPEN);
                        const a = new Event("open");
                        if (null == (t = M(this, v)) || t.call(this, a), this.dispatchEvent(a), "object" != typeof r || !r || !("getReader" in r)) return F(this, b, T).call(this, "Invalid response body, expected a web ReadableStream", o), void this.close();
                        const c = new TextDecoder,
                            u = r.getReader();
                        let _ = !0;
                        do {
                            const {
                                done: e,
                                value: t
                            } = await u.read();
                            t && M(this, m).feed(c.decode(t, {
                                stream: !e
                            })), e && (_ = !1, M(this, m).reset(), F(this, b, A).call(this))
                        } while (_)
                    })), I(this, S, (e => {
                        N(this, h, void 0), "AbortError" !== e.name && "aborted" !== e.type && F(this, b, A).call(this, i(e))
                    })), I(this, C, (e => {
                        "string" == typeof e.id && N(this, f, e.id);
                        const t = new MessageEvent(e.event || "message", {
                            data: e.data,
                            origin: M(this, l) ? M(this, l).origin : M(this, c).origin,
                            lastEventId: e.id || ""
                        });
                        M(this, g) && (!e.event || "message" === e.event) && M(this, g).call(this, t), this.dispatchEvent(t)
                    })), I(this, E, (e => {
                        N(this, d, e)
                    })), I(this, R, (() => {
                        N(this, p, void 0), M(this, s) === this.CONNECTING && F(this, b, w).call(this)
                    }));
                    try {
                        if (e instanceof URL) N(this, c, e);
                        else {
                            if ("string" != typeof e) throw new Error("Invalid URL");
                            N(this, c, new URL(e, function() {
                                const e = "document" in globalThis ? globalThis.document : void 0;
                                return e && "object" == typeof e && "baseURI" in e && "string" == typeof e.baseURI ? e.baseURI : void 0
                            }()))
                        }
                    } catch {
                        throw function(e) {
                            const t = globalThis.DOMException;
                            return "function" == typeof t ? new t(e, "SyntaxError") : new SyntaxError(e)
                        }("An invalid or illegal string was specified")
                    }
                    N(this, m, o({
                        onEvent: M(this, C),
                        onRetry: M(this, E)
                    })), N(this, s, this.CONNECTING), N(this, d, 3e3), N(this, _, null != (r = null == t ? void 0 : t.fetch) ? r : globalThis.fetch), N(this, u, null != (n = null == t ? void 0 : t.withCredentials) && n), F(this, b, w).call(this)
                }
                get readyState() {
                    return M(this, s)
                }
                get url() {
                    return M(this, c).href
                }
                get withCredentials() {
                    return M(this, u)
                }
                get onerror() {
                    return M(this, y)
                }
                set onerror(e) {
                    N(this, y, e)
                }
                get onmessage() {
                    return M(this, g)
                }
                set onmessage(e) {
                    N(this, g, e)
                }
                get onopen() {
                    return M(this, v)
                }
                set onopen(e) {
                    N(this, v, e)
                }
                addEventListener(e, t, r) {
                    const n = t;
                    super.addEventListener(e, n, r)
                }
                removeEventListener(e, t, r) {
                    const n = t;
                    super.removeEventListener(e, n, r)
                }
                close() {
                    M(this, p) && clearTimeout(M(this, p)), M(this, s) !== this.CLOSED && (M(this, h) && M(this, h).abort(), N(this, s, this.CLOSED), N(this, h, void 0))
                }
            }
            s = new WeakMap, c = new WeakMap, l = new WeakMap, u = new WeakMap, _ = new WeakMap, d = new WeakMap, p = new WeakMap, f = new WeakMap, h = new WeakMap, m = new WeakMap, y = new WeakMap, g = new WeakMap, v = new WeakMap, b = new WeakSet, w = function() {
                N(this, s, this.CONNECTING), N(this, h, new AbortController), M(this, _)(M(this, c), F(this, b, x).call(this)).then(M(this, k)).catch(M(this, S))
            }, k = new WeakMap, S = new WeakMap, x = function() {
                var e;
                const t = {
                    mode: "cors",
                    redirect: "follow",
                    headers: {
                        Accept: "text/event-stream",
                        ...M(this, f) ? {
                            "Last-Event-ID": M(this, f)
                        } : void 0
                    },
                    cache: "no-store",
                    signal: null == (e = M(this, h)) ? void 0 : e.signal
                };
                return "window" in globalThis && (t.credentials = this.withCredentials ? "include" : "same-origin"), t
            }, C = new WeakMap, E = new WeakMap, T = function(e, t) {
                var r;
                M(this, s) !== this.CLOSED && N(this, s, this.CLOSED);
                const n = new ErrorEvent("error", {
                    code: t,
                    message: e
                });
                null == (r = M(this, y)) || r.call(this, n), this.dispatchEvent(n)
            }, A = function(e, t) {
                var r;
                if (M(this, s) === this.CLOSED) return;
                N(this, s, this.CONNECTING);
                const n = new ErrorEvent("error", {
                    code: t,
                    message: e
                });
                null == (r = M(this, y)) || r.call(this, n), this.dispatchEvent(n), N(this, p, setTimeout(M(this, R), M(this, d)))
            }, R = new WeakMap, EventSource.CONNECTING = 0, EventSource.OPEN = 1, EventSource.CLOSED = 2
        },
        71468: (e, t, r) => {
            "use strict";
            r.d(t, {
                Kq: () => te,
                Ng: () => ee,
                Pj: () => ie,
                d4: () => ue,
                wA: () => se
            });
            var n = r(96540),
                o = r(78418),
                i = n.version.startsWith("19"),
                a = Symbol.for(i ? "react.transitional.element" : "react.element"),
                s = Symbol.for("react.portal"),
                c = Symbol.for("react.fragment"),
                l = Symbol.for("react.strict_mode"),
                u = Symbol.for("react.profiler"),
                _ = Symbol.for("react.consumer"),
                d = Symbol.for("react.context"),
                p = Symbol.for("react.forward_ref"),
                f = Symbol.for("react.suspense"),
                h = Symbol.for("react.suspense_list"),
                m = Symbol.for("react.memo"),
                y = Symbol.for("react.lazy"),
                g = p,
                v = m;

            function b(e) {
                if ("object" == typeof e && null !== e) {
                    const {
                        $$typeof: t
                    } = e;
                    switch (t) {
                        case a:
                            switch (e = e.type) {
                                case c:
                                case u:
                                case l:
                                case f:
                                case h:
                                    return e;
                                default:
                                    switch (e = e && e.$$typeof) {
                                        case d:
                                        case p:
                                        case y:
                                        case m:
                                        case _:
                                            return e;
                                        default:
                                            return t
                                    }
                            }
                        case s:
                            return t
                    }
                }
            }

            function w(e, t, r, n, {
                areStatesEqual: o,
                areOwnPropsEqual: i,
                areStatePropsEqual: a
            }) {
                let s, c, l, u, _, d = !1;

                function p(d, p) {
                    const f = !i(p, c),
                        h = !o(d, s, p, c);
                    return s = d, c = p, f && h ? (l = e(s, c), t.dependsOnOwnProps && (u = t(n, c)), _ = r(l, u, c), _) : f ? (e.dependsOnOwnProps && (l = e(s, c)), t.dependsOnOwnProps && (u = t(n, c)), _ = r(l, u, c), _) : h ? function() {
                        const t = e(s, c),
                            n = !a(t, l);
                        return l = t, n && (_ = r(l, u, c)), _
                    }() : _
                }
                return function(o, i) {
                    return d ? p(o, i) : (s = o, c = i, l = e(s, c), u = t(n, c), _ = r(l, u, c), d = !0, _)
                }
            }

            function k(e) {
                return function(t) {
                    const r = e(t);

                    function n() {
                        return r
                    }
                    return n.dependsOnOwnProps = !1, n
                }
            }

            function S(e) {
                return e.dependsOnOwnProps ? Boolean(e.dependsOnOwnProps) : 1 !== e.length
            }

            function x(e, t) {
                return function(t, {
                    displayName: r
                }) {
                    const n = function(e, t) {
                        return n.dependsOnOwnProps ? n.mapToProps(e, t) : n.mapToProps(e, void 0)
                    };
                    return n.dependsOnOwnProps = !0, n.mapToProps = function(t, r) {
                        n.mapToProps = e, n.dependsOnOwnProps = S(e);
                        let o = n(t, r);
                        return "function" == typeof o && (n.mapToProps = o, n.dependsOnOwnProps = S(o), o = n(t, r)), o
                    }, n
                }
            }

            function C(e, t) {
                return (r, n) => {
                    throw new Error(`Invalid value of type ${typeof e} for ${t} argument when connecting component ${n.wrappedComponentName}.`)
                }
            }

            function E(e, t, r) {
                return { ...r,
                    ...e,
                    ...t
                }
            }

            function T(e) {
                e()
            }
            var A = {
                notify() {},
                get: () => []
            };

            function R(e, t) {
                let r, n = A,
                    o = 0,
                    i = !1;

                function a() {
                    l.onStateChange && l.onStateChange()
                }

                function s() {
                    o++, r || (r = t ? t.addNestedSub(a) : e.subscribe(a), n = function() {
                        let e = null,
                            t = null;
                        return {
                            clear() {
                                e = null, t = null
                            },
                            notify() {
                                T((() => {
                                    let t = e;
                                    for (; t;) t.callback(), t = t.next
                                }))
                            },
                            get() {
                                const t = [];
                                let r = e;
                                for (; r;) t.push(r), r = r.next;
                                return t
                            },
                            subscribe(r) {
                                let n = !0;
                                const o = t = {
                                    callback: r,
                                    next: null,
                                    prev: t
                                };
                                return o.prev ? o.prev.next = o : e = o,
                                    function() {
                                        n && null !== e && (n = !1, o.next ? o.next.prev = o.prev : t = o.prev, o.prev ? o.prev.next = o.next : e = o.next)
                                    }
                            }
                        }
                    }())
                }

                function c() {
                    o--, r && 0 === o && (r(), r = void 0, n.clear(), n = A)
                }
                const l = {
                    addNestedSub: function(e) {
                        s();
                        const t = n.subscribe(e);
                        let r = !1;
                        return () => {
                            r || (r = !0, t(), c())
                        }
                    },
                    notifyNestedSubs: function() {
                        n.notify()
                    },
                    handleChangeWrapper: a,
                    isSubscribed: function() {
                        return i
                    },
                    trySubscribe: function() {
                        i || (i = !0, s())
                    },
                    tryUnsubscribe: function() {
                        i && (i = !1, c())
                    },
                    getListeners: () => n
                };
                return l
            }
            var O = (() => !("undefined" == typeof window || void 0 === window.document || void 0 === window.document.createElement))(),
                P = (() => "undefined" != typeof navigator && "ReactNative" === navigator.product)(),
                M = (() => O || P ? n.useLayoutEffect : n.useEffect)();

            function I(e, t) {
                return e === t ? 0 !== e || 0 !== t || 1 / e == 1 / t : e != e && t != t
            }

            function N(e, t) {
                if (I(e, t)) return !0;
                if ("object" != typeof e || null === e || "object" != typeof t || null === t) return !1;
                const r = Object.keys(e),
                    n = Object.keys(t);
                if (r.length !== n.length) return !1;
                for (let n = 0; n < r.length; n++)
                    if (!Object.prototype.hasOwnProperty.call(t, r[n]) || !I(e[r[n]], t[r[n]])) return !1;
                return !0
            }
            var F = {
                    childContextTypes: !0,
                    contextType: !0,
                    contextTypes: !0,
                    defaultProps: !0,
                    displayName: !0,
                    getDefaultProps: !0,
                    getDerivedStateFromError: !0,
                    getDerivedStateFromProps: !0,
                    mixins: !0,
                    propTypes: !0,
                    type: !0
                },
                D = {
                    name: !0,
                    length: !0,
                    prototype: !0,
                    caller: !0,
                    callee: !0,
                    arguments: !0,
                    arity: !0
                },
                j = {
                    $$typeof: !0,
                    compare: !0,
                    defaultProps: !0,
                    displayName: !0,
                    propTypes: !0,
                    type: !0
                },
                L = {
                    [g]: {
                        $$typeof: !0,
                        render: !0,
                        defaultProps: !0,
                        displayName: !0,
                        propTypes: !0
                    },
                    [v]: j
                };

            function W(e) {
                return b(e) === m ? j : L[e.$$typeof] || F
            }
            var z = Object.defineProperty,
                U = Object.getOwnPropertyNames,
                H = Object.getOwnPropertySymbols,
                q = Object.getOwnPropertyDescriptor,
                B = Object.getPrototypeOf,
                $ = Object.prototype;

            function G(e, t) {
                if ("string" != typeof t) {
                    if ($) {
                        const r = B(t);
                        r && r !== $ && G(e, r)
                    }
                    let r = U(t);
                    H && (r = r.concat(H(t)));
                    const n = W(e),
                        o = W(t);
                    for (let i = 0; i < r.length; ++i) {
                        const a = r[i];
                        if (!(D[a] || o && o[a] || n && n[a])) {
                            const r = q(t, a);
                            try {
                                z(e, a, r)
                            } catch (e) {}
                        }
                    }
                }
                return e
            }
            var V = Symbol.for("react-redux-context"),
                Y = "undefined" != typeof globalThis ? globalThis : {};

            function X() {
                if (!n.createContext) return {};
                const e = Y[V] ? ? = new Map;
                let t = e.get(n.createContext);
                return t || (t = n.createContext(null), e.set(n.createContext, t)), t
            }
            var K = X(),
                J = [null, null];

            function Q(e, t, r, n, o, i) {
                e.current = n, r.current = !1, o.current && (o.current = null, i())
            }

            function Z(e, t) {
                return e === t
            }
            var ee = function(e, t, r, {
                pure: o,
                areStatesEqual: i = Z,
                areOwnPropsEqual: a = N,
                areStatePropsEqual: s = N,
                areMergedPropsEqual: c = N,
                forwardRef: l = !1,
                context: u = K
            } = {}) {
                const _ = u,
                    d = function(e) {
                        return e ? "function" == typeof e ? x(e) : C(e, "mapStateToProps") : k((() => ({})))
                    }(e),
                    p = function(e) {
                        return e && "object" == typeof e ? k((t => function(e, t) {
                            const r = {};
                            for (const n in e) {
                                const o = e[n];
                                "function" == typeof o && (r[n] = (...e) => t(o(...e)))
                            }
                            return r
                        }(e, t))) : e ? "function" == typeof e ? x(e) : C(e, "mapDispatchToProps") : k((e => ({
                            dispatch: e
                        })))
                    }(t),
                    f = function(e) {
                        return e ? "function" == typeof e ? function(e) {
                            return function(t, {
                                displayName: r,
                                areMergedPropsEqual: n
                            }) {
                                let o, i = !1;
                                return function(t, r, a) {
                                    const s = e(t, r, a);
                                    return i ? n(s, o) || (o = s) : (i = !0, o = s), o
                                }
                            }
                        }(e) : C(e, "mergeProps") : () => E
                    }(r),
                    h = Boolean(e);
                return e => {
                    const t = e.displayName || e.name || "Component",
                        r = `Connect(${t})`,
                        o = {
                            shouldHandleStateChanges: h,
                            displayName: r,
                            wrappedComponentName: t,
                            WrappedComponent: e,
                            initMapStateToProps: d,
                            initMapDispatchToProps: p,
                            initMergeProps: f,
                            areStatesEqual: i,
                            areStatePropsEqual: s,
                            areOwnPropsEqual: a,
                            areMergedPropsEqual: c
                        };

                    function u(t) {
                        const [r, i, a] = n.useMemo((() => {
                            const {
                                reactReduxForwardedRef: e,
                                ...r
                            } = t;
                            return [t.context, e, r]
                        }), [t]), s = n.useMemo((() => _), [r, _]), c = n.useContext(s), l = Boolean(t.store) && Boolean(t.store.getState) && Boolean(t.store.dispatch), u = Boolean(c) && Boolean(c.store);
                        const d = l ? t.store : c.store,
                            p = u ? c.getServerState : d.getState,
                            f = n.useMemo((() => function(e, {
                                initMapStateToProps: t,
                                initMapDispatchToProps: r,
                                initMergeProps: n,
                                ...o
                            }) {
                                return w(t(e, o), r(e, o), n(e, o), e, o)
                            }(d.dispatch, o)), [d]),
                            [m, y] = n.useMemo((() => {
                                if (!h) return J;
                                const e = R(d, l ? void 0 : c.subscription),
                                    t = e.notifyNestedSubs.bind(e);
                                return [e, t]
                            }), [d, l, c]),
                            g = n.useMemo((() => l ? c : { ...c,
                                subscription: m
                            }), [l, c, m]),
                            v = n.useRef(void 0),
                            b = n.useRef(a),
                            k = n.useRef(void 0),
                            S = n.useRef(!1),
                            x = n.useRef(!1),
                            C = n.useRef(void 0);
                        M((() => (x.current = !0, () => {
                            x.current = !1
                        })), []);
                        const E = n.useMemo((() => () => k.current && a === b.current ? k.current : f(d.getState(), a)), [d, a]),
                            T = n.useMemo((() => e => m ? function(e, t, r, n, o, i, a, s, c, l, u) {
                                if (!e) return () => {};
                                let _ = !1,
                                    d = null;
                                const p = () => {
                                    if (_ || !s.current) return;
                                    const e = t.getState();
                                    let r, p;
                                    try {
                                        r = n(e, o.current)
                                    } catch (e) {
                                        p = e, d = e
                                    }
                                    p || (d = null), r === i.current ? a.current || l() : (i.current = r, c.current = r, a.current = !0, u())
                                };
                                return r.onStateChange = p, r.trySubscribe(), p(), () => {
                                    if (_ = !0, r.tryUnsubscribe(), r.onStateChange = null, d) throw d
                                }
                            }(h, d, m, f, b, v, S, x, k, y, e) : () => {}), [m]);
                        var A, O, P;
                        let I;
                        A = Q, O = [b, v, S, a, k, y], M((() => A(...O)), P);
                        try {
                            I = n.useSyncExternalStore(T, E, p ? () => f(p(), a) : E)
                        } catch (e) {
                            throw C.current && (e.message += `\nThe error may be correlated with this previous error:\n${C.current.stack}\n\n`), e
                        }
                        M((() => {
                            C.current = void 0, k.current = void 0, v.current = I
                        }));
                        const N = n.useMemo((() => n.createElement(e, { ...I,
                            ref: i
                        })), [i, e, I]);
                        return n.useMemo((() => h ? n.createElement(s.Provider, {
                            value: g
                        }, N) : N), [s, N, g])
                    }
                    const m = n.memo(u);
                    if (m.WrappedComponent = e, m.displayName = u.displayName = r, l) {
                        const t = n.forwardRef((function(e, t) {
                            return n.createElement(m, { ...e,
                                reactReduxForwardedRef: t
                            })
                        }));
                        return t.displayName = r, t.WrappedComponent = e, G(t, e)
                    }
                    return G(m, e)
                }
            };
            var te = function(e) {
                const {
                    children: t,
                    context: r,
                    serverState: o,
                    store: i
                } = e, a = n.useMemo((() => {
                    const e = R(i);
                    return {
                        store: i,
                        subscription: e,
                        getServerState: o ? () => o : void 0
                    }
                }), [i, o]), s = n.useMemo((() => i.getState()), [i]);
                M((() => {
                    const {
                        subscription: e
                    } = a;
                    return e.onStateChange = e.notifyNestedSubs, e.trySubscribe(), s !== i.getState() && e.notifyNestedSubs(), () => {
                        e.tryUnsubscribe(), e.onStateChange = void 0
                    }
                }), [a, s]);
                const c = r || K;
                return n.createElement(c.Provider, {
                    value: a
                }, t)
            };

            function re(e = K) {
                return function() {
                    return n.useContext(e)
                }
            }
            var ne = re();

            function oe(e = K) {
                const t = e === K ? ne : re(e),
                    r = () => {
                        const {
                            store: e
                        } = t();
                        return e
                    };
                return Object.assign(r, {
                    withTypes: () => r
                }), r
            }
            var ie = oe();

            function ae(e = K) {
                const t = e === K ? ie : oe(e),
                    r = () => t().dispatch;
                return Object.assign(r, {
                    withTypes: () => r
                }), r
            }
            var se = ae(),
                ce = (e, t) => e === t;

            function le(e = K) {
                const t = e === K ? ne : re(e),
                    r = (e, r = {}) => {
                        const {
                            equalityFn: i = ce
                        } = "function" == typeof r ? {
                            equalityFn: r
                        } : r;
                        const a = t(),
                            {
                                store: s,
                                subscription: c,
                                getServerState: l
                            } = a,
                            u = (n.useRef(!0), n.useCallback({
                                [e.name](t) {
                                    return e(t)
                                }
                            }[e.name], [e])),
                            _ = (0, o.useSyncExternalStoreWithSelector)(c.addNestedSub, s.getState, l || s.getState, u, i);
                        return n.useDebugValue(_), _
                    };
                return Object.assign(r, {
                    withTypes: () => r
                }), r
            }
            var ue = le()
        },
        14644: (e, t, r) => {
            "use strict";

            function n(e) {
                return `Minified Redux error #${e}; visit https://redux.js.org/Errors?code=${e} for the full message or use the non-minified dev environment for full errors. `
            }
            r.d(t, {
                HY: () => l,
                Qd: () => s,
                Tw: () => p,
                Zz: () => d,
                ve: () => f,
                y$: () => c,
                zH: () => _
            });
            var o = (() => "function" == typeof Symbol && Symbol.observable || "@@observable")(),
                i = () => Math.random().toString(36).substring(7).split("").join("."),
                a = {
                    INIT: `@@redux/INIT${i()}`,
                    REPLACE: `@@redux/REPLACE${i()}`,
                    PROBE_UNKNOWN_ACTION: () => `@@redux/PROBE_UNKNOWN_ACTION${i()}`
                };

            function s(e) {
                if ("object" != typeof e || null === e) return !1;
                let t = e;
                for (; null !== Object.getPrototypeOf(t);) t = Object.getPrototypeOf(t);
                return Object.getPrototypeOf(e) === t || null === Object.getPrototypeOf(e)
            }

            function c(e, t, r) {
                if ("function" != typeof e) throw new Error(n(2));
                if ("function" == typeof t && "function" == typeof r || "function" == typeof r && "function" == typeof arguments[3]) throw new Error(n(0));
                if ("function" == typeof t && void 0 === r && (r = t, t = void 0), void 0 !== r) {
                    if ("function" != typeof r) throw new Error(n(1));
                    return r(c)(e, t)
                }
                let i = e,
                    l = t,
                    u = new Map,
                    _ = u,
                    d = 0,
                    p = !1;

                function f() {
                    _ === u && (_ = new Map, u.forEach(((e, t) => {
                        _.set(t, e)
                    })))
                }

                function h() {
                    if (p) throw new Error(n(3));
                    return l
                }

                function m(e) {
                    if ("function" != typeof e) throw new Error(n(4));
                    if (p) throw new Error(n(5));
                    let t = !0;
                    f();
                    const r = d++;
                    return _.set(r, e),
                        function() {
                            if (t) {
                                if (p) throw new Error(n(6));
                                t = !1, f(), _.delete(r), u = null
                            }
                        }
                }

                function y(e) {
                    if (!s(e)) throw new Error(n(7));
                    if (void 0 === e.type) throw new Error(n(8));
                    if ("string" != typeof e.type) throw new Error(n(17));
                    if (p) throw new Error(n(9));
                    try {
                        p = !0, l = i(l, e)
                    } finally {
                        p = !1
                    }
                    return (u = _).forEach((e => {
                        e()
                    })), e
                }
                y({
                    type: a.INIT
                });
                return {
                    dispatch: y,
                    subscribe: m,
                    getState: h,
                    replaceReducer: function(e) {
                        if ("function" != typeof e) throw new Error(n(10));
                        i = e, y({
                            type: a.REPLACE
                        })
                    },
                    [o]: function() {
                        const e = m;
                        return {
                            subscribe(t) {
                                if ("object" != typeof t || null === t) throw new Error(n(11));

                                function r() {
                                    const e = t;
                                    e.next && e.next(h())
                                }
                                r();
                                return {
                                    unsubscribe: e(r)
                                }
                            },
                            [o]() {
                                return this
                            }
                        }
                    }
                }
            }

            function l(e) {
                const t = Object.keys(e),
                    r = {};
                for (let n = 0; n < t.length; n++) {
                    const o = t[n];
                    0, "function" == typeof e[o] && (r[o] = e[o])
                }
                const o = Object.keys(r);
                let i;
                try {
                    ! function(e) {
                        Object.keys(e).forEach((t => {
                            const r = e[t];
                            if (void 0 === r(void 0, {
                                    type: a.INIT
                                })) throw new Error(n(12));
                            if (void 0 === r(void 0, {
                                    type: a.PROBE_UNKNOWN_ACTION()
                                })) throw new Error(n(13))
                        }))
                    }(r)
                } catch (e) {
                    i = e
                }
                return function(e = {}, t) {
                    if (i) throw i;
                    let a = !1;
                    const s = {};
                    for (let i = 0; i < o.length; i++) {
                        const c = o[i],
                            l = r[c],
                            u = e[c],
                            _ = l(u, t);
                        if (void 0 === _) {
                            t && t.type;
                            throw new Error(n(14))
                        }
                        s[c] = _, a = a || _ !== u
                    }
                    return a = a || o.length !== Object.keys(e).length, a ? s : e
                }
            }

            function u(e, t) {
                return function(...r) {
                    return t(e.apply(this, r))
                }
            }

            function _(e, t) {
                if ("function" == typeof e) return u(e, t);
                if ("object" != typeof e || null === e) throw new Error(n(16));
                const r = {};
                for (const n in e) {
                    const o = e[n];
                    "function" == typeof o && (r[n] = u(o, t))
                }
                return r
            }

            function d(...e) {
                return 0 === e.length ? e => e : 1 === e.length ? e[0] : e.reduce(((e, t) => (...r) => e(t(...r))))
            }

            function p(...e) {
                return t => (r, o) => {
                    const i = t(r, o);
                    let a = () => {
                        throw new Error(n(15))
                    };
                    const s = {
                            getState: i.getState,
                            dispatch: (e, ...t) => a(e, ...t)
                        },
                        c = e.map((e => e(s)));
                    return a = d(...c)(i.dispatch), { ...i,
                        dispatch: a
                    }
                }
            }

            function f(e) {
                return s(e) && "type" in e && "string" == typeof e.type
            }
        },
        26765: e => {
            "use strict";
            e.exports = JSON.parse('{"a_b_testing_feature_description":"Test different message variations and choose the winning variable.","a_b_testing_feature_short_title":"A/B testing","a_b_testing_feature_title":"A/B testing","a_day":"A day","a_few_hours":"A few hours","a_few_minutes":"A few minutes","a_week":"A week","account_ownership_feature_description":"Set an owner for your leads and users so you can auto-assign messages to owners, get alerts, and easily monitor and message accounts.","account_ownership_feature_short_title":"Account ownership","account_ownership_feature_title":"Account ownership","action_templates_feature_description":"Connect Fin to the data sources and systems you use daily—no code required—with ready-made templates for Stripe, Shopify and more.","action_templates_feature_short_title":"Action templates","action_templates_feature_title":"Action templates","active_15m_ago":"Active in the last {minutes}m","active_day_ago":"Active {days}d ago","active_hour_ago":"Active {hours}h ago","active_minute_ago":"Active {minutes}m ago","active_state":"Active","active_week_ago":"Active over 1w ago","activities":"Activities","add_participant":"Add participant","add_person":"Add person","advanced_qualification_feature_description":"Categorize leads based on different rules so you can follow up with each category differently.","advanced_qualification_feature_short_title":"Advanced qualification","advanced_qualification_feature_title":"Advanced qualification","agree_to_privacy_policy":"By chatting with us, you agree to our {privacy_policy}.","ai_answer":"AI Answer","ai_answer_information":"AI Answer, information","ai_autofill_feature_description":"Automatically populate key information from conversations for ticket attributes.","ai_autofill_feature_short_title":"AI Autofill","ai_autofill_feature_title":"AI Autofill","ai_bot":"AI Bot","ai_category_detection_feature_description":"Fin can categorize conversations by topics in order to optimize workflows and streamlining conversation routing to your team.","ai_category_detection_feature_short_title":"AI Category Detection","ai_category_detection_feature_title":"AI Category Detection","ai_compose_feature_description":"Expand replies, rephrase answers, or change tone using AI.","ai_compose_feature_short_title":"AI Compose","ai_compose_feature_title":"AI Compose","ai_compose_my_tone_of_voice_feature_description":"Rewrites replies in your tone of voice based on your previous responses.","ai_compose_my_tone_of_voice_feature_short_title":"AI Compose (my tone of voice)","ai_compose_my_tone_of_voice_feature_title":"AI Compose (my tone of voice)","ai_generated_csat_feature_description":"For the first time ever, you can get CSAT scores across 100% of your customer conversations using AI-generated analysis.","ai_generated_csat_feature_short_title":"CX Score","ai_generated_csat_feature_title":"CX Score","ai_recommendations_feature_description":"Actionable AI-generated recommendations you can approve in one click to improve Fin’s performance.","ai_recommendations_feature_short_title":"AI Recommendations","ai_recommendations_feature_title":"AI Recommendations","ai_summarize_feature_description":"Summarize conversations in the Inbox using AI.","ai_summarize_feature_short_title":"AI Summarize","ai_summarize_feature_title":"AI Summarize","ai_summarize_workflow_feature_description":"Allow teammates to use AI Summarize to summarize conversations in workflows.","ai_summarize_workflow_feature_short_title":"AI Summarize (Workflows)","ai_summarize_workflow_feature_title":"AI Summarize (Workflows)","ai_topics_feature_description":"Automatically categorize all your support conversations into topics and suptopics.","ai_topics_feature_short_title":"AI Topics","ai_topics_feature_title":"AI Topics","alexandria_unauthorized":"You can try sending us a message or logging in at {app_name}","almost_there":"Almost there...","also_in_this_conversation":"Also in this conversation","amazing":"Amazing","animals_nature":"Animals & Nature","answer":"Answer","answer_inspection_feature_description":"See the sources and settings that shape Fin\'s responses.","answer_inspection_feature_short_title":"Answer inspection","answer_inspection_feature_title":"Answer inspection","answer_is_generated_with_ai":"This answer is based only on content specified by {company_name}. It is AI generated so may not be fully correct.","answer_is_generated_with_ai_may_be_incorrect":"This answer was auto generated using AI. There’s a chance it may not be fully correct.","answer_is_generated_with_ai_sources":"AI answers are generated based on both public and private sources provided by {company_name}.","answer_length_feature_description":"You can choose how long Fin\'s answers are, from shorter and concise, to longer and more thorough.","answer_length_feature_short_title":"Answer length","answer_length_feature_title":"Answer length","answer_rating_feature_description":"Review and rate each of Fin\'s answers.","answer_rating_feature_short_title":"Answer rating","answer_rating_feature_title":"Answer rating","app_permissions_feature_description":"Set permissions for who can install, configure, and delete apps.","app_permissions_feature_short_title":"App permissions","app_permissions_feature_title":"App permissions","april_date":"April {date}","article":"article","article_double_author":"By {author_first_name1} and {author_first_name2}","article_multiple_authors":"By {author_first_name1} and {number_of_other_authors} others","article_question":"Did this answer your question?","article_search_hint_text":"Search articles...","article_search_no_results_for_query":"No results for \\"{query}\\"","article_search_search_results":"Search results","article_search_search_results_for_query":"Search results for \\"{query}\\"","article_single_author":"By {author_first_name}","ask_a_question":"Ask a question","ask_a_question_placeholder":"Ask a question…","ask_a_question_with_ellipsis":"Ask a question...","ask_another_question_with_ellipsis":"Ask another question...","ask_anything_placeholder":"Ask anything…","ask_fin_sdr_something_to_start":"Ask Fin a question your customers might ask, to preview its response.","ask_fin_something_to_start":"Ask Fin a question your customers might ask, to preview its response.","ask_our_bot_a_question":"Ask our bot a question","asked_about":"Asked about","assign_and_snooze_conversations_feature_description":"Automatically assign conversations to the right team or teammate.","assign_and_snooze_conversations_feature_short_title":"Assign and snooze conversations","assign_and_snooze_conversations_feature_title":"Assign and snooze conversations","assigned_to_admin":"Assigned to {admin}","attach_images_or_files":"Attach images or files","attachments":"Attachments","attribute_collector_negative":"No","attribute_collector_positive":"Yes","audience_rules_not_applied":"Note: This preview does not apply audience rules","audience_testing_feature_description":"Test how Fin answers vary by audience types.","audience_testing_feature_short_title":"Audience testing","audience_testing_feature_title":"Audience testing","august_date":"August {date}","avatar":"Avatar","avatars":"Avatars","away_state":"Away","bad":"Bad","banner":"banner","banner_messages_feature_description":"Highlight important information with persistent banners in your app or website.","banner_messages_feature_short_title":"Banner messages","banner_messages_feature_title":"Banner messages","basic_chatbots_and_automations_feature_description":"Simple bots and automations for triaging conversations, qualifying leads, and gathering customer information.","basic_chatbots_and_automations_feature_short_title":"Basic automation","basic_chatbots_and_automations_feature_title":"Basic chatbots and automations","batch_testing_feature_description":"Import conversations from your support inbox, other sources to test how ready your content is for Fin.","batch_testing_feature_short_title":"Batch testing","batch_testing_feature_title":"Batch testing","bold":"Bold","book_a_meeting":"Book a meeting","bot":"Bot","bot_answers_instantly":"Bot answers instantly","bot_expectation_text":"Our bot can answer many common questions","bot_is_still_thinking":"Bot is still thinking...","bot_is_thinking":"Bot is thinking...","browse_collections":"Browse collections","bulk_whatsapp_feature_description":"WhatsApp conversations sent via the Outbound section or series, regardless of audience size.","bulk_whatsapp_feature_short_title":"WhatsApp","bulk_whatsapp_feature_title":"Bulk WhatsApp","bulleted_list":"Bulleted list","by_email":"By email","by_web_notification":"By web notification","calendar_back":"Back","calendar_booking_confirmed":"Booking confirmed","calendar_booking_failed_retry":"Booking failed - Retry","calendar_confirm_booking":"Confirm booking","calendar_expired":"Calendar expired","calendar_next_month":"Next month","calendar_no_date_selected":"No date selected","calendar_please_try_again":"Please try again.","calendar_previous_month":"Previous month","calendar_select_date":"Select a date","calendar_something_went_wrong":"Something went wrong","calendar_try_again":"Please try again.","call_barging_feature_description":"Managers can jump in during a call to help out with customer requests.","call_barging_feature_short_title":"Call barging","call_barging_feature_title":"Call barging","call_csat_feature_description":"Capture customer satisfaction ratings after the call ends.","call_csat_feature_short_title":"Call CSAT","call_csat_feature_title":"Call CSAT","call_live_monitoring_feature_description":"Managers can listen in during a call and coach agents.","call_live_monitoring_feature_short_title":"Call live monitoring","call_live_monitoring_feature_title":"Call live monitoring","call_overflow_feature_description":"Route calls to a secondary team or configure one of our call deflection options.","call_overflow_feature_short_title":"Call overflow","call_overflow_feature_title":"Call overflow","call_wrap_up_time_feature_description":"Set the amount of time agents have after a call to wrap-up before accepting new calls.","call_wrap_up_time_feature_short_title":"Call wrap-up time","call_wrap_up_time_feature_title":"Call wrap-up time","caller_id_feature_description":"Automatically identify the customer and have full context before the call starts.","caller_id_feature_short_title":"Caller ID","caller_id_feature_title":"Caller ID","can_continue_whatsapp":"You can continue your conversation on WhatsApp","cancel":"Cancel","cancel_transcription":"Cancel transcription","cant_load_new_messages":"Can\'t load new messages","captions":"Captions","carousel_add_to_cart":"Add to cart","carousel_add_to_cart_message":"Can you add {product} to my cart please","channels_category_description":"Deliver conversational support where it works best for your customers.","channels_category_title":"Channels","chat_with":"Chat with {assignee_name}","chat_with_us":"Chat with us","chats_feature_description":"Send one-off messages to specific customers.","chats_feature_short_title":"Chats","chats_feature_title":"Chats","check_later_for_updates":"Check back later for updates.","checklist_card_first_step":"First step","checklist_card_next_step":"Next step","checklist_completed":"Completed","checklist_in_progress_time_remaining_plural":"About {minutes} minutes left","checklist_in_progress_time_remaining_singular":"About 1 minute left","checklist_mark_step_as_complete":"Mark as completed","checklist_not_started_time_remaining_plural":"About {minutes} minutes","checklist_not_started_time_remaining_singular":"About 1 minute","checklist_number_of_steps_plural":"{number_of_steps} steps","checklist_number_of_steps_progress_plural":"{steps_completed} of {total_steps} done","checklist_number_of_steps_progress_singular":"1 of {total_steps} done","checklist_number_of_steps_singular":"1 step","checklist_progress":"Checklist progress: {completedChecklistTasks} of {checklistTasks} tasks completed","checklist_sender_name":"Shared by {name}","checklist_step_action_button":"Step action button","checklist_step_completed":"Completed","checklist_toggle_task_details":"Toggle task details","checklists_feature_description":"In-product message that allows you to deliver contextual and personalized lists of tasks to customers.","checklists_feature_short_title":"Checklists","checklists_feature_title":"Checklists","choose_date":"Choose date","choose_one":"Choose one…","clear":"Clear","clear_all":"Clear All","clear_recording":"Clear recording","clearbit_integration_feature_description":"Use Clearbit data to identify, target, and route website visitors.","clearbit_integration_feature_short_title":"Clearbit integration","clearbit_integration_feature_title":"Clearbit integration","click_open_whatsapp":"Click here to open WhatsApp","click_to_unmute":"Click to unmute","clickable_button":"Clickable button","close":"Close","close_intercom_messenger":"Close Intercom Messenger","code_block":"Code block","code_block_label":"Code","component":"Component","connecting":"Connecting...","contact_support":"Contact support","contact_us":"Contact us","continue_on_whatsapp":"Continue on WhatsApp","continue_the_conversation":"Continue the conversation","continue_whatsapp_instead":"You can continue the conversation on WhatsApp instead.","conversation_card_office_hours_header":"We\'ll be back online","conversation_card_reply_time_header":"Our usual reply time","conversation_card_reply_time_header_m5":"Usual reply time","conversation_card_unknown_response_time":"We’ll reply as soon as we can","conversation_data_attributes_feature_description":"Categorize all of your conversations for reporting purposes, e.g. by type, urgency, product area etc.","conversation_data_attributes_feature_short_title":"Conversation data attributes","conversation_data_attributes_feature_title":"Conversation data attributes","conversation_has_ended":"Your conversation has ended","conversation_history_feature_description":"Copilot uses your team\'s past conversation history to give your team the best possible answer.","conversation_history_feature_short_title":"Conversation history","conversation_history_feature_title":"Conversation history","conversation_history_no_recent_text":"Your recent conversations will appear here.","conversation_history_no_recent_title":"No recent conversations","conversation_monitoring_feature_description":"Easily review Fin conversations in real time right within the Inbox.","conversation_monitoring_feature_short_title":"Conversation monitoring","conversation_monitoring_feature_title":"Conversation monitoring","conversation_moved_whatsapp":"Your conversation has moved to WhatsApp","conversation_options":"Conversation options","conversation_overview":"Info","conversation_quality_feature_description":"Quickly identify areas of poor quality across all your support to understand where you need to improve.","conversation_quality_feature_short_title":"AI Insights","conversation_quality_feature_title":"AI Insights","conversation_ratings_feature_description":"Ask your customers for feedback after a conversation is closed.","conversation_ratings_feature_short_title":"Conversation ratings","conversation_ratings_feature_title":"Conversation ratings","conversation_topics_feature_description":"Define a set of keywords and phrases to include (or exclude) and any matching conversation will be automatically added to a topic.","conversation_topics_feature_short_title":"Conversation topics","conversation_topics_feature_title":"Conversation topics","conversations":"Conversations","conversations_empty_state_text":"Previous conversations will be shown here","conversations_portal_card_link_title":"Go to customer portal","conversations_portal_card_title":"Looking for your company’s conversations?","conversations_portal_card_title_restricted":"Looking for your conversations?","conversations_space_title":"Conversations","copilot_category_description":"Increase agent efficiency by 31% with a personal AI assistant in the Inbox.","copilot_category_title":"Copilot","copilot_multilingual_feature_description":"Use Copilot in 45 different languages.","copilot_multilingual_feature_short_title":"Multilingual","copilot_multilingual_feature_title":"Multilingual","copy":"Copy","copy_to_clipboard":"Copy this code block to your clipboard.","couldnt_load_app":"Couldn\'t load the app.","couldnt_load_apps":"Couldn\'t load apps.","couldnt_load_content":"Couldn\'t load the content","count_more":"{count} more","create_a_ticket":"Create a ticket","currently_no_help_articles":"There’s currently no help articles available.","custom_actions_feature_description":"Call external APIs with custom actions.","custom_actions_feature_short_title":"Custom actions","custom_actions_feature_title":"Custom actions","custom_ai_scorecards_feature_description":"Evaluate conversations against your own quality standards and business context.","custom_ai_scorecards_feature_short_title":"Custom AI Scorecards","custom_ai_scorecards_feature_title":"Custom AI Scorecards","custom_answers_feature_description":"Fin can use human-written answers with embedded rich media like maps, external data, and custom actions to give you complete control over exactly how specific, high priority or critical questions should be answered.","custom_answers_feature_short_title":"Custom Answers","custom_answers_feature_title":"Custom Answers","custom_call_reports_feature_description":"Create custom reports to dive deeper into call volume and performance data.","custom_call_reports_feature_short_title":"Custom call reports","custom_call_reports_feature_title":"Custom call reports","custom_emojis":"Custom emojis","custom_events_feature_description":"Track activity and changing data with custom events.","custom_events_feature_short_title":"Custom events","custom_events_feature_title":"Custom events","custom_objects_feature_description":"Bring in business-critical data to power automated Workflows.","custom_objects_feature_short_title":"Custom objects","custom_objects_feature_title":"Custom objects","custom_reports_feature_description":"Create custom reports and build charts using our extensive metric library and chart-building tools.","custom_reports_feature_short_title":"Advanced custom reports","custom_reports_feature_title":"Advanced custom reports","custom_response_delay_0":"Typically replies in a few minutes","custom_response_delay_1":"Typically replies in a few hours","custom_response_delay_2":"Typically replies in a day","custom_response_delay_3":"Typically replies in a week","custom_response_delay_unknown":"Will reply as soon as they can.","custom_roles_feature_description":"Create custom roles to assign consistent permissions to your team.","custom_roles_feature_short_title":"Custom roles","custom_roles_feature_title":"Custom roles","customizable_charts_feature_description":"Customizable charts used to analyze and display data on reports.","customizable_charts_feature_short_title":"Customizable charts","customizable_charts_feature_title":"Customizable charts","customizable_report_layout_feature_description":"Customize your report by resizing visuals and arranging layouts.","customizable_report_layout_feature_short_title":"Customizable report layout","customizable_report_layout_feature_title":"Customizable report layout","customize_launcher_logo_feature_description":"Display your logo on the Messenger launcher.","customize_launcher_logo_feature_short_title":"Customize launcher logo","customize_launcher_logo_feature_title":"Customize launcher logo","customized_greetings_feature_description":"Generate greetings with text to speech or upload custom audio for branded or localized messages.","customized_greetings_feature_short_title":"Customized greetings","customized_greetings_feature_title":"Customized greetings","cx_score_feature_description":"An AI-generated metric that scores the customer experience across all of your conversations.","cx_score_feature_short_title":"CX Score","cx_score_feature_title":"CX Score","data_export_feature_description":"Export Intercom data to a data warehouse.","data_export_feature_short_title":"Data export","data_export_feature_title":"Data export","data_table":"Data table","december_date":"December {date}","dictate":"Dictate","discord_feature_description":"Support customers in Discord servers from the Inbox.","discord_feature_short_title":"Discord","discord_feature_title":"Discord","discovery_launcher":"discovery launcher","discovery_mode_entry_text":"Need help?","dismiss":"Dismiss","dont_show_suggestions":"Don’t show suggestions","download_transcript":"Download transcript","download_transcript_failed":"Couldn’t download the transcript. Please try again.","drag_drop_overlay_subtitle":"They\'ll be added to your conversation","drag_drop_overlay_title":"Drop files or images here","effectiveness_report_feature_description":"Get insight into your support team\'s effectiveness and identify inefficiencies.","effectiveness_report_feature_short_title":"Effectiveness report","effectiveness_report_feature_title":"Effectiveness report","email":"Email","email_campaigns_feature_description":"Create and send targeted emails to customers.","email_campaigns_feature_short_title":"Email campaigns","email_campaigns_feature_title":"Email campaigns","emoji_picker":"Emoji picker","empty_conversations":"Messages from the team will be shown here","empty_suggestion_prompt":"No related suggestions","enable_microphone_for_voice_features":"Enable microphone access in your browser settings to use voice features.","enter_fullscreen":"Enter fullscreen","enter_text_placeholder":"Enter text…","enter_your_email":"Enter your email","exit_fullscreen":"Exit fullscreen","expand_header":"Expand header","expanded":"Expanded","expanded_mode_disable":"Collapse window","expanded_mode_enable":"Expand window","expected_response_delay_10800":"under 3 hours","expected_response_delay_120":"under 2 minutes","expected_response_delay_1200":"under 20 minutes","expected_response_delay_14400":"under 4 hours","expected_response_delay_172800":"2 days","expected_response_delay_180":"under 3 minutes","expected_response_delay_1800":"under 30 minutes","expected_response_delay_18000":"under 5 hours","expected_response_delay_21600":"under 6 hours","expected_response_delay_240":"under 4 minutes","expected_response_delay_259200":"3 days","expected_response_delay_300":"under 5 minutes","expected_response_delay_345600":"4 days","expected_response_delay_3600":"under 1 hour","expected_response_delay_43200":"under 12 hours","expected_response_delay_432000":"5 days","expected_response_delay_518400":"6 days","expected_response_delay_60":"under 1 minute","expected_response_delay_600":"under 10 minutes","expected_response_delay_604800":"under 1 week","expected_response_delay_7200":"under 2 hours","expected_response_delay_86400":"1 day","expected_response_delay_900":"under 15 minutes","export_conversation_data_feature_description":"Easily export your conversation and message data to further analyze your team\'s performance.","export_conversation_data_feature_short_title":"Export conversation data","export_conversation_data_feature_title":"Export conversation data","extended_api_limit_feature_description":"Companies requiring more API volume can extend to 30,000 calls per minute.","extended_api_limit_feature_short_title":"Extended API limit","extended_api_limit_feature_title":"Extended API limit","external_and_internal_sources_feature_description":"Copilot connects to external content (articles, public URLs, PDFs) and internal content (articles or syncs with Confluence, Notion, or Guru).","external_and_internal_sources_feature_short_title":"External & internal sources","external_and_internal_sources_feature_title":"External & internal sources","extra_labels_count":"+ {labels_count} labels","failed_message":"Failed message","failed_to_send":"Couldn\'t send","february_date":"February {date}","field_is_required":"Field {field_name} is required","file":"File","file_max_limit":"Maximum {limit} files","file_too_big":"Can\'t send files over {limit}MB","file_too_large_to_transcribe":"File too large to transcribe","file_type_not_allowed":"File type is not allowed","fin_ai_agent_category_description":"Service, Sales and Ecommerce from $0.99 per outcome","fin_ai_agent_category_title":"Fin AI Agent","fin_feature_description":"Fin is the most sophisticated AI agent in customer service, handling all of your frontline support while delivering human-quality service.","fin_feature_short_title":"Fin AI Agent","fin_feature_title":"Fin AI Agent","fin_guidance_feature_description":"Fin can learn your support policies or instructions in natural language, ensuring it always follows the correct processes with customers.","fin_guidance_feature_short_title":"Fin Guidance","fin_guidance_feature_title":"Fin Guidance","fin_knowledge_management_feature_description":"Fin\'s industry leading Knowledge Hub makes it easy for your team to control, update and maintain all of the knowledge Fin learns from in a centralized location.","fin_knowledge_management_feature_short_title":"Fin knowledge management","fin_knowledge_management_feature_title":"Fin knowledge management","fin_knowledge_sources_feature_description":"Fin instantly learns from a variety of public and private knowledge sources, including Help Center articles, internal support content, PDFs, and URLs.","fin_knowledge_sources_feature_short_title":"Knowledge sources","fin_knowledge_sources_feature_title":"Knowledge sources","fin_multi_source_generative_answers_feature_description":"Fin can construct an answer using multiple content sources, enhancing its ability to solve complex questions by using the most relevant information from each source to create a more thorough and comprehensive response.","fin_multi_source_generative_answers_feature_short_title":"Multi-source generative answers","fin_multi_source_generative_answers_feature_title":"Multi-source generative answers","fin_multilingual_feature_description":"Fin can automatically detect and resolve issues in more than 45 languages, giving you complete control over which of those languages you would like to support.","fin_multilingual_feature_short_title":"Multilingual","fin_multilingual_feature_title":"Multilingual","fin_over_api_feature_description":"Integrate Fin almost anywhere using an API connection.","fin_over_api_feature_short_title":"Fin over API","fin_over_api_feature_title":"Fin over API","fin_over_chat_email_whatsapp_sms_social_feature_description":"Fin can deliver conversational support across chat, email, WhatsApp, SMS and social channels, including Telegram and Discord.","fin_over_chat_email_whatsapp_sms_social_feature_short_title":"Fin over chat, email, WhatsApp, SMS and social","fin_over_chat_email_whatsapp_sms_social_feature_title":"Fin over chat, email, WhatsApp, SMS and social","fin_over_email_feature_description":"Fin can respond to customers over email, with responses structured in a way that feels natural to the channel. At the same time, Fin filters out phishing attempts, spam, and other threats.","fin_over_email_feature_short_title":"Fin over email","fin_over_email_feature_title":"Fin over email","fin_over_slack_feature_description":"Deliver instant, accurate answers on Slack.","fin_over_slack_feature_short_title":"Fin over Slack","fin_over_slack_feature_title":"Fin over Slack","fin_over_social_feature_description":"Fin can deliver conversational support across social channels, including Facebook and Instagram.","fin_over_social_feature_short_title":"Fin over social","fin_over_social_feature_title":"Fin over social","fin_over_whatsapp_and_sms_feature_description":"Fin can deliver conversational support across Whatsapp and SMS.","fin_over_whatsapp_and_sms_feature_short_title":"Fin over Whatsapp & SMS","fin_over_whatsapp_and_sms_feature_title":"Fin over Whatsapp & SMS","fin_over_whatsapp_feature_description":"Fin can respond to customers over WhatsApp, with responses structured in a way that feels natural to the channel.","fin_over_whatsapp_feature_short_title":"Fin over WhatsApp","fin_over_whatsapp_feature_title":"Fin over WhatsApp","fin_preview_feature_description":"See how updates to guidance, deployment settings will appear to customers in real time.","fin_preview_feature_short_title":"Fin preview","fin_preview_feature_title":"Fin preview","fin_preview_handover_message_part_one":"At this point, I’d hand the conversation over to a teammate. However this is just a preview. You can control handovers from <a href=\\"{deploy_url}\\" rel=\\"nofollow noopener noreferrer\\" target=\\"_blank\\">Deploy</a>.","fin_preview_handover_message_part_two":"To keep going, ask me another question.","fin_procedures_feature_description":"Procedures combine the flexibility of natural language with the reliability of deterministic controls, enabling Fin to resolve complex customer queries from start to finish.","fin_procedures_feature_short_title":"Fin Procedures","fin_procedures_feature_title":"Fin Procedures","fin_reply_reviewed_by":"Reviewed by {name}","fin_vision_feature_description":"Fin can read, analyze and understand images — like screenshots, invoices, and error messages.","fin_vision_feature_short_title":"Fin Vision","fin_vision_feature_title":"Fin Vision","fin_voice_feature_description":"Fin Voice is Intercom’s AI Agent for phone support.","fin_voice_feature_short_title":"Fin Voice","fin_voice_feature_title":"Fin Voice","flags":"Flags","food_drink":"Food & Drink","formatting":"Formatting","forward_to_external_number_feature_description":"Forward calls to external numbers when out of office or to connect customers with a partner.","forward_to_external_number_feature_short_title":"Forward to external number","forward_to_external_number_feature_title":"Forward to external number","frequently_used":"Frequently used","from_app":"from {app_name}","from_name":"from {name}","full_page_embedded_welcome_title":"How can Fin help?","full_page_help_article_title":"Help center article","full_page_new_conversation_label":"New conversation","full_page_no_conversations_yet":"No conversations yet","full_page_resources_section_title":"Resources","full_page_welcome_subtitle":"Your step-by-step setup guide","full_page_welcome_title":"Get started","gallery_next_image":"Next image","gallery_previous_image":"Previous image","generating_answer":"Generating answer...","generating_table":"Generating table…","generic_notification_response":"You\'ll get a notification when they reply.","get_an_instant_answer":"Get an instant answer","get_help":"Get help","get_notified":"Get notified","get_notified_by_email":"Get notified by email","get_responses_by_email":"Get replies by email","gif_attribution":"via {providername}","gif_picker":"Gif picker","gifs_load_error":"Couldn\'t load GIFs","github_integration_feature_description":"Sync GitHub issues with your conversations.","github_integration_feature_short_title":"GitHub integration","github_integration_feature_title":"GitHub integration","go_back":"Go back","go_back_to":"Go back, {destination}","go_to":"Go to {app_name}","great":"Great","group_conversation_1_other_participant_count_short":"+1 other","group_conversation_multiple_other_participant_count_short":"+{other_participant_count} others","group_conversation_multiple_person_also_participating":"{other_participant_count} others are also participating","group_conversation_name_also_participating":"{participant_name} is also participating","group_conversation_name_and_1_other_also_particiapting":"{participant_name} and 1 other are also participating","group_conversation_name_and_multiple_others_also_participating":"{participant_name} and {other_participant_count} others are also participating","group_conversation_one_person_also_participating":"1 other is also participating","handover_context_from_conversation":"Context from {conversation}","handover_context_source_conversation":"other conversation","handover_cta_conversation_created":"Separate conversation created","handover_cta_error":"Something went wrong. Please try again.","handover_cta_talk_to_team":"Talk to team","help_center_article":"Help Center Article","help_center_customization_feature_description":"Customize the visual appearance of your Help Center to keep it looking on brand.","help_center_customization_feature_short_title":"Help Center customization","help_center_customization_feature_title":"Help Center customization","help_desk_category_description":"Connect your Inbox, tickets, and help center in one central, AI-enhanced workspace.","help_desk_category_title":"Helpdesk","help_space_title":"Help","hi_name":"Hi {first_name} 👋","hi_there":"Hi <imt>first_name | fallback: \'there\'</imt> 👋","hide_messenger_feature_description":"Choose whether to hide the Messenger.","hide_messenger_feature_short_title":"Hide Messenger","hide_messenger_feature_title":"Hide Messenger","hipaa_support_feature_description":"Intercom is HIPAA compliant.","hipaa_support_feature_short_title":"HIPAA support","hipaa_support_feature_title":"HIPAA support","home_space_title":"Home","how_can_we_help":"How can we help?","how_would_you_rate_this":"How would you rate this?","hubspot_integration_feature_description":"See HubSpot data in Intercom\'s Inbox and sync leads and conversations.","hubspot_integration_feature_short_title":"HubSpot integration","hubspot_integration_feature_title":"HubSpot integration","human_handoff_feature_description":"Configure how and when Fin triages conversations or hands off to your human support team. Fin will always automatically handoff when that is the safest option for the customer.","human_handoff_feature_short_title":"Human handoff","human_handoff_feature_title":"Human handoff","image_gallery":"Image gallery","image_preview_alt":"Image preview {index} of {total}","image_previews":"Image previews","inbound_and_outbound_phone_calls_feature_description":"Customers can reach you by phone and agents receive or place in-browser through the Intercom Inbox.","inbound_and_outbound_phone_calls_feature_short_title":"Inbound and outbound phone calls","inbound_and_outbound_phone_calls_feature_title":"Inbound and outbound phone calls","inbound_email_feature_description":"Receive and reply to support emails from the Inbox, free of charge.","inbound_email_feature_short_title":"Inbound email","inbound_email_feature_title":"Inbound email","inbox_views_feature_description":"Build custom filtered views to monitor conversations in real time.","inbox_views_feature_short_title":"Inbox views","inbox_views_feature_title":"Inbox views","incident_detection_feature_description":"Surfaces emerging customer problems as they happen, so your team can respond before they escalate.","incident_detection_feature_short_title":"Incident detection","incident_detection_feature_title":"Incident detection","included_usage_feature_description":"Monthly Copilot Usage included in every core plan.","included_usage_feature_short_title":"Included usage","included_usage_feature_title":"Included usage","inline_code":"Inline code","integrated_calls_and_conversations_inbox_feature_description":"Save time by handling calls within the Intercom Inbox. Quickly follow up with customers through tickets or messaging across various channels.","integrated_calls_and_conversations_inbox_feature_short_title":"Integrated calls and conversations Inbox","integrated_calls_and_conversations_inbox_feature_title":"Integrated calls and conversations Inbox","intercom_messenger_feature_description":"Give proactive help, self-serve options, and personal assistance through chat on your website or mobile app.","intercom_messenger_feature_short_title":"Intercom Messenger","intercom_messenger_feature_title":"Intercom Messenger","italic":"Italic","january_date":"January {date}","join_conversation":"Join conversation","july_date":"July {date}","june_date":"June {date}","last_active_hours_ago":"Last active {mins} hours ago","last_active_mins_ago":"Last active {mins} mins ago","last_active_over_a_week":"Last active over 1w ago","launcher_new_message_singular":"{count} new message","launcher_new_messages_plural":"{count} new messages","learn_more":"Learn more","leave_us_a_message":"Leave us a message","leave_your_email":"Leave your email...","link":"Link","link_url":"Link URL","link_url_error":"Enter a valid URL, like https://example.com","list_placeholder":"List","lite_seats_feature_description":"Back-office teams can access Intercom as a collaborator at no extra cost.","lite_seats_feature_short_title":"Lite seats","lite_seats_feature_title":"Lite seats","live_chat_feature_description":"Support customers via live chat on the Messenger (web, iOS, Android).","live_chat_feature_short_title":"Live chat","live_chat_feature_title":"Live chat","loading":"Loading","local_and_toll_free_numbers_feature_description":"Set-up a new number or port over your existing number.","local_and_toll_free_numbers_feature_short_title":"Local and toll-free numbers","local_and_toll_free_numbers_feature_title":"Local and toll-free numbers","macros_feature_description":"Save time on repetitive tasks by creating saved replies and actions for your team.","macros_feature_short_title":"Macros","macros_feature_title":"Macros","march_date":"March {date}","marketo_integration_feature_description":"Automatically send leads and conversations to Marketo.","marketo_integration_feature_short_title":"Marketo integration","marketo_integration_feature_title":"Marketo integration","maximum_attachment_limit_reached":"Maximum attachment limit reached","may_date":"May {date}","media":"Media","message":"message","message_placeholder":"Message…","message_seen":"Seen","message_sent":"Message sent.","message_state_sending":"Sending…","message_unseen":"Not seen yet","messages_browse_articles_btn":"Browse for help","messages_empty_state_text":"Messages from the team will be shown here","messages_empty_state_title":"No messages","messages_space_title":"Messages","messenger":"messenger","messenger_app_targeting_feature_description":"Configure your Messenger\'s home screen with apps and apply targeting to different users.","messenger_app_targeting_feature_short_title":"Messenger app targeting","messenger_app_targeting_feature_title":"Messenger app targeting","messenger_bot_reply_time":"Our bot will reply instantly","messenger_calls_feature_description":"Agents can go from a live chat to a voice or video call in the Messenger for richer customer interactions.","messenger_calls_feature_short_title":"Messenger calls","messenger_calls_feature_title":"Messenger calls","messenger_screen_sharing_feature_description":"Customers can share their screen to have complex problems solved in context.","messenger_screen_sharing_feature_short_title":"Messenger screen sharing","messenger_screen_sharing_feature_title":"Messenger screen sharing","mobile_carousels_feature_description":"Highlight the best parts of your mobile app with simple-to-create, fully customizable screens.","mobile_carousels_feature_short_title":"Mobile Carousels","mobile_carousels_feature_title":"Mobile Carousels","monitors_feature_description":"Define and monitor the conversations to review quality, oversee high-risk scenarios, and track critical business moments.","monitors_feature_short_title":"Monitors","monitors_feature_title":"Monitors","more_actions":"More actions","multi_brand_email_feature_description":"Manage email settings, signatures, and notifications for multiple brands.","multi_brand_email_feature_short_title":"Multi-brand email","multi_brand_email_feature_title":"Multi-brand email","multibrand_messenger_feature_description":"Create different Messenger styles for each of your unique brands.","multibrand_messenger_feature_short_title":"Multibrand Messenger","multibrand_messenger_feature_title":"Multibrand Messenger","multilingual_help_center_feature_description":"Configure your Help Center to work in multiple languages, so you can provide self-service support in the languages your customers speak.","multilingual_help_center_feature_short_title":"Multilingual Help Center","multilingual_help_center_feature_title":"Multilingual Help Center","multiple_articles":"{total_articles} articles","multiple_collections":"{total_collection} collections","multiple_help_centers_feature_description":"Create separate knowledge bases for your different products or brands.","multiple_help_centers_feature_short_title":"Multiple Help Centers","multiple_help_centers_feature_title":"Multiple Help Centers","multiple_team_inboxes_feature_description":"Provide multiple Inboxes per team from the same workspace.","multiple_team_inboxes_feature_short_title":"Team Inboxes","multiple_team_inboxes_feature_title":"Multiple team Inboxes","mute_hold_transfer_calls_feature_description":"Mute, hold and transfer calls to other teams as needed.","mute_hold_transfer_calls_feature_short_title":"Mute, hold & transfer calls","mute_hold_transfer_calls_feature_title":"Mute, hold & transfer calls","mute_sound":"Mute sound","name_and_1_other":"{name} and 1 other","name_and_one_other":"{name} and one other","name_and_two_others":"{name} and 2 others","name_and_x_others":"{name} and {count} others","nature":"Nature","navigation_back":"Back","new":"New","new_chat":"New chat","new_conversation":"New conversation","new_message":"New message","news":"News","news_empty_title":"No news yet","news_items_feature_description":"Share contextual and relevant announcements with your customers directly in the Messenger.","news_items_feature_short_title":"News items","news_items_feature_title":"News items","news_latest_subtitle":"From Team {team_name}","news_latest_title":"Latest","news_older_title":"Older","news_space_title":"News","newsfeed":"Newsfeed","next_match":"Next match","no_articles_to_display":"No articles yet","no_conversations":"No conversations","no_emoji_found":"No emoji could be found","no_gifs_found":"No GIFs found","no_help_articles_to_display":"No help articles","no_messages_from_the_team":"No messages from the team","no_results_for_searchterm":"No results for {searchTerm}","no_tasks":"No tasks","no_tasks_available_currently":"There are currently no tasks available.","nothing_to_see_here_yet":"Nothing to see here yet","notification":"notification","november_date":"November {date}","number_is_incorrect":"That number doesn\'t look quite right","numbered_list":"Numbered list","objects":"Objects","october_date":"October {date}","office_hours_and_reply_time_feature_description":"Set office hours and reply time so customers know when to expect a reply and when you\'re out of office.","office_hours_and_reply_time_feature_short_title":"Office hours and reply time","office_hours_and_reply_time_feature_title":"Office hours and reply time","office_hours_client_response_1h":"Back in 1h","office_hours_client_response_2h":"Back in 2h","office_hours_client_response_30m":"Back in 30m","office_hours_client_response_3h":"Back in 3h","office_hours_client_response_day_0":"Back on Mon","office_hours_client_response_day_1":"Back on Tue","office_hours_client_response_day_2":"Back on Wed","office_hours_client_response_day_3":"Back on Thu","office_hours_client_response_day_4":"Back on Fri","office_hours_client_response_day_5":"Back on Sat","office_hours_client_response_day_6":"Back on Sun","office_hours_client_response_later_today":"Back later today","office_hours_client_response_next_week":"Back next week","office_hours_client_response_tomorrow":"Back tomorrow","ok_description":"OK","on_behalf_of_app":"on behalf of {app_name}","open_article_in_help_center":"Open in help center","open_conversation_and_reply":"Open conversation and reply","open_file":"Open {filename}","open_intercom_messenger":"Open Intercom Messenger","opens_in_new_tab":"opens in new tab","operator_asked_for_attribute":"Asked for {attribute}","operator_feature_description":"An agent for your customer operations. It gives your team a conversational interface for managing and improving not only Fin, but your entire customer operation.","operator_feature_short_title":"Operator","operator_feature_title":"Operator","optimize_feature_description":"Understand where Fin can resolve more conversations, and take instant action to improve performance.","optimize_feature_short_title":"Optimize Dashboard","optimize_feature_title":"Optimize Dashboard","or_click_open_whatsapp":"Or click here to open WhatsApp","or_continue_on_whatsapp_web":"Or continue on WhatsApp web","our_bot_answers_instantly":"Our bot answers instantly","overview_report_feature_description":"Analyze how Fin is impacting your resolution rates and CSAT, with a complete overview of Fin\'s performance in a pre-built, customizable report.","overview_report_feature_short_title":"Fin performance report","overview_report_feature_title":"Fin performance report","pause":"Pause","people":"People","people_body":"People & Body","performance_pro_category_description":"Add to any plan for $99/mo.","performance_pro_category_title":"Pro","personalized_answers_feature_description":"Fin uses customer information from external systems - including account, purchase and subscription history - to personalize answers for each individual customer.","personalized_answers_feature_short_title":"Personalized answers","personalized_answers_feature_title":"Personalized answers","phone_availability_controls_feature_description":"Manage team phone \'availability\' to meet phone volume.","phone_availability_controls_feature_short_title":"Phone \'availability\' controls","phone_availability_controls_feature_title":"Phone \'availability\' controls","phone_feature_description":"Make every call count. Solve customer problems faster with phone calls, video calls, and screen sharing. All within Intercom.","phone_feature_short_title":"Phone","phone_feature_title":"Phone","phone_integrations_feature_description":"Already using a call center you want to keep? Integrate your call center with Intercom so all data is synced and agents can work out of one tool.","phone_integrations_feature_short_title":"Phone integrations","phone_integrations_feature_title":"Phone integrations","phone_number":"Phone number","pipedrive_integration_feature_description":"Boost your sales by creating and tracking Pipedrive deals while you chat.","pipedrive_integration_feature_short_title":"Pipedrive integration","pipedrive_integration_feature_title":"Pipedrive integration","placeholder_datepicker":"DD-MM-YYYY","placeholder_email_input":"Enter email here...","placeholder_numerical_inputs":"Enter number here...","placeholder_text_inputs":"Enter text here...","places":"Places","plan_card_error_text":"Couldn\'t load plan.","plan_card_loading_text":"Loading plan…","plan_card_outdated_suffix":"outdated","plan_card_skeleton_subtitle":"Fin will create a tailored onboarding plan","plan_card_skeleton_title":"Setup plan","plan_card_title":"Onboarding Plan","plan_card_title_success":"Success Plan","plan_card_updated_suffix":"updated plan below","platform_category_description":"One central platform connecting everything together, from apps and automations to customer data and reporting.","platform_category_title":"Platform","play":"Play","play_sound":"Play sound","play_video":"Play video","please_select":"Please select...","plus_x_participants":"+ {count}","pointer":"pointer","post":"post","posts_feature_description":"Proactively send customers pop-up messages in your app.","posts_feature_short_title":"Posts","posts_feature_title":"Posts","powered_by_fin_ai_agent":"Powered by Fin","powered_by_intercom":"Powered by Intercom","pre_built_reports_feature_description":"Inbox comes with reports like conversations, customer satisfaction, and more.","pre_built_reports_feature_short_title":"Pre-built reports","pre_built_reports_feature_title":"Pre-built reports","preview_customer_view_empty_state_subtext":"Note: You won\'t be charged for preview conversations.","previous_match":"Previous match","privacy_policy":"Privacy Policy","private_help_center_feature_description":"Keep articles private or define a set of audience rules to control which customers can see which articles.","private_help_center_feature_short_title":"Private Help Center","private_help_center_feature_title":"Private Help Center","proactive_expected_response_delay_10800":"Typically replies in under 3h","proactive_expected_response_delay_120":"Typically replies in under 2m","proactive_expected_response_delay_1200":"Typically replies in under 20m","proactive_expected_response_delay_14400":"Typically replies in under 4h","proactive_expected_response_delay_172800":"Typically replies in 2d","proactive_expected_response_delay_180":"Typically replies in under 3m","proactive_expected_response_delay_1800":"Typically replies in under 30m","proactive_expected_response_delay_18000":"Typically replies in under 5h","proactive_expected_response_delay_21600":"Typically replies in under 6h","proactive_expected_response_delay_240":"Typically replies in under 4m","proactive_expected_response_delay_259200":"Typically replies in 3d","proactive_expected_response_delay_300":"Typically replies in under 5m","proactive_expected_response_delay_345600":"Typically replies in 4d","proactive_expected_response_delay_3600":"Typically replies in under 1h","proactive_expected_response_delay_43200":"Typically replies in 12h","proactive_expected_response_delay_432000":"Typically replies in 5d","proactive_expected_response_delay_518400":"Typically replies in 6d","proactive_expected_response_delay_60":"Typically replies in under 1m","proactive_expected_response_delay_600":"Typically replies in under 10m","proactive_expected_response_delay_604800":"Typically replies in under 1w","proactive_expected_response_delay_7200":"Typically replies in under 2h","proactive_expected_response_delay_86400":"Typically replies in 1d","proactive_expected_response_delay_900":"Typically replies in under 15m","proactive_expected_response_delay_unknown":"Will reply as soon as they can","proactive_support_category_description":"Give customers the support they need before they need it with in-context automated messages.","proactive_support_category_title":"Proactive Support","proactive_support_plus_category_description":"Give customers the support they need before they need it with in-context automated messages.","proactive_support_plus_category_title":"Proactive Support Plus","processing_recording":"Processing recording","product_tours_author":"By {name} from {company}","product_tours_done":"Done","product_tours_error":"We’re sorry, there was an unexpected issue with this tour","product_tours_error_cta":"Talk to the team","product_tours_feature_description":"Make it easy for new users to get started with automated, interactive onboarding.","product_tours_feature_short_title":"Product tours","product_tours_feature_title":"Product tours","product_tours_name":"Product tour","product_tours_next":"Next","product_tours_restart":"Restart","product_tours_snooze":"Snooze","product_tours_tour_step_number":"{start_number} of {end_number}","product_tours_view":"View tour","profile_location":"{time} in {location}","public_help_center_feature_description":"A web page for your customers to quickly and reliably find support content.","public_help_center_feature_short_title":"Public Help Center","public_help_center_feature_title":"Public Help Center","push_notifications_feature_description":"Send contextual push messages and bring customers directly into your mobile app.","push_notifications_feature_short_title":"Push notifications","push_notifications_feature_title":"Push notifications","rate_your_conversation":"Rate your conversation","rating_window_closed":"This conversation can no longer be rated","real_time_call_agent_dashboard_feature_description":"Monitor agent phone volume and performance in real-time.","real_time_call_agent_dashboard_feature_short_title":"Real-time call agent dashboard","real_time_call_agent_dashboard_feature_title":"Real-time call agent dashboard","real_time_call_team_dashboard_feature_description":"Monitor team phone volume and performance in real-time.","real_time_call_team_dashboard_feature_short_title":"Real-time call team dashboard","real_time_call_team_dashboard_feature_title":"Real-time call team dashboard","real_time_dashboard_feature_description":"Monitor your team\'s workload and capacity in real time.","real_time_dashboard_feature_short_title":"Real-time dashboard","real_time_dashboard_feature_title":"Real-time dashboard","real_time_translations_feature_description":"Fin can automatically translate support content written in any language and reply to each customer in the language they are speaking in.","real_time_translations_feature_short_title":"Real-time translations","real_time_translations_feature_title":"Real-time translations","receive_replies_there":"You\'ll receive replies there when the team replies","recent_ticket":"Recent ticket","recent_ticket_case":"Recent case","recent_tickets":"Recent tickets","recent_tickets_case":"Recent cases","reconnect":"Reconnect","recorded_days_ago":"Recorded {days} days ago","recorded_over_week_ago":"Recorded over a week ago","recorded_today":"Recorded today","recorded_yesterday":"Recorded yesterday","recordings_feature_description":"Enable call recordings for quick reference and quality assurance.","recordings_feature_short_title":"Call recordings","recordings_feature_title":"Call recordings","remove_file":"Remove file","remove_image":"Remove image {index}","remove_participant":"Remove participant","remove_person":"Remove person","reply":"Reply","reply_from":"Reply from","reply_to_conversation":"Write a reply…","reply_to_name":"Reply to {name}…","report_ai_answer":"Report AI answer","report_builder_feature_description":"Create unique reports from scratch with your choice of charts from our template library.","report_builder_feature_short_title":"Report builder","report_builder_feature_title":"Report builder","reporting_drill_downs_feature_description":"Customizable reporting drill-downs that allow use of filters.","reporting_drill_downs_feature_short_title":"Reporting drill-downs","reporting_drill_downs_feature_title":"Reporting drill-downs","reporting_feature_description":"Get insights on how many conversations are using Copilot, track teammate usage, and review the quality of Fin\'s answers.","reporting_feature_short_title":"Reporting","reporting_feature_title":"Reporting","request_callback_feature_description":"Allow customers to request a callback at a convenient time instead of waiting on hold.","request_callback_feature_short_title":"Request callback","request_callback_feature_title":"Request callback","require_email_to_chat_feature_description":"Require an email for new conversations.","require_email_to_chat_feature_short_title":"Require email to chat","require_email_to_chat_feature_title":"Require email to chat","required_fields_asterisk_explanation":"Asterisks (*) indicate required fields.","round_robin_assignment_feature_description":"Share new inbound conversations evenly among your team.","round_robin_assignment_feature_short_title":"Round-robin assignment","round_robin_assignment_feature_title":"Round-robin assignment","sales_reports_feature_description":"Track your sales team\'s performance and Intercom\'s impact on your revenue.","sales_reports_feature_short_title":"Sales reports","sales_reports_feature_title":"Sales reports","salesforce_integration_feature_description":"2-way sync of Contact, Account, and Case data between Salesforce and Intercom.","salesforce_integration_feature_short_title":"Salesforce integration","salesforce_integration_feature_title":"Salesforce integration","save":"Save","scan_qr":"Scan the QR with your phone","search":"Search","search_browse_empty_state_text":"Sorry, we couldn’t find any results for that. Try rewording your search.","search_conversation":"Search conversation","search_for_answers":"Search for answers…","search_for_emoji":"Search emoji…","search_for_help":"Search for help","search_gif":"Search GIFs…","see_all":"See all","see_all_conversations":"See all your conversations","see_past_conversations":"See previous","see_previous_conversations":"See your previous conversations","seek_video":"Seek video","select_an_option":"Please select an option:","send":"Send","send_a_message":"Send a message…","send_a_message_reply_time":"Usual reply time is","send_a_message_reply_time_card":"Usual reply time is {replyTime}","send_a_voice_note":"Send a voice note…","send_prefilled_message":"When WhatsApp opens, send the pre-filled message to continue the conversation","send_us_a_message":"Send us a message","send_us_a_message_bot":"Send us a message and our bot will reply instantly","sent_a_video":"sent a video","sent_a_voice_note":"Sent a voice note","sent_an_app":"sent an app","sent_an_attachment":"sent an attachment","sent_an_image":"sent an image","sent_you_a_video":"Sent you a video","sent_you_a_video_reply":"Sent you a video reply","sent_you_a_voice_note":"Sent you a voice note","sent_you_an_app":"Sent you an app","sent_you_an_attachment":"Sent you an attachment","sent_you_an_image":"Sent you an image","sent_you_an_interactive_message":"Sent you an interactive message","september_date":"September {date}","series_campaign_builder_feature_description":"Create cohesive targeted message sequences across channels with a no-code visual builder.","series_campaign_builder_feature_short_title":"Series campaign builder","series_campaign_builder_feature_title":"Series campaign builder","service_level_agreements_slas_feature_description":"Automatically apply SLAs to inbound conversations using rules.","service_level_agreements_slas_feature_short_title":"Service level agreements (SLAs)","service_level_agreements_slas_feature_title":"Service level agreements (SLAs)","shared_by":"Shared by","shared_inbox_feature_description":"Manage conversations from a single, collaborative Inbox.","shared_inbox_feature_short_title":"Shared Inbox","shared_inbox_feature_title":"Shared Inbox","show_admin_name":"Show admin name","show_count_more":"Show {count} more","show_less":"Show less","show_more":"Show more","side_conversations_feature_description":"Collaborate with external partners by starting a side conversation from the ticket.","side_conversations_feature_short_title":"Side conversations","side_conversations_feature_title":"Side conversations","side_panel_empty_conversation_title":"What can I help you with?","simulations_feature_description":"Simulations are a scalable way to test, evaluate, and refine Fin’s behavior and actions.","simulations_feature_short_title":"Simulations","simulations_feature_title":"Simulations","single_article":"1 article","single_collection":"1 collection","slack_integration_feature_description":"Automatically send notifications to Slack channels using Workflows.","slack_integration_feature_short_title":"Slack integration","slack_integration_feature_title":"Slack integration","smileys_emotion":"Smileys & Emotion","sms":"SMS","sms_feature_description":"Send and receive SMS text messages from the Inbox.","sms_feature_short_title":"SMS","sms_feature_title":"SMS","social_feature_description":"Integrate with Facebook and Instagram.","social_feature_short_title":"Social","social_feature_title":"Social","social_integrations_feature_description":"Integrate with Facebook and Instagram.","social_integrations_feature_short_title":"Social integrations","social_integrations_feature_title":"Social integrations","some_things_failed_to_load":"Some things failed to load. Try again.","something_is_wrong":"Something\'s wrong","sophisticated_interactive_voice_response_trees_feature_description":"Route, assign or automate calls based on user data with fully customizable multi-level IVR trees.","sophisticated_interactive_voice_response_trees_feature_short_title":"Sophisticated interactive voice response trees","sophisticated_interactive_voice_response_trees_feature_title":"Sophisticated interactive voice response trees","source":"Source","sources":"Sources","spaces_error_description":"Content could not be loaded","spaces_error_title":"Something\'s gone wrong","sso_identity_management_feature_description":"Log in to Intercom with SAML SSO using Okta, OneLogin, or another identity provider.","sso_identity_management_feature_short_title":"Single sign-on","sso_identity_management_feature_title":"SSO & identity management","standard_call_reports_feature_description":"Analyze call volume and performance trends with out-of-the-box reports.","standard_call_reports_feature_short_title":"Standard call reports","standard_call_reports_feature_title":"Standard call reports","start_a_conversation":"Start a conversation","start_another_conversation":"Start another conversation","start_dictating":"Start dictating","start_recording":"Start recording","start_recording_with_shortcut":"Start recording (hold {shortcut})","start_typing":"Start typing...","status":"Status","still_generating_answer":"Still generating answer...","still_thinking":"Still thinking...","still_working_on_it":"Still working on it...","stop_dictating":"Stop dictating","stop_recording":"Stop recording","string_is_incorrect":"That doesn\'t look quite right","submit":"Submit","successfully_reconnected":"Successfully reconnected","suggested_articles":"Suggested articles","suggested_content_prompt":"Are any of these related to your question?","suggestions_feature_description":"Actionable AI-generated suggestions you can approve in one click to improve Fin\'s performance.","suggestions_feature_short_title":"Suggestions","suggestions_feature_title":"Suggestions","survey":"Survey","surveys_all_options_response_hint":"Please select all options that apply","surveys_close_survey":"Close survey","surveys_done_button":"Done","surveys_dropdown_default_option":"Please select a response...","surveys_email_error":"Please enter a valid email address","surveys_feature_description":"Capture customer feedback and use it to create a better customer experience.","surveys_feature_short_title":"Surveys","surveys_feature_title":"Surveys","surveys_fixed_response_count_response_hint":"Please select {response_count} options","surveys_from_company":"Survey from {company}","surveys_from_teammate":"Survey by {sender_name} from {company}","surveys_multi_select_too_few_responses":"This question requires at least {response_count} options to be selected","surveys_multi_select_too_many_responses":"This question requires {response_count} options to be selected","surveys_multiselect_other_option":"Other (Please specify)","surveys_multiselect_other_option_input_label":"Please specify","surveys_multiselect_other_option_input_placeholder":"Enter response","surveys_multiselect_other_option_value":"Other","surveys_next_button":"Next","surveys_nps_lower_label":"Not likely","surveys_nps_upper_label":"Very likely","surveys_number_error":"Please enter a number","surveys_required_question":"This is a required question","surveys_required_response":"This is a required response","surveys_response_range_response_hint":"Please select a minimum of {minimum_response_count} and a maximum of {maximum_response_count} options","surveys_response_too_long":"Please keep answers to a maximum of {character_count} characters","surveys_single_response_hint":"Please select 1 option","surveys_submit_response":"Submit your response","surveys_telephone_error":"Please enter a valid telephone number","surveys_text_input_question_placeholder":"Please type your response here...","switch_phone_deflection_to_messenger_feature_description":"Reduce wait times by giving your customers the choice to switch to messaging mid-call.","switch_phone_deflection_to_messenger_feature_short_title":"Switch: phone deflection to Messenger","switch_phone_deflection_to_messenger_feature_title":"Switch: phone deflection to Messenger","symbols":"Symbols","targeting_and_scheduling_feature_description":"Decide how and Fin can show up for your customers based on audience, region, channel, and more—helping you control and maintain your support availability even when you\'re out of office.","targeting_and_scheduling_feature_short_title":"Targeting & scheduling","targeting_and_scheduling_feature_title":"Targeting & scheduling","tasks_feature_description":"Connect Fin to your data sources and systems so it can update data, enabling it to perform complex tasks on behalf of your customers.","tasks_feature_short_title":"Fin Tasks","tasks_feature_title":"Fin Tasks","tasks_space_title":"Tasks","team_name_custom_response_delay_2":"{app_name} typically replies in a day","team_name_custom_response_delay_3":"{app_name} typically replies in a week","team_name_proactive_expected_response_delay_one_business_day":"{app_name} typically replies in one business day","team_name_proactive_expected_response_delay_two_business_days":"{app_name} typically replies in two business days","team_office_hours_and_reply_time_feature_description":"Set unique office hours and reply times for each team to better set customer expectations.","team_office_hours_and_reply_time_feature_short_title":"Team office hours and reply time","team_office_hours_and_reply_time_feature_title":"Team office hours and reply time","team_performance_reports_feature_description":"Easily measure and compare your team\'s performance.","team_performance_reports_feature_short_title":"Team performance reports","team_performance_reports_feature_title":"Team performance reports","team_routing_feature_description":"Specify the teams for call routing to ensure customers connect with the right agent.","team_routing_feature_short_title":"Team routing","team_routing_feature_title":"Team routing","teammate_calendar_link":"Teammate calendar","teammate_inactivity_feature_description":"Trigger rules when a teammate hasn\'t replied to a new conversation in a specified time.","teammate_inactivity_feature_short_title":"Teammate inactivity","teammate_inactivity_feature_title":"Teammate inactivity","teammate_profile":"{provider} teammate profile","telegram_feature_description":"Send and receive Telegram messages from the Inbox.","telegram_feature_short_title":"Telegram","telegram_feature_title":"Telegram","tell_us_more":"Tell us more…","tell_us_what_you_need":"Tell us what you need help with and our bot will do its best to answer","terrible":"Terrible","thank_you":"Thank you","thanks_custom_response_delay_one_business_day":"Thanks! The team will reply in one business day","thanks_custom_response_delay_two_business_days":"Thanks! The team will reply in two business days","thanks_for_letting_us_know":"Thanks for letting us know","thanks_proactive_expected_response_delay_unknown":"Thanks! The team will reply as soon as they can","that_country_code_doesnt_look_quite_right":"That country code doesn\'t look quite right","that_email_address_doesnt_look_quite_right":"That email doesn\'t look quite right","that_number_doesnt_look_quite_right":"That number doesn\'t look quite right","that_number_has_too_many_digits":"That number has too many digits","that_number_is_missing_a_few_digits":"That number is missing a few digits","that_number_needs_a_prefix":"That number needs a prefix (+ or 00)","the_team_can_help_if_needed":"The team can help if needed","the_team_typically_replies_in_10800":"The team typically replies in under 3h","the_team_typically_replies_in_120":"The team typically replies in under 2m","the_team_typically_replies_in_1200":"The team typically replies in under 20m","the_team_typically_replies_in_14400":"The team typically replies in under 4h","the_team_typically_replies_in_172800":"The team typically replies in 2d","the_team_typically_replies_in_180":"The team typically replies in under 3m","the_team_typically_replies_in_1800":"The team typically replies in under 30m","the_team_typically_replies_in_18000":"The team typically replies in under 5h","the_team_typically_replies_in_21600":"The team typically replies in under 6h","the_team_typically_replies_in_240":"The team typically replies in under 4m","the_team_typically_replies_in_259200":"The team typically replies in 3d","the_team_typically_replies_in_300":"The team typically replies in under 5m","the_team_typically_replies_in_345600":"The team typically replies in 4d","the_team_typically_replies_in_3600":"The team typically replies in under 1h","the_team_typically_replies_in_43200":"The team typically replies in under 12h","the_team_typically_replies_in_432000":"The team typically replies in 5d","the_team_typically_replies_in_518400":"The team typically replies in 6d","the_team_typically_replies_in_60":"The team typically replies in under 1m","the_team_typically_replies_in_600":"The team typically replies in under 10m","the_team_typically_replies_in_604800":"The team typically replies in under 1w","the_team_typically_replies_in_7200":"The team typically replies in under 2h","the_team_typically_replies_in_86400":"The team typically replies in 1d","the_team_typically_replies_in_900":"The team typically replies in under 15m","the_team_typically_replies_in_day":"The team typically replies in a day.","the_team_typically_replies_in_hours":"The team typically replies in a few hours.","the_team_typically_replies_in_minutes":"The team typically replies in a few minutes.","the_team_typically_replies_in_one_business_day":"The team typically replies in one business day.","the_team_typically_replies_in_two_business_days":"The team typically replies in two business days","the_team_typically_replies_in_under_n_hours":"The team typically replies in under {hours}h.","the_team_typically_replies_in_under_n_min":"The team typically replies in under {minutes}m.","the_team_typically_replies_in_unknown":"The team will reply as soon as they can","the_team_typically_replies_in_week":"The team typically replies in a week.","thinking":"Thinking...","this_chat_is_powered_by_intercom":"This chat is powered by Intercom","ticket_could_not_be_created":"Ticket could not be created","ticket_create_ticket_with_type_title":"Create {ticket_type_title} ticket","ticket_current_status":"Current status: {current_status_title}","ticket_current_status_with_date":"Current status: {current_status_title}, {date}","ticket_data_attributes_feature_description":"Create ticket types and attributes.","ticket_data_attributes_feature_short_title":"Ticket data attributes","ticket_data_attributes_feature_title":"Ticket data attributes","ticket_details_attributes_accessibility_text":"Ticket attributes;","ticket_details_for_title":"Ticket details for {title}","ticket_details_notification_detail":"You will be notified here and via email at","ticket_forms_feature_description":"Collect information upfront through a bot in Messenger or directly in your product.","ticket_forms_feature_short_title":"Ticket forms","ticket_forms_feature_title":"Ticket forms","ticket_has_been_created":"Ticket has been created","ticket_has_been_created_case":"Case has been created","ticket_has_been_updated":"Ticket has been updated","ticket_has_been_updated_case":"Case has been updated","ticket_portal_card_link_title":"Go to ticket portal","ticket_portal_card_title":"Looking for your company’s tickets?","ticket_portal_card_title_case":"Looking for your company’s cases?","ticket_portal_card_title_restricted":"Looking for your tickets?","ticket_sla_details":"SLA details: {sla_details}","ticket_status_details":"Status details: {status_details}","ticket_status_event_moved_automation_with_bullet_point":"Ticket moved into {status} • {timestamp}","ticket_status_event_moved_with_bullet_point":"{teammate} moved ticket into {status} • {timestamp}","ticket_update_icon_aria_label":"Ticket update icon","ticket_update_icon_aria_label_case":"Case update icon","ticket_update_notification_aria_label":"Ticket update from {name}, {timestamp}. {message_preview}","ticket_update_notification_aria_label_case":"Case update from {name}, {timestamp}. {message_preview}","ticket_update_notification_role":"ticket update","ticket_update_notification_role_case":"case update","ticket_update_notification_title":"Ticket update","ticket_update_notification_title_case":"Case update","ticketing_system_feature_description":"Tickets optimized for team collaboration and real-time customer updates.","ticketing_system_feature_short_title":"Ticketing system","ticketing_system_feature_title":"Ticketing system","tickets_add_file":"Add file","tickets_add_files":"Add files","tickets_create_ticket":"Create ticket","tickets_create_ticket_case":"Create case","tickets_create_ticket_fallback":"Please reply with the following information and someone will get back to you soon.","tickets_created_confirmation_header":"Ticket is created","tickets_created_confirmation_header_case":"Case is created","tickets_cta_text":"Have a question about this ticket?","tickets_cta_text_case":"Have a question about this case?","tickets_email_copy":"Replies and ticket updates will be sent to this email","tickets_email_copy_case":"Replies and case updates will be sent to this email","tickets_email_subject":"Your {ticket_type_name} ticket","tickets_email_subject_with_ticket_id":"Your {ticket_type_name} ticket #{ticket_id}","tickets_estimated_resolution":"Estimated time to resolution: {duration}","tickets_files_added":"Files added","tickets_have_a_question":"Have a question about this issue?","tickets_in_progress_status_detail":"We’re working on this 🙌","tickets_in_progress_status_detail_with_assignee":"{first_name} is working on this!","tickets_is_resolved":"Is this ticket resolved?","tickets_log_a_ticket":"Log a ticket","tickets_portal_feature_description":"Allow business customers to view and track all their team\'s tickets in one place.","tickets_portal_feature_short_title":"Tickets portal","tickets_portal_feature_title":"Tickets portal","tickets_resolved_status_detail":"We’ve completed your ticket","tickets_resolved_status_detail_case":"We’ve resolved your case","tickets_resolved_status_detail_with_assignee":"{first_name} has completed your ticket","tickets_resolved_status_detail_with_assignee_case":"{first_name} has resolved your case","tickets_sla":"Estimated to be resolved {time}","tickets_space_load_error":"Something went wrong loading your tickets","tickets_space_load_error_case":"Something went wrong loading your cases","tickets_space_title":"Tickets","tickets_space_title_case":"Cases","tickets_status_change_event":"Ticket is now {status} • {timestamp}","tickets_status_change_event_case":"Case is now {status} • {timestamp}","tickets_status_description_completed":"We\'ve completed your ticket","tickets_status_description_completed_case":"We\'ve resolved your case","tickets_status_description_more_info":"We need more information","tickets_status_description_well_pick_up_soon":"We\'ll pick up your ticket soon","tickets_status_description_well_pick_up_soon_case":"We\'ll pick up your case soon","tickets_status_description_working_on":"We\'re working on your ticket","tickets_status_description_working_on_case":"We\'re working on your case","tickets_status_event_moved":"{teammate} moved ticket into {status} {timestamp}","tickets_status_event_moved_automation":"Ticket moved into {status} {timestamp}","tickets_status_event_submitted":"Ticket has been {submitted_status} • {timestamp}","tickets_status_event_submitted_case":"Case has been {submitted_status} • {timestamp}","tickets_status_in_progress":"In progress","tickets_status_resolved":"Resolved","tickets_status_submitted":"Submitted","tickets_status_waiting_on_you":"Waiting on you","tickets_submitted_confirmation_header":"Ticket is submitted","tickets_submitted_confirmation_header_case":"Case is submitted","tickets_submitted_confirmation_paragraph":"We\'ll notify you once your ticket has an update","tickets_submitted_confirmation_paragraph_case":"We\'ll notify you once your case has an update","tickets_submitted_status_detail":"We’ll pick this up soon","tickets_submitted_status_detail_with_assignee":"{first_name} will pick this up soon","tickets_updates_prompt":"You will receive updates in the Messenger and via email","tickets_view_ticket":"View ticket details","tickets_view_ticket_case":"View case details","tickets_waiting_on_customer_status_detail":"We need more information from you","tickets_waiting_on_customer_status_detail_with_assignee":"{first_name} needs more information","time_day_ago":"{delta}d","time_future_1h":"In 1 hour","time_future_2h":"In 2 hours","time_future_30m":"In 30 minutes","time_future_3h":"In 3 hours","time_future_day_0":"Monday","time_future_day_1":"Tuesday","time_future_day_2":"Wednesday","time_future_day_3":"Thursday","time_future_day_4":"Friday","time_future_day_5":"Saturday","time_future_day_6":"Sunday","time_future_later_today":"Later today","time_future_next_week":"Next week","time_future_tomorrow":"Tomorrow","time_hour_ago":"{delta}h","time_just_now":"Just now","time_minute_ago":"{delta}m","time_month_ago":"{delta}mo","time_week_ago":"{delta}w","time_year_ago":"{delta}y","time_yesterday":"yesterday","tone_of_voice_feature_description":"Fin can incorporate your support tone of voice preferences, allowing you to customize your own, or choose from a selection of options like professional, friendly, humorous, and more.","tone_of_voice_feature_short_title":"Tone of voice","tone_of_voice_feature_title":"Tone of voice","tooltip_anchor":"Tooltip anchor","tooltips_feature_description":"Highlight features with a label that draws attention to a specific area of your product.","tooltips_feature_short_title":"Tooltips","tooltips_feature_title":"Tooltips","topics_explorer_feature_description":"Visualize support volume and key performance metrics by topic and subtopic.","topics_explorer_feature_short_title":"Topics Explorer","topics_explorer_feature_title":"Topics Explorer","tour":"tour","transcribing":"Transcribing...","transcription_failed":"Transcription failed","transcripts_feature_description":"Enable call transcripts for quick reference and quality assurance.","transcripts_feature_short_title":"Call transcripts","transcripts_feature_title":"Call transcripts","travel_places":"Travel & Places","trending_topics_feature_description":"Automatically detect meaningful changes in support activity and performance.","trending_topics_feature_short_title":"Trends","trending_topics_feature_title":"Trends","try_again":"Try Again","try_help_center":"Try our Help Center","try_use_different_keywords":"Try different keywords or type your full question","two_business_days":"Two business days","type_a_number":"Type a number…","typically_replies_in_one_business_day":"Typically replies in one business day","typically_replies_in_two_business_days":"Typically replies in two business days","typing":"Typing","unable_to_load_the_messenger":"We\'re unable to load the messenger","unbranded_help_center_feature_description":"A Help Center that will not include \'Built by Intercom\' in the footer.","unbranded_help_center_feature_short_title":"Unbranded Help Center","unbranded_help_center_feature_title":"Unbranded Help Center","unlimited_articles_and_collections_feature_description":"Publish an unlimited amount of articles and organize them by topic in collections.","unlimited_articles_and_collections_feature_short_title":"Unlimited articles","unlimited_articles_and_collections_feature_title":"Unlimited articles & collections","unlimited_usage_feature_description":"Unlimited Copilot usage.","unlimited_usage_feature_short_title":"Copilot","unlimited_usage_feature_title":"Unlimited usage","unread_messages":"Unread messages","unsubscribe_sync_feature_description":"Keep your customers\' subscription choices in sync across Intercom and Mailchimp/Marketo.","unsubscribe_sync_feature_short_title":"Unsubscribe sync","unsubscribe_sync_feature_title":"Unsubscribe sync","updated_in_the_last_15m":"Updated in the last 15 minutes","updated_in_the_last_hour":"Updated in the last hour","updated_multiple_months_ago":"Updated over {count} months ago","updated_multiple_weeks_ago":"Updated over {count} weeks ago","updated_multiple_years_ago":"Updated over {count} years ago","updated_over_a_month_ago ":"Updated over a month ago","updated_over_a_week_ago":"Updated over a week ago","updated_over_a_year_ago":"Updated over a year ago","updated_this_week":"Updated this week","updated_today":"Updated today","updated_yesterday":"Updated yesterday","upfront_collection_form_close_out":"You can return here anytime to see responses and send updates.","upfront_collection_form_introduction":"Share some context to help the team respond better and faster.","upfront_collection_form_submission_confirmation":"Thanks for sending that context. To save time later, feel free to add more details now.","upfront_collection_form_subtitle":"Send the team some context","upfront_collection_form_subtitle_submitted":"They\'ll keep this context in mind","upfront_collection_form_title":"Get help faster","upfront_collection_form_title_submitted":"Sent to the team!","upload_attachment":"Upload attachment","upload_failed":"Upload failed","upload_max_files_allowed":"Maximum {limit} files allowed","upload_max_files_size":"Maximum file size is {limit}MB","upload_retry":"Retry upload","user_company_segments_feature_description":"Filter and group users and companies with segments.","user_company_segments_feature_short_title":"User & company segments","user_company_segments_feature_title":"User & company segments","user_says":"{firstName} says…","usual_reply_time_header_label":"Usual reply time","view_all":"View all","view_attachments":"View attachments","view_conversation":"View conversation","view_more":"View more","view_more_details":"View more details","view_post":"View post","view_shared_media":"View shared media","voice_shortcut_hint":"Record a voice note — hold {shortcut} while the composer is empty.","voicemail_feature_description":"Turn on transcribed voicemails to easily return customer calls.","voicemail_feature_short_title":"Voicemail","voicemail_feature_title":"Voicemail","we_run_on_fin":"We run on Fin","we_run_on_intercom":"We run on Intercom","webhooks_feature_description":"Subscribe to real-time notifications of events happening in Intercom.","webhooks_feature_short_title":"Webhooks","webhooks_feature_title":"Webhooks","welcome_messages_feature_description":"Automatically message new users and visitors with a personalized greeting.","welcome_messages_feature_short_title":"Welcome messages","welcome_messages_feature_title":"Welcome messages","whatsapp_feature_description":"Send and receive WhatsApp messages from the Inbox.","whatsapp_feature_short_title":"WhatsApp","whatsapp_feature_title":"WhatsApp","whatsapp_inbound_feature_description":"WhatsApp conversations in the Inbox and sent from Workflows, free of charge.","whatsapp_inbound_feature_short_title":"Inbound WhatsApp","whatsapp_inbound_feature_title":"Inbound WhatsApp","with_teamname":"with {teamname}","within_custom_response_delay_0":"a few minutes","within_custom_response_delay_1":"a few hours","within_custom_response_delay_2":"a day","within_custom_response_delay_3":"a week","within_expected_response_delay_10800":"3 hours","within_expected_response_delay_120":"2 minutes","within_expected_response_delay_1200":"20 minutes","within_expected_response_delay_14400":"4 hours","within_expected_response_delay_172800":"2 days","within_expected_response_delay_180":"3 minutes","within_expected_response_delay_1800":"30 minutes","within_expected_response_delay_18000":"5 hours","within_expected_response_delay_21600":"6 hours","within_expected_response_delay_240":"4 minutes","within_expected_response_delay_259200":"3 days","within_expected_response_delay_300":"5 minutes","within_expected_response_delay_345600":"4 days","within_expected_response_delay_3600":"1 hour","within_expected_response_delay_43200":"12 hours","within_expected_response_delay_432000":"5 days","within_expected_response_delay_518400":"6 days","within_expected_response_delay_60":"1 minute","within_expected_response_delay_600":"10 minutes","within_expected_response_delay_604800":"1 week","within_expected_response_delay_7200":"2 hours","within_expected_response_delay_86400":"1 day","within_expected_response_delay_900":"15 minutes","workflows_for_advanced_automations_feature_description":"Automatically assign, close, and prioritize conversations and tickets, and do more with our visual automation builder.","workflows_for_advanced_automations_feature_short_title":"Workflows for advanced automation","workflows_for_advanced_automations_feature_title":"Workflows for advanced automations","workflows_for_fin_feature_description":"Add Fin to sophisticated Workflows automations to triage, handle complex customer queries and generate answers when customers take specific actions.","workflows_for_fin_feature_short_title":"Workflows for Fin","workflows_for_fin_feature_title":"Workflows for Fin","workforce_management_feature_description":"Forecast, schedule and manage your support team.","workforce_management_feature_short_title":"Workforce Management","workforce_management_feature_title":"Workforce Management","working_on_it":"Working on it...","workload_management_feature_description":"Assign the most critical conversations from various team Inboxes to the most available and relevant teammate.","workload_management_feature_short_title":"Workload management","workload_management_feature_title":"Workload management","workspace_sandbox_feature_description":"Sandbox to test features and Workflows without impacting the live workspace.","workspace_sandbox_feature_short_title":"Workspace sandbox","workspace_sandbox_feature_title":"Workspace sandbox","write_your_message":"Write your message...","written_by":"Written by","you":"You","you_are_all_up_to_date":"You\'re all caught up!","you_have_new_messages":"You have new messages.","you_rated_the_conversation":"You rated the conversation","you_will_get_a_reply_here_and_at_email":"You\'ll get a reply here and at {email}","youll_be_notified_here_and_by_email":"You will be notified here and by email","youll_be_notified_here_and_by_sms":"You\'ll be notified here and by SMS","your_checklists":"Your checklists","your_conversations":"Your conversations","your_email":"Your email","your_message":"Your message","your_recent_conversations":"Recent conversations","your_recent_message":"Recent message","your_recent_messages":"Recent messages","your_ticket":"Your ticket","your_ticket_case":"Your case","zendesk_support_integration_feature_description":"View Zendesk tickets or create new ones without leaving your Inbox.","zendesk_support_integration_feature_short_title":"Zendesk Support integration","zendesk_support_integration_feature_title":"Zendesk Support integration"}')
        }
    }
]);