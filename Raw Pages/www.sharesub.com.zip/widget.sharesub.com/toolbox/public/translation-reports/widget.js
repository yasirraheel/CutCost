/*! Sharesub translation-report widget — © Sharesub. Auto-generated. */
(function(){
  if (typeof window === 'undefined' || typeof document === 'undefined') return;
  if (window.__sharesubTRWidget) return;
  window.__sharesubTRWidget = true;

  var API_URL = "https://widget.sharesub.com/toolbox/public/translation-reports/submit";
  var TURNSTILE_SITE_KEY = "0x4AAAAAADNSGmN1lJgKsr8N";
  var LABELS = {"fr":{"button_label":"Signaler une erreur de traduction","modal_title":"Signaler une erreur de traduction","field_text":"Texte concerné","field_correction":"Votre correction","field_email_optional":"Email (optionnel)","field_email_placeholder":"Pour vous tenir au courant","submit":"Envoyer","cancel":"Annuler","close":"Fermer","thanks":"Merci, votre suggestion a bien été envoyée.","error_generic":"Une erreur est survenue. Veuillez réessayer.","click_target":"Cliquez sur le texte mal traduit"},"en":{"button_label":"Report a translation error","modal_title":"Report a translation error","field_text":"Affected text","field_correction":"Your correction","field_email_optional":"Email (optional)","field_email_placeholder":"To keep you posted","submit":"Send","cancel":"Cancel","close":"Close","thanks":"Thank you, your suggestion has been sent.","error_generic":"Something went wrong. Please try again.","click_target":"Click the mistranslated text"},"de":{"button_label":"Übersetzungsfehler melden","modal_title":"Übersetzungsfehler melden","field_text":"Betroffener Text","field_correction":"Ihre Korrektur","field_email_optional":"E-Mail (optional)","field_email_placeholder":"Um Sie auf dem Laufenden zu halten","submit":"Senden","cancel":"Abbrechen","close":"Schließen","thanks":"Vielen Dank, Ihr Vorschlag wurde gesendet.","error_generic":"Ein Fehler ist aufgetreten. Bitte erneut versuchen.","click_target":"Klicken Sie auf den falsch übersetzten Text"},"it":{"button_label":"Segnala un errore di traduzione","modal_title":"Segnala un errore di traduzione","field_text":"Testo interessato","field_correction":"La tua correzione","field_email_optional":"Email (opzionale)","field_email_placeholder":"Per tenerti aggiornato","submit":"Invia","cancel":"Annulla","close":"Chiudi","thanks":"Grazie, il tuo suggerimento è stato inviato.","error_generic":"Si è verificato un errore. Riprova.","click_target":"Clicca sul testo mal tradotto"},"es":{"button_label":"Reportar un error de traducción","modal_title":"Reportar un error de traducción","field_text":"Texto afectado","field_correction":"Tu corrección","field_email_optional":"Email (opcional)","field_email_placeholder":"Para mantenerte informado","submit":"Enviar","cancel":"Cancelar","close":"Cerrar","thanks":"Gracias, tu sugerencia ha sido enviada.","error_generic":"Ha ocurrido un error. Por favor inténtalo de nuevo.","click_target":"Haz clic en el texto mal traducido"},"et":{"button_label":"Teata tõlkeveast","modal_title":"Teata tõlkeveast","field_text":"Vigane tekst","field_correction":"Sinu parandus","field_email_optional":"E-post (valikuline)","field_email_placeholder":"Et hoida sind kursis","submit":"Saada","cancel":"Tühista","close":"Sulge","thanks":"Aitäh, sinu ettepanek on saadetud.","error_generic":"Tekkis viga. Palun proovi uuesti.","click_target":"Klõpsa vigaselt tõlgitud tekstil"},"lv":{"button_label":"Ziņot par tulkojuma kļūdu","modal_title":"Ziņot par tulkojuma kļūdu","field_text":"Skartais teksts","field_correction":"Jūsu labojums","field_email_optional":"E-pasts (neobligāts)","field_email_placeholder":"Lai jūs informētu","submit":"Nosūtīt","cancel":"Atcelt","close":"Aizvērt","thanks":"Paldies, jūsu ieteikums ir nosūtīts.","error_generic":"Radās kļūda. Lūdzu, mēģiniet vēlreiz.","click_target":"Noklikšķiniet uz nepareizi tulkotā teksta"},"lt":{"button_label":"Pranešti apie vertimo klaidą","modal_title":"Pranešti apie vertimo klaidą","field_text":"Aptariamas tekstas","field_correction":"Jūsų pataisymas","field_email_optional":"El. paštas (neprivaloma)","field_email_placeholder":"Kad būtumėte informuoti","submit":"Siųsti","cancel":"Atšaukti","close":"Uždaryti","thanks":"Ačiū, jūsų pasiūlymas išsiųstas.","error_generic":"Įvyko klaida. Bandykite dar kartą.","click_target":"Spustelėkite blogai išverstą tekstą"},"nl":{"button_label":"Een vertaalfout melden","modal_title":"Een vertaalfout melden","field_text":"Betreffende tekst","field_correction":"Jouw correctie","field_email_optional":"E-mail (optioneel)","field_email_placeholder":"Om je op de hoogte te houden","submit":"Verzenden","cancel":"Annuleren","close":"Sluiten","thanks":"Bedankt, je suggestie is verzonden.","error_generic":"Er is iets misgegaan. Probeer het opnieuw.","click_target":"Klik op de verkeerd vertaalde tekst"},"pt":{"button_label":"Reportar um erro de tradução","modal_title":"Reportar um erro de tradução","field_text":"Texto em causa","field_correction":"A sua correção","field_email_optional":"Email (opcional)","field_email_placeholder":"Para mantê-lo informado","submit":"Enviar","cancel":"Cancelar","close":"Fechar","thanks":"Obrigado, a sua sugestão foi enviada.","error_generic":"Ocorreu um erro. Por favor tente novamente.","click_target":"Clique no texto mal traduzido"},"sk":{"button_label":"Nahlásiť chybu prekladu","modal_title":"Nahlásiť chybu prekladu","field_text":"Dotknutý text","field_correction":"Vaša oprava","field_email_optional":"Email (voliteľné)","field_email_placeholder":"Aby sme vás informovali","submit":"Odoslať","cancel":"Zrušiť","close":"Zavrieť","thanks":"Ďakujeme, váš návrh bol odoslaný.","error_generic":"Vyskytla sa chyba. Skúste to znova.","click_target":"Kliknite na nesprávne preložený text"},"sl":{"button_label":"Prijavi napako v prevodu","modal_title":"Prijavi napako v prevodu","field_text":"Zadevno besedilo","field_correction":"Vaš popravek","field_email_optional":"E-pošta (neobvezno)","field_email_placeholder":"Da vas obvestimo","submit":"Pošlji","cancel":"Prekliči","close":"Zapri","thanks":"Hvala, vaš predlog je bil poslan.","error_generic":"Prišlo je do napake. Poskusite znova.","click_target":"Kliknite na napačno preveden tekst"},"fi":{"button_label":"Ilmoita käännösvirheestä","modal_title":"Ilmoita käännösvirheestä","field_text":"Asianomainen teksti","field_correction":"Korjauksesi","field_email_optional":"Sähköposti (valinnainen)","field_email_placeholder":"Pidämme sinut ajan tasalla","submit":"Lähetä","cancel":"Peruuta","close":"Sulje","thanks":"Kiitos, ehdotuksesi on lähetetty.","error_generic":"Tapahtui virhe. Yritä uudelleen.","click_target":"Napsauta väärin käännettyä tekstiä"},"el":{"button_label":"Αναφορά λάθους μετάφρασης","modal_title":"Αναφορά λάθους μετάφρασης","field_text":"Σχετικό κείμενο","field_correction":"Η διόρθωσή σας","field_email_optional":"Email (προαιρετικό)","field_email_placeholder":"Για να σας ενημερώνουμε","submit":"Αποστολή","cancel":"Ακύρωση","close":"Κλείσιμο","thanks":"Ευχαριστούμε, η πρότασή σας στάλθηκε.","error_generic":"Παρουσιάστηκε σφάλμα. Δοκιμάστε ξανά.","click_target":"Κάντε κλικ στο λάθος μεταφρασμένο κείμενο"},"bg":{"button_label":"Докладвай грешка в превода","modal_title":"Докладвай грешка в превода","field_text":"Засегнат текст","field_correction":"Вашата корекция","field_email_optional":"Имейл (по избор)","field_email_placeholder":"За да ви държим в течение","submit":"Изпрати","cancel":"Откажи","close":"Затвори","thanks":"Благодарим, вашето предложение е изпратено.","error_generic":"Възникна грешка. Опитайте отново.","click_target":"Кликнете върху неправилно преведения текст"},"da":{"button_label":"Rapportér en oversættelsesfejl","modal_title":"Rapportér en oversættelsesfejl","field_text":"Berørt tekst","field_correction":"Din rettelse","field_email_optional":"Email (valgfri)","field_email_placeholder":"For at holde dig informeret","submit":"Send","cancel":"Annullér","close":"Luk","thanks":"Tak, dit forslag er sendt.","error_generic":"Der opstod en fejl. Prøv igen.","click_target":"Klik på den forkert oversatte tekst"},"sv":{"button_label":"Rapportera ett översättningsfel","modal_title":"Rapportera ett översättningsfel","field_text":"Berörd text","field_correction":"Din rättelse","field_email_optional":"E-post (valfritt)","field_email_placeholder":"För att hålla dig informerad","submit":"Skicka","cancel":"Avbryt","close":"Stäng","thanks":"Tack, ditt förslag har skickats.","error_generic":"Något gick fel. Försök igen.","click_target":"Klicka på den felaktigt översatta texten"},"nb":{"button_label":"Rapporter en oversettelsesfeil","modal_title":"Rapporter en oversettelsesfeil","field_text":"Berørt tekst","field_correction":"Din rettelse","field_email_optional":"E-post (valgfritt)","field_email_placeholder":"For å holde deg informert","submit":"Send","cancel":"Avbryt","close":"Lukk","thanks":"Takk, forslaget ditt er sendt.","error_generic":"Noe gikk galt. Prøv igjen.","click_target":"Klikk på den feiloversatte teksten"},"hu":{"button_label":"Fordítási hiba jelentése","modal_title":"Fordítási hiba jelentése","field_text":"Érintett szöveg","field_correction":"Az ön javítása","field_email_optional":"Email (nem kötelező)","field_email_placeholder":"Hogy tájékoztathassuk","submit":"Küldés","cancel":"Mégse","close":"Bezárás","thanks":"Köszönjük, javaslata elküldve.","error_generic":"Hiba történt. Próbálja újra.","click_target":"Kattintson a hibásan fordított szövegre"},"pl":{"button_label":"Zgłoś błąd w tłumaczeniu","modal_title":"Zgłoś błąd w tłumaczeniu","field_text":"Tekst, którego dotyczy","field_correction":"Twoja poprawka","field_email_optional":"Email (opcjonalnie)","field_email_placeholder":"Aby informować cię na bieżąco","submit":"Wyślij","cancel":"Anuluj","close":"Zamknij","thanks":"Dziękujemy, twoja sugestia została wysłana.","error_generic":"Wystąpił błąd. Spróbuj ponownie.","click_target":"Kliknij na błędnie przetłumaczony tekst"},"ro":{"button_label":"Raportează o eroare de traducere","modal_title":"Raportează o eroare de traducere","field_text":"Text vizat","field_correction":"Corectarea ta","field_email_optional":"Email (opțional)","field_email_placeholder":"Pentru a te ține la curent","submit":"Trimite","cancel":"Anulează","close":"Închide","thanks":"Mulțumim, sugestia ta a fost trimisă.","error_generic":"A apărut o eroare. Încearcă din nou.","click_target":"Fă clic pe textul tradus greșit"},"cs":{"button_label":"Nahlásit chybu v překladu","modal_title":"Nahlásit chybu v překladu","field_text":"Dotčený text","field_correction":"Vaše oprava","field_email_optional":"Email (volitelné)","field_email_placeholder":"Abychom vás informovali","submit":"Odeslat","cancel":"Zrušit","close":"Zavřít","thanks":"Děkujeme, váš návrh byl odeslán.","error_generic":"Došlo k chybě. Zkuste to znovu.","click_target":"Klikněte na nesprávně přeložený text"},"hr":{"button_label":"Prijavi pogrešku u prijevodu","modal_title":"Prijavi pogrešku u prijevodu","field_text":"Dotični tekst","field_correction":"Vaš ispravak","field_email_optional":"E-mail (neobavezno)","field_email_placeholder":"Da vas obavijestimo","submit":"Pošalji","cancel":"Odustani","close":"Zatvori","thanks":"Hvala, vaš prijedlog je poslan.","error_generic":"Došlo je do greške. Pokušajte ponovno.","click_target":"Kliknite na neispravno preveden tekst"}};
  var ENABLED = true;
  var ENABLED_LANGS = ["et","lv","lt","nl","sk","sl","fi","el","bg","da","sv","nb","hu","pl","ro","cs","hr","pt"];
  var EXCLUDED_URL_SUBSTRINGS = ["/cms/"];
  var FALLBACK_LANG = 'en';
  var STATE = { mode: 'idle', captured: null, turnstileWidgetId: null };

  function pickLang(){
    try {
      if (typeof window.__sharesub_lang === 'string' && LABELS[window.__sharesub_lang]) return window.__sharesub_lang;
      var htmlLang = (document.documentElement.getAttribute('lang') || '').toLowerCase().split('-')[0];
      if (LABELS[htmlLang]) return htmlLang;
      var pathLang = (location.pathname.split('/')[1] || '').toLowerCase();
      if (LABELS[pathLang]) return pathLang;
      var nav = ((navigator.language || navigator.userLanguage || '')+'').toLowerCase().split('-')[0];
      if (LABELS[nav]) return nav;
    } catch (e) {}
    return FALLBACK_LANG;
  }
  var LANG = pickLang();
  function t(key){ return (LABELS[LANG] && LABELS[LANG][key]) || (LABELS[FALLBACK_LANG] && LABELS[FALLBACK_LANG][key]) || key; }

  function el(tag, props, children){
    var node = document.createElement(tag);
    if (props) {
      for (var k in props) {
        if (!Object.prototype.hasOwnProperty.call(props, k)) continue;
        var v = props[k];
        if (v == null) continue;
        if (k === 'className') node.className = v;
        else if (k === 'text') node.textContent = v;
        else if (k === 'dataset') { for (var dk in v) node.dataset[dk] = v[dk]; }
        else if (k === 'on') { for (var ek in v) node.addEventListener(ek, v[ek]); }
        else if (k === 'attrs') { for (var ak in v) node.setAttribute(ak, v[ak]); }
        else node[k] = v;
      }
    }
    if (children) {
      for (var i = 0; i < children.length; i++) {
        var c = children[i];
        if (c == null) continue;
        node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
      }
    }
    return node;
  }

  // ── CSS ─────────────────────────────────────────────────────────────────
  var STYLE_ID = 'sharesub-tr-widget-style';
  if (!document.getElementById(STYLE_ID)) {
    var s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent = [
      ".sharesub-tr-wrap{position:fixed;bottom:20px;left:20px;z-index:2147483630;display:inline-block;transition:opacity .18s ease,visibility .18s,transform .18s ease}",
      ".sharesub-tr-wrap.is-hidden{opacity:0;visibility:hidden;pointer-events:none;transform:translateY(8px)}",
      ".sharesub-tr-btn{background:#016df4;color:#fff;border:none;border-radius:999px;padding:12px 18px;font:600 14px/1.2 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;cursor:pointer;box-shadow:0 6px 20px rgba(1,109,244,.32);transition:transform .15s ease,box-shadow .15s ease;display:inline-flex;align-items:center;gap:8px}",
      ".sharesub-tr-btn:hover{transform:translateY(-1px);box-shadow:0 8px 24px rgba(1,109,244,.4)}",
      ".sharesub-tr-btn:focus{outline:2px solid #fff;outline-offset:2px}",
      ".sharesub-tr-btn--pick{background:#fff;color:#016df4;border:2px solid #016df4;box-shadow:0 6px 20px rgba(1,109,244,.45)}",
      ".sharesub-tr-btn--pick:hover{background:#f0f7ff;box-shadow:0 8px 24px rgba(1,109,244,.55)}",
      ".sharesub-tr-btn .sharesub-tr-x{font-size:20px;line-height:1;font-weight:700;color:#016df4;background:#fff;border-radius:50%;width:20px;height:20px;display:inline-flex;align-items:center;justify-content:center}",
      ".sharesub-tr-btn--pick .sharesub-tr-x{background:#016df4;color:#fff}",
      ".sharesub-tr-dismiss{position:absolute;top:-7px;right:-7px;width:20px;height:20px;border-radius:50%;background:#475569;color:#fff;border:2px solid #fff;font:700 11px/1 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;padding:0;opacity:.78;transition:opacity .15s ease,transform .15s ease,background .15s ease;box-shadow:0 2px 6px rgba(0,0,0,.22)}",
      ".sharesub-tr-dismiss:hover{opacity:1;background:#0f172a;transform:scale(1.12)}",
      ".sharesub-tr-dismiss:focus{outline:2px solid #016df4;outline-offset:2px;opacity:1}",
      ".sharesub-tr-wrap.is-pick .sharesub-tr-dismiss{display:none}",
      ".sharesub-tr-overlay{position:fixed;inset:0;background:rgba(8,15,30,.55);z-index:2147483641;display:flex;align-items:center;justify-content:center;padding:16px;animation:sharesub-tr-fade .15s ease}",
      "@keyframes sharesub-tr-fade{from{opacity:0}to{opacity:1}}",
      ".sharesub-tr-modal{background:#fff;border-radius:14px;max-width:520px;width:100%;max-height:90vh;overflow-y:auto;box-shadow:0 24px 60px rgba(0,0,0,.32);font:14px/1.45 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#0f172a}",
      ".sharesub-tr-modal header{padding:20px 22px 12px;display:flex;align-items:start;justify-content:space-between;gap:12px;border-bottom:1px solid #eef2f7}",
      ".sharesub-tr-modal h2{margin:0;font-size:17px;font-weight:600;color:#0f172a}",
      ".sharesub-tr-modal .x{background:none;border:0;font-size:26px;font-weight:700;line-height:1;color:#016df4;cursor:pointer;padding:0 4px;transition:transform .15s ease}",
      ".sharesub-tr-modal .x:hover{transform:scale(1.15)}",
      ".sharesub-tr-modal .body{padding:18px 22px}",
      ".sharesub-tr-modal label{display:block;font-weight:600;color:#0f172a;margin-bottom:6px;font-size:13px}",
      ".sharesub-tr-modal textarea,.sharesub-tr-modal input[type=text],.sharesub-tr-modal input[type=email]{width:100%;border:1px solid #cbd5e1;border-radius:8px;padding:10px 12px;font:inherit;color:#0f172a;background:#fff;box-sizing:border-box;resize:vertical}",
      ".sharesub-tr-modal textarea{min-height:80px}",
      ".sharesub-tr-modal textarea:focus,.sharesub-tr-modal input:focus{outline:none;border-color:#016df4;box-shadow:0 0 0 3px rgba(1,109,244,.15)}",
      ".sharesub-tr-modal .help{font-size:12px;color:#64748b;margin-top:4px}",
      ".sharesub-tr-modal .field{margin-bottom:14px}",
      ".sharesub-tr-modal .ts{margin:6px 0 4px;min-height:1px}",
      ".sharesub-tr-modal footer{display:flex;gap:8px;justify-content:flex-end;padding:14px 22px 20px}",
      ".sharesub-tr-modal .primary{background:#016df4;color:#fff;border:0;padding:10px 18px;border-radius:8px;font:600 14px/1.2 inherit;cursor:pointer}",
      ".sharesub-tr-modal .primary:disabled{opacity:.55;cursor:not-allowed}",
      ".sharesub-tr-modal .secondary{background:#fff;color:#0f172a;border:1px solid #cbd5e1;padding:10px 16px;border-radius:8px;font:600 14px/1.2 inherit;cursor:pointer}",
      ".sharesub-tr-modal .error{color:#dc2626;font-size:13px;margin-top:6px}",
      ".sharesub-tr-modal .quote{background:#f8fafc;border-left:3px solid #016df4;padding:8px 12px;border-radius:6px;color:#475569;font-size:13px;word-break:break-word;max-height:110px;overflow-y:auto;white-space:pre-wrap}",
      ".sharesub-tr-modal .honeypot{position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden}",
      ".sharesub-tr-modal .thanks{padding:30px 22px;text-align:center;color:#0f172a;font-size:15px}",
      ".sharesub-tr-modal .thanks .ok{display:inline-flex;align-items:center;justify-content:center;width:48px;height:48px;border-radius:50%;background:#dcfce7;color:#15803d;font-size:24px;margin-bottom:12px}",
      ".sharesub-tr-pick-mode{cursor:crosshair !important}",
      ".sharesub-tr-pick-mode *{cursor:crosshair !important}",
      ".sharesub-tr-pick-hint{position:fixed;top:18px;left:50%;transform:translateX(-50%);background:#0f172a;color:#fff;padding:8px 16px;border-radius:999px;z-index:2147483641;font:600 13px/1.2 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.32)}",
    ].join('');
    document.head.appendChild(s);
  }

  // ── DOM helpers ─────────────────────────────────────────────────────────
  function cssPath(node){
    if (!(node instanceof Element)) return '';
    var parts = [];
    while (node && node.nodeType === 1 && parts.length < 6) {
      var part = node.nodeName.toLowerCase();
      if (node.id) { part += '#' + node.id; parts.unshift(part); break; }
      var sib = node, n = 1;
      while ((sib = sib.previousElementSibling) != null) { if (sib.nodeName === node.nodeName) n++; }
      if (n > 1) part += ':nth-of-type(' + n + ')';
      parts.unshift(part);
      node = node.parentElement;
    }
    return parts.join(' > ').slice(0, 500);
  }

  function readNativeData(target){
    var ctx = {};
    var node = target;
    while (node && node !== document.body && node.nodeType === 1) {
      var d = node.dataset || {};
      if (!ctx.tio_key && d.tioKey) ctx.tio_key = d.tioKey;
      if (!ctx.product_table && d.productTable) ctx.product_table = d.productTable;
      if (!ctx.product_id && d.productId) ctx.product_id = d.productId;
      if (!ctx.product_field && d.productField) ctx.product_field = d.productField;
      if (ctx.tio_key || (ctx.product_table && ctx.product_id)) break;
      node = node.parentElement;
    }
    try {
      var g = window.__sharesub_translation_context;
      if (g && typeof g === 'object') {
        if (!ctx.tio_key && typeof g.tio_key === 'string') ctx.tio_key = g.tio_key;
        if (!ctx.product_table && typeof g.product_table === 'string') ctx.product_table = g.product_table;
        if (!ctx.product_id && g.product_id != null) ctx.product_id = String(g.product_id);
        if (!ctx.product_field && typeof g.product_field === 'string') ctx.product_field = g.product_field;
      }
    } catch (e) {}
    return ctx;
  }

  // Whitelist des préfixes data-* qu'on accepte de capturer. Évite de
  // capturer accidentellement un data-csrf-token, data-stripe-* ou un
  // data-user-id sensible exposé par le site Laravel. Si tu veux passer
  // un contexte custom au backend, préfixe avec data-tr- (translation-report).
  var DATA_WHITELIST = /^(tr[A-Z0-9]|tio[A-Z0-9]|product[A-Z0-9])/;
  var DATA_RESERVED = { tioKey: 1, productTable: 1, productId: 1, productField: 1 };

  function readHiddenMetadata(target){
    var meta = {};
    var count = 0;
    try {
      var node = target;
      while (node && node !== document.body && node.nodeType === 1 && count < 20) {
        var d = node.dataset || {};
        for (var k in d) {
          if (!Object.prototype.hasOwnProperty.call(d, k)) continue;
          if (DATA_RESERVED[k]) continue;
          if (!DATA_WHITELIST.test(k)) continue;
          if (meta[k] == null) { meta[k] = String(d[k]).slice(0, 200); count++; }
          if (count >= 20) break;
        }
        node = node.parentElement;
      }
    } catch (e) {}
    return meta;
  }

  function captureFromSelection(){
    var sel = window.getSelection ? window.getSelection() : null;
    var text = sel ? String(sel.toString() || '').trim() : '';
    if (!text) return null;
    var anchor = sel && sel.anchorNode ? (sel.anchorNode.nodeType === 3 ? sel.anchorNode.parentElement : sel.anchorNode) : null;
    if (!anchor) return null;
    return { text: text.slice(0, 500), el: anchor };
  }

  function captureFromElement(target){
    var raw = (target.innerText || target.textContent || '').trim();
    return { text: raw.slice(0, 500), el: target };
  }

  function getSurrounding(target){
    if (!target) return '';
    var parent = target.closest('p, li, td, div, section, article, main, body') || target.parentElement || target;
    var text = ((parent.innerText || parent.textContent || '') + '').replace(/\s+/g, ' ').trim();
    return text.slice(0, 1500);
  }

  // Strip query params dont le nom suggère un secret avant de les envoyer
  // au backend. Évite de stocker accidentellement un token de reset, un
  // session id, ou un Stripe redirect_payment_intent_secret en clair en DB.
  function sanitizeUrl(raw){
    try {
      var u = new URL(raw);
      var SENSITIVE = /(token|secret|key|password|reset|sig|auth|jwt|hash)/i;
      var keys = [];
      u.searchParams.forEach(function(_, k){ if (SENSITIVE.test(k)) keys.push(k); });
      for (var i = 0; i < keys.length; i++) u.searchParams.set(keys[i], '[redacted]');
      return u.toString();
    } catch (e) {
      return raw;
    }
  }

  // ── Pick mode ───────────────────────────────────────────────────────────
  var hintEl = null;
  function setTriggerLabel(pickActive){
    var btn = document.getElementById('sharesub-tr-trigger');
    if (!btn) return;
    if (wrapEl) {
      if (pickActive) wrapEl.classList.add('is-pick');
      else wrapEl.classList.remove('is-pick');
    }
    if (pickActive) {
      btn.classList.add('sharesub-tr-btn--pick');
      // Croix bleue + label "Cliquez sur le texte mal traduit" (i18n).
      while (btn.firstChild) btn.removeChild(btn.firstChild);
      var x = document.createElement('span');
      x.className = 'sharesub-tr-x';
      x.textContent = '×';
      btn.appendChild(x);
      btn.appendChild(document.createTextNode(' ' + t('click_target')));
      btn.setAttribute('aria-label', t('cancel'));
    } else {
      btn.classList.remove('sharesub-tr-btn--pick');
      while (btn.firstChild) btn.removeChild(btn.firstChild);
      btn.appendChild(document.createTextNode(t('button_label')));
      btn.removeAttribute('aria-label');
    }
  }
  function startPickMode(){
    if (STATE.mode === 'pick') return;
    STATE.mode = 'pick';
    document.body.classList.add('sharesub-tr-pick-mode');
    hintEl = el('div', { className: 'sharesub-tr-pick-hint', text: t('click_target') });
    document.body.appendChild(hintEl);
    setTriggerLabel(true);
    document.addEventListener('click', onPickClick, true);
    document.addEventListener('keydown', onPickKeydown, true);
  }
  function stopPickMode(){
    STATE.mode = 'idle';
    document.body.classList.remove('sharesub-tr-pick-mode');
    if (hintEl && hintEl.parentNode) hintEl.parentNode.removeChild(hintEl);
    hintEl = null;
    setTriggerLabel(false);
    document.removeEventListener('click', onPickClick, true);
    document.removeEventListener('keydown', onPickKeydown, true);
  }
  function onPickKeydown(e){
    if (e.key === 'Escape') { e.preventDefault(); stopPickMode(); }
  }
  function onPickClick(e){
    if (STATE.mode !== 'pick') return;
    var target = e.target;
    if (!target || (target.closest && target.closest('#sharesub-tr-wrap'))) return;
    e.preventDefault();
    e.stopPropagation();
    var captured = captureFromSelection() || captureFromElement(target);
    if (!captured || !captured.text) { stopPickMode(); return; }
    STATE.captured = {
      text: captured.text,
      selector: cssPath(captured.el),
      surrounding: getSurrounding(captured.el),
      native: readNativeData(captured.el),
      hidden: readHiddenMetadata(captured.el),
    };
    stopPickMode();
    openModal();
  }

  // ── Modal ───────────────────────────────────────────────────────────────
  var overlayEl = null;
  var modalEl = null;
  var corrEl = null;
  var emailEl = null;
  var honeyEl = null;
  var errCorrEl = null;
  var errGenEl = null;
  var submitBtnEl = null;
  var turnstileTargetEl = null;

  function openModal(){
    if (overlayEl) return;
    var cap = STATE.captured || { text: '', selector: '', surrounding: '', native: {}, hidden: {} };

    var closeBtn = el('button', { type: 'button', className: 'x', text: '×', attrs: { 'aria-label': t('close') }, on: { click: closeModal } });
    var header = el('header', null, [el('h2', { text: t('modal_title') }), closeBtn]);

    var quote = el('div', { className: 'quote', text: cap.text || '', dataset: { role: 'reported' } });
    corrEl = el('textarea', { id: 'sharesub-tr-corr', name: 'correction', required: true, maxLength: 500 });
    errCorrEl = el('div', { className: 'error', dataset: { role: 'err-correction' }, hidden: true });
    emailEl = el('input', { id: 'sharesub-tr-email', type: 'email', name: 'contact_email', maxLength: 200, placeholder: t('field_email_placeholder') });
    honeyEl = el('input', { type: 'text', name: 'website', tabIndex: -1, autocomplete: 'off' });

    turnstileTargetEl = el('div', { className: 'ts', dataset: { role: 'turnstile' } });
    errGenEl = el('div', { className: 'error', dataset: { role: 'err-generic' }, hidden: true });

    var form = el('form', { className: 'body', noValidate: true }, [
      el('div', { className: 'field' }, [
        el('label', { text: t('field_text') }),
        quote,
      ]),
      el('div', { className: 'field' }, [
        el('label', { text: t('field_correction'), attrs: { for: 'sharesub-tr-corr' } }),
        corrEl,
        errCorrEl,
      ]),
      el('div', { className: 'field' }, [
        el('label', { text: t('field_email_optional'), attrs: { for: 'sharesub-tr-email' } }),
        emailEl,
      ]),
      el('div', { className: 'honeypot', attrs: { 'aria-hidden': 'true' } }, [
        el('label', { text: 'Website' }),
        honeyEl,
      ]),
      turnstileTargetEl,
      errGenEl,
    ]);

    var cancelBtn = el('button', { type: 'button', className: 'secondary', text: t('cancel'), dataset: { role: 'cancel' }, on: { click: closeModal } });
    submitBtnEl = el('button', { type: 'button', className: 'primary', text: t('submit'), dataset: { role: 'submit' }, on: { click: onSubmit } });
    var footer = el('footer', null, [cancelBtn, submitBtnEl]);

    modalEl = el('div', { className: 'sharesub-tr-modal', attrs: { role: 'document' } }, [header, form, footer]);
    overlayEl = el('div', { className: 'sharesub-tr-overlay', attrs: { role: 'dialog', 'aria-modal': 'true' } }, [modalEl]);
    overlayEl.addEventListener('click', function(e){ if (e.target === overlayEl) closeModal(); });
    document.body.appendChild(overlayEl);
    document.addEventListener('keydown', onModalKeydown);
    setTimeout(function(){ if (corrEl) corrEl.focus(); }, 80);

    renderTurnstile();
  }
  function closeModal(){
    if (!overlayEl) return;
    document.removeEventListener('keydown', onModalKeydown);
    if (overlayEl.parentNode) overlayEl.parentNode.removeChild(overlayEl);
    overlayEl = modalEl = corrEl = emailEl = honeyEl = errCorrEl = errGenEl = submitBtnEl = turnstileTargetEl = null;
    STATE.turnstileWidgetId = null;
  }
  function onModalKeydown(e){ if (e.key === 'Escape') closeModal(); }

  function renderTurnstile(){
    if (!TURNSTILE_SITE_KEY || !turnstileTargetEl) return;
    function doRender(){
      try {
        STATE.turnstileWidgetId = window.turnstile.render(turnstileTargetEl, {
          sitekey: TURNSTILE_SITE_KEY,
          theme: 'light',
          size: 'flexible',
        });
      } catch (e) {}
    }
    if (window.turnstile && typeof window.turnstile.render === 'function') { doRender(); return; }
    if (!document.getElementById('sharesub-tr-turnstile-script')) {
      var sc = document.createElement('script');
      sc.id = 'sharesub-tr-turnstile-script';
      sc.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
      sc.async = true; sc.defer = true;
      sc.onload = doRender;
      document.head.appendChild(sc);
    } else {
      var tries = 0;
      var iv = setInterval(function(){
        if (window.turnstile && window.turnstile.render) { clearInterval(iv); doRender(); }
        else if (++tries > 40) clearInterval(iv);
      }, 100);
    }
  }
  function getTurnstileToken(){
    try {
      if (TURNSTILE_SITE_KEY && window.turnstile && STATE.turnstileWidgetId != null) {
        return window.turnstile.getResponse(STATE.turnstileWidgetId) || '';
      }
    } catch (e) {}
    return '';
  }
  function resetTurnstile(){
    try {
      if (TURNSTILE_SITE_KEY && window.turnstile && STATE.turnstileWidgetId != null) {
        window.turnstile.reset(STATE.turnstileWidgetId);
      }
    } catch (e) {}
  }

  function onSubmit(){
    if (!overlayEl || !submitBtnEl || !corrEl) return;
    if (errCorrEl) errCorrEl.hidden = true;
    if (errGenEl) errGenEl.hidden = true;

    var correction = (corrEl.value || '').trim();
    if (!correction) {
      if (errCorrEl) { errCorrEl.textContent = t('field_correction'); errCorrEl.hidden = false; }
      corrEl.focus();
      return;
    }

    var cap = STATE.captured || { text: '', selector: '', surrounding: '', native: {}, hidden: {} };
    var payload = {
      page_url: sanitizeUrl(location.href),
      lang: LANG,
      reported_text: (cap.text || '').slice(0, 500),
      suggested_correction: correction.slice(0, 500),
      surrounding_context: (cap.surrounding || '').slice(0, 2000),
      dom_selector: (cap.selector || '').slice(0, 500),
      hidden_metadata: cap.hidden || {},
      native_context: cap.native || {},
      contact_email: (emailEl && emailEl.value || '').trim(),
      website: (honeyEl && honeyEl.value) || '',
    };
    if (window.__sharesub_user_id != null) {
      var uid = Number(window.__sharesub_user_id);
      if (!isNaN(uid) && uid > 0) payload.user_id = uid;
    }
    // Jeton d'auth signé (émis par le site pour un user connecté) : vérifié
    // côté serveur, seul un jeton valide rend le signalement éligible à
    // l'auto-push T.io. Le user_id ci-dessus reste informationnel (non fiable).
    try {
      var ctx = window.__sharesub_translation_context;
      if (ctx && typeof ctx.auth_token === 'string' && ctx.auth_token) {
        payload.auth_token = ctx.auth_token;
      }
    } catch (e) {}
    var token = getTurnstileToken();
    if (token) payload['cf-turnstile-response'] = token;

    submitBtnEl.disabled = true;
    fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      credentials: 'omit',
    }).then(function(r){
      if (r.ok) return r.json();
      return r.json().then(function(b){ throw new Error((b && b.error && b.error.code) || ('http_'+r.status)); });
    }).then(function(){
      renderThanks();
    }).catch(function(err){
      if (errGenEl) {
        errGenEl.textContent = (err && err.message === 'turnstile_failed') ? 'Captcha invalide.' : t('error_generic');
        errGenEl.hidden = false;
      }
      if (submitBtnEl) submitBtnEl.disabled = false;
      resetTurnstile();
    });
  }

  function renderThanks(){
    if (!overlayEl || !modalEl) return;
    while (modalEl.firstChild) modalEl.removeChild(modalEl.firstChild);
    var icon = el('div', { className: 'ok', text: '✓' });
    var msg = el('div', { text: t('thanks') });
    var thanks = el('div', { className: 'thanks' }, [icon, msg]);
    var dismissBtn = el('button', { type: 'button', className: 'primary', text: t('close'), dataset: { role: 'dismiss' }, on: { click: closeModal } });
    var footer = el('footer', null, [dismissBtn]);
    modalEl.appendChild(thanks);
    modalEl.appendChild(footer);
    setTimeout(closeModal, 4000);
  }

  // ── Dismiss + overlay watch ─────────────────────────────────────────────
  // Le bouton flottant occupe le coin bas-gauche et peut chevaucher un menu
  // mobile plein écran (sharesub.com utilise un drawer avec scroll-lock).
  // Heuristique : si <body> ou <html> a un scroll-lock (overflow:hidden,
  // position:fixed iOS, ou classes type menu-open|no-scroll|modal-open),
  // on cache temporairement le widget. MutationObserver re-réagit sans
  // polling. Aucune dépendance au markup spécifique de sharesub.com.
  // Le dismiss définitif est stocké dans localStorage (clé versionnée
  // pour permettre une réinitialisation côté code si besoin un jour).
  var wrapEl = null;
  var overlayObs = null;
  var DISMISS_KEY = 'sharesub_tr_widget_dismissed_v1';

  function isDismissed(){
    try { return !!(window.localStorage && window.localStorage.getItem(DISMISS_KEY) === '1'); }
    catch (e) { return false; }
  }
  function dismiss(){
    try { if (window.localStorage) window.localStorage.setItem(DISMISS_KEY, '1'); } catch (e) {}
    if (STATE.mode === 'pick') stopPickMode();
    if (overlayObs) { try { overlayObs.disconnect(); } catch (e) {} overlayObs = null; }
    if (wrapEl && wrapEl.parentNode) wrapEl.parentNode.removeChild(wrapEl);
    wrapEl = null;
  }
  function isOverlayActive(){
    try {
      var b = document.body, h = document.documentElement;
      if (!b) return false;
      var bs = b.style, hs = h.style;
      if (bs.overflow === 'hidden' || (hs && hs.overflow === 'hidden')) return true;
      if (bs.position === 'fixed') return true; // iOS scroll-lock pattern
      var classes = ((b.className || '') + ' ' + (h.className || '')).toLowerCase();
      if (/(menu-open|menu-active|menu-is-open|nav-open|nav-active|modal-open|modal-active|drawer-open|drawer-active|no-scroll|noscroll|scroll-locked|overflow-hidden|is-locked|body-lock|mobile-menu-open)/.test(classes)) return true;
    } catch (e) {}
    return false;
  }
  function applyOverlayState(){
    if (!wrapEl) return;
    if (isOverlayActive()) wrapEl.classList.add('is-hidden');
    else wrapEl.classList.remove('is-hidden');
  }
  function installOverlayWatch(){
    if (overlayObs || typeof MutationObserver === 'undefined') return;
    try {
      overlayObs = new MutationObserver(applyOverlayState);
      overlayObs.observe(document.body, { attributes: true, attributeFilter: ['class', 'style'] });
      overlayObs.observe(document.documentElement, { attributes: true, attributeFilter: ['class', 'style'] });
      applyOverlayState();
    } catch (e) {}
  }

  // ── Bootstrap button ────────────────────────────────────────────────────
  function mount(){
    if (document.getElementById('sharesub-tr-wrap')) return;
    if (isDismissed()) return;
    var btn = el('button', {
      type: 'button',
      id: 'sharesub-tr-trigger',
      className: 'sharesub-tr-btn',
      text: t('button_label'),
      on: {
        click: function(){
          if (STATE.mode === 'pick') { stopPickMode(); return; }
          var sel = captureFromSelection();
          if (sel) {
            STATE.captured = {
              text: sel.text,
              selector: cssPath(sel.el),
              surrounding: getSurrounding(sel.el),
              native: readNativeData(sel.el),
              hidden: readHiddenMetadata(sel.el),
            };
            openModal();
          } else {
            startPickMode();
          }
        },
      },
    });
    var dismissBtn = el('button', {
      type: 'button',
      id: 'sharesub-tr-dismiss',
      className: 'sharesub-tr-dismiss',
      text: '×',
      attrs: { 'aria-label': t('close'), title: t('close') },
      on: {
        click: function(e){
          e.preventDefault();
          e.stopPropagation();
          dismiss();
        },
      },
    });
    wrapEl = el('div', { id: 'sharesub-tr-wrap', className: 'sharesub-tr-wrap' }, [btn, dismissBtn]);
    document.body.appendChild(wrapEl);
    installOverlayWatch();
  }
  // ── Lang gate ─────────────────────────────────────────────────────────
  // La config (ENABLED + ENABLED_LANGS) est BAKÉE dans ce bundle au build côté
  // serveur (widget.js régénéré à chaque cache-miss, TTL 1h). On ne fetch PLUS
  // l'endpoint de config à chaque mount : ce hit, × tout le trafic GTM de
  // sharesub.com, cramait le quota du Worker Cloudflare partagé sharesub-proxy
  // (100k req/jour pour tous les *.sharesub.com proxiés). Compromis assumé : un
  // toggle de langue admin se propage en ~1h (TTL du bundle) au lieu de 60s.
  // Sémantique IDENTIQUE à l'ancien gate (pure indexOf) : LANG absent de la
  // liste → ne pas monter. Cela COUVRE la liste vide (= admin a tout désactivé
  // via "Tout désactiver") → widget masqué partout. Le fail-soft "backend
  // dégradé" est géré côté serveur : getSettings() renvoie TOUTES les langues
  // sur erreur DB, donc une liste vide ici = choix explicite de l'admin, jamais
  // un blip réseau. NE PAS court-circuiter sur la longueur de la liste (ça
  // ferait monter le widget partout au moment où l'admin l'a justement coupé).
  // Zones exclues (blog / CMS) : le widget ne s'affiche pas sur ces URLs.
  // Décision produit — pas de signalement de traduction sur le blog. Le
  // endpoint /submit refuse aussi ces URLs (defense-in-depth).
  function isExcludedUrl(){
    try {
      var path = (location.pathname + location.search).toLowerCase();
      for (var i = 0; i < EXCLUDED_URL_SUBSTRINGS.length; i++) {
        if (path.indexOf(String(EXCLUDED_URL_SUBSTRINGS[i]).toLowerCase()) !== -1) return true;
      }
    } catch (e) {}
    return false;
  }
  function gateAndMount(){
    if (!ENABLED) return;
    if (isExcludedUrl()) return; // blog / CMS
    if (ENABLED_LANGS.indexOf(LANG) === -1) return; // lang non activée (liste vide incluse)
    mount();
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', gateAndMount, { once: true });
  } else {
    gateAndMount();
  }
})();
