(function() {
    "use strict";
    let ck;
    let initOptions={};
    let equeue = window.sib ? window.sib.equeue || [] : [];
    if( window.sib && window.sib.client_key ){
        ck = window.sib.client_key;
        if (window.sib.email_id){ 
            initOptions.email_id = window.sib.email_id;
        }
    } else if (Array.isArray(window.Brevo) ){
        for(const element of window.Brevo){
            if (
                Array.isArray(element) &&
                typeof element[0] === "string"
            ){
                let funcName=element[0];
                let args = element.slice(1);
                if(funcName === "init" && typeof args[0] === "object"){
                    if(typeof args[0].client_key === "string"){
                        ck=args[0].client_key;
                    }
                    initOptions=args[0];
                } else {
                    equeue.push({[funcName]: args})
                }
            } else if (typeof element === "function"){
                equeue.push(element);
            }
        }
        // For the new snippet, we want to send the page views
        // From the the frame and popup window we will use an option (i.e. _mode) to avoid sending the page view
        if (initOptions._mode !== "frame" && initOptions._mode !== "popup" && !initOptions.do_not_track_page){
            equeue.unshift({page:[]});
        }
    }
    if(!ck) return;
    var config = {
            url: 'https://in-automate.brevo.com/p',
            tracker_url: 'https://in-automate.brevo.com',
            com_err_msg: 'Please try again later/ Report this error to Sendinblue Team',
            cookie_exp: 182 * 24,
            if_url: 'https://sibautomation.com/cm.html?key=' + ck,
            is_secure: 'false',
            base_url: 'https://in-automate.brevo.com',
            custom_url_parsing: '[object Object]',
            tracking_enabled: { track: 'true', identify: 'true', page: 'true', trackLink: 'true', viewProduct: 'true', viewCategory: 'true', search: 'true',},
            wonderpush_webkey: '',
        },
        Helper = new hl();
    var iframe,cm;
    function q() {
        while (equeue.length) { (function(obj) { 
            if(typeof obj === "object") { 
                for (var k in obj) { 
                    if(typeof window.sib[k] === "function") { 
                        setTimeout(function() { 
                            if(typeof window.sib[k] === "function") { 
                                window.sib[k].apply(null, obj[k]);
                            } 
                        }, 200); 
                    } 
                }
            } else if(typeof obj === "function") { 
                setTimeout(function() {  
                    obj(); 
                }, 200); 
            } 
        })(equeue.shift());}
    }
    function mo(t) {
        var to = Object(t); for (var i = 1; i < arguments.length; i++) {var n = arguments[i]; if (n != null) { for (var k in n) { Object.prototype.hasOwnProperty.call(n, k) && (to[k] = n[k]);}}} return to;
    }
    function sr(o) {
        var s = []; for (var p in o) { Object.prototype.hasOwnProperty.call(o, p) && (s.push(encodeURIComponent(p) + "=" + encodeURIComponent(o[p]))); } return s.join("&");
    }
    function br(d) {
        var td = { key: ck, cuid: Helper.cookie.get('sib_cuid'), ma_url: window.location.href }; initOptions.email_id && (td.email_id = initOptions.email_id); return mo(td, d);
    }
    function generateReqBody(event_type) {
        var b = { event_type, ma_url: window.location.href, ma_referrer: document.referrer }
        if (initOptions.email_id) 
            b.email_id = initOptions.email_id;
        return b;
    }
    function generateReqHeaders() {
        return { "Content-Type": "application/json;charset=UTF-8", "visitor_id": Helper.cookie.get('sib_cuid'), "ma-key": ck };
    }
    function setReqHeaders(req, hdrs) {
        for (var key in hdrs) {
            req.setRequestHeader(key, hdrs[key]);
        } 
    }
    function createReq(event_type, url_suffix) {
        var reqBody = generateReqBody(event_type);
        var headers = generateReqHeaders();
        var url = config.tracker_url + url_suffix;
        return { reqBody, headers, url };
    }
    function hl() {}
    function sib() {}
    hl.prototype.cookie = {
        get: function(cn) { var name = cn + "=", dc = document.cookie, ca = dc.split(';'); for (var i = 0; i < ca.length; i++) { var c = ca[i]; while (c.charAt(0) == ' ') { c = c.substring(1); } if (c.indexOf(name) == 0) { return decodeURIComponent(c.substring(name.length, c.length)); }}return "";},
        set: function(n, v) { var cd = new Date(); cd.setHours(config.cookie_exp); var cookie_value = n + "=" + v + ";domain= " + window.location.hostname + ";expires=" + cd.toGMTString() + ";path=/"; if (config.is_secure === 'true') { cookie_value += ";secure=true" }; document.cookie = cookie_value; },
        remove: function(n) { document.cookie = n + '=;expires=Thu, 01 Jan 1970 00:00:01 GMT;'; }
    };
    hl.prototype.gen_sib_cuid = function() {
        var d = new Date().getTime(); return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = (d + Math.random() * 16) % 16 | 0; d = Math.floor(d / 16); return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);});
    };
    hl.prototype.closest = function(el, fn) {
        return el && (fn(el) ? el : this.closest(el.parentNode, fn));
    };
    hl.prototype.send = function(d, cb) {
        var u = config.url + '?' + sr(d), x = new XMLHttpRequest(); x.open("GET", u, !0); x.send(); return cb && cb(null);
    };
    hl.prototype.post = function(d, cb) {
        var u = config.url, x = new XMLHttpRequest(); x.open("POST", u, !0); x.setRequestHeader("Content-Type", "application/json;charset=UTF-8"); x.send(JSON.stringify(d)); return cb && cb(null);
    };
    hl.prototype.postReq = function(url, b, h, cb) {
        var u = url, x = new XMLHttpRequest(); x.open("POST", u, !0); setReqHeaders(x, h); x.send(JSON.stringify(b));
    };
    sib.prototype.track = function(n, d, s, a, cb) {
        if (config.tracking_enabled.track === 'false') {
            return cb();
        }
        if (n && n != undefined && n != "") {
            var o = {"sib_type": 'track', "sib_name": n};
            if(d && typeof d == 'object'){ o.contact = d; }
            if(s && typeof s == 'object'){ o.event = s; }
            if(a && typeof a == 'object'){ o.actiondata = a; }
            o = br(o);
            Helper.post(o, function(err) { return cb && cb(err); });
        } else {
            return cb && cb("Event name not passed.");
        }
    };
    function notifyWonderPushIdentify(args) {
        try { window.localStorage && window.localStorage.setItem('BrevoTracker.identifyCalledDate', String(+new Date())); } catch (e) {}
        
        let waitForWonderPush = function(triesLeft) {
            if (window.WonderPush) {
                window.WonderPush.push(function(WonderPushSDK) {
                    if (typeof WonderPushSDK._brevoIdentifyCalled === 'function') {
                        WonderPushSDK._brevoIdentifyCalled.apply(WonderPushSDK, args);
                    }
                });
            } else if (triesLeft > 0) {
                setTimeout(waitForWonderPush.bind(this, triesLeft-1), 1000);
            } // else give up
        };
        waitForWonderPush(60);
        
    }
    sib.prototype.identify = function(em, d, cb) {
        if (config.tracking_enabled.identify === 'false') {
            return cb();
        }
        var o = {"sib_type": 'identify'};
        if(typeof em === 'object'){
            if(em.attributes && typeof em.attributes === 'object'){
                o.contact = em.attributes;
            }
            o = br(o);
            var identifiers = {};
            if(em.identifiers && typeof em.identifiers === 'object'){
                if(em.identifiers.email_id) identifiers.email_id = em.identifiers.email_id;
                if(em.identifiers.phone_id) identifiers.phone_id = em.identifiers.phone_id;
                if(em.identifiers.whatsapp_id) identifiers.whatsapp_id = em.identifiers.whatsapp_id;
                if(em.identifiers.landline_number_id) identifiers.landline_number_id = em.identifiers.landline_number_id;
                if(em.identifiers.ext_id) identifiers.ext_id = em.identifiers.ext_id;
            }
            if(Object.keys(identifiers).length){
                if(identifiers.email_id) delete o.email_id;
                o.identifiers = identifiers;
            } else{
                return d && d("Identifiers not passed");
            }
            notifyWonderPushIdentify(Array.prototype.slice.call(arguments));
            Helper.post(o, function(err) { return d && d(err); });
        }
        else if ( em !== undefined && typeof em === "string" && em !== "") {
            if(d && typeof d === 'object'){ o.contact = d; }
            o = br(o);
            o.email_id = em;
            notifyWonderPushIdentify(Array.prototype.slice.call(arguments));
            Helper.post(o, function(err) { return cb && cb(err); });
        } else {
            return cb && cb("Email not passed");
        }
    };
    sib.prototype.trackLink = function(l, d, cb) {
        if (config.tracking_enabled.trackLink === 'false') {
            return cb();
        }
        d = br(d); d.sib_type = 'trackLink';
        var links = l ? (Array.isArray(l) ? l : [l]) : [];
        for (var i = 0; i < links.length; i++) {
            (function(v, td) {
                if (v) {
                    var href = v.getAttribute('href');
                    var jsClosest = Helper.closest(v, function(el) { return el && typeof el.tagName != "undefined" && el.tagName.toLowerCase() == 'a'; });
                    if (jsClosest && href) {
                        v.addEventListener("click", function(e) {
                            e.preventDefault();
                            td.href = href, td.linkid = v.getAttribute('id'), td.sib_name = v.getAttribute('id');
                            Helper.send(td, function(err) { cb && cb(err); (v.getAttribute('target') !== '_blank') ? setTimeout(function() { window.location.href = href; }, 1000): window.open(href); });
                        });
                    }
                }
            })(links[i], d);
        }
    };
    sib.prototype.page = function(n, d, cb) {
        if (config.tracking_enabled.page === 'false') {
            return cb();
        }
        d = br(d); d.sib_type = 'page', d.ma_title = d.title || d.ma_title || document.title, d.sib_name = n || d.ma_title,d.ma_referrer = d.referrer || d.ma_referrer || document.referrer,d.ma_path = d.path || d.ma_path || window.location.pathname;
        Helper.send(d, function(err) { return cb && cb(err); });
    };
    sib.prototype.viewCategory = function(n, cb) {
        if (config.tracking_enabled.viewCategory === 'false') {
            return cb();
        }
        var request = createReq("view_category", "/ecommerce/category/view");
        request.reqBody.category_id = n;
        Helper.postReq(request.url, request.reqBody, request.headers, function(err) { return cb && cb(err); });
    };
    sib.prototype.viewProduct = function(n, cb) {
        if (config.tracking_enabled.viewProduct === 'false') {
            return cb();
        }
        var request = createReq("view_product", "/ecommerce/product/view");
        request.reqBody.product_id = n;
        Helper.postReq(request.url, request.reqBody, request.headers, function(err) { return cb && cb(err); });
    };
    sib.prototype.search = function(q, u, cb) {
        if (config.tracking_enabled.search === 'false') {
            return cb();
        }
        var request = createReq("ecommerce_search", "/ecommerce/search");
        request.reqBody.query = q;
        request.reqBody.url = u;
        Helper.postReq(request.url, request.reqBody, request.headers, function(err) { return cb && cb(err); });
    };
    sib.prototype.push = function(ele) {
        if(typeof ele === "function") {
            ele();
        } else if (Array.isArray(ele) && typeof ele[0] === "string") {
            var funcName = ele[0];
            var args = ele.slice(1);
            if (typeof this[funcName] === "function") {
                this[funcName].apply(null, args);
            }
        }
    };
    sib.prototype.setInAppMessagesSuppressed = function(ele) {
        
        console.warn("Wonderpush is not enabled");
        
    };
    window.sib = mo(new sib(), window.sib);
    window.Brevo = window.sib; 
    var cuid;
    var cm_flag = false;
    if (Helper.cookie.get('sib_cuid')) {
        cuid = Helper.cookie.get('sib_cuid');
    } else {
        cuid = Helper.gen_sib_cuid();
        cm_flag = true;
        Helper.cookie.set('sib_cuid', cuid);
    }
    
    var se = '', sc= '';
    function load_cm(c){
        let contact_email = "", parameter = "", organization_id = 0, contact_id = 0;
        let phone_id = "", whatsapp_id = "";
        if(initOptions.email_id && initOptions.email_id.length > 3) {
            contact_email = initOptions.email_id;
        } else {
            const urlParams = new URLSearchParams(window.location.search);
            se = urlParams.get('_se');
            sc = urlParams.get('_sc');
            const idf = urlParams.get("_idf");
            if(se) {
                contact_email = window.atob(se);
                parameter = "_se"
            } else if(sc) {
                var contact_metadata = window.atob(sc).split('#')
                organization_id = parseInt(contact_metadata[0],10)
                contact_id = parseInt(contact_metadata[1],10)
                parameter = "_sc"
            } else if(idf) {
                const parts = window.atob(idf).split("#");
                if (parts.length === 2) {
                    const type = parts[0];
                    const value = parts[1];

                    if (type === "pid") phone_id = value;
                    if (type === "wid") whatsapp_id = value;
                }
            }
        }

        if (cuid && (phone_id.length > 0 || whatsapp_id.length > 0) && config.custom_url_parsing == "true"){
            const identifiers = {};
            if (phone_id) identifiers.phone_id = phone_id;
            if (whatsapp_id) identifiers.whatsapp_id = whatsapp_id;
            
            const payload = {visitor_id: cuid, identifiers: identifiers};
            const identification_url = config.base_url + '/internal/identification';
            const x = new XMLHttpRequest(); 
            x.open("POST", identification_url, !0); 
            x.setRequestHeader("ma-key", ck);
            x.setRequestHeader("Content-Type", "application/json;charset=UTF-8"); 
            x.send(JSON.stringify(payload));
            return c && c();
        }
        
        if (cuid && (contact_email || contact_id) && config.custom_url_parsing == "true"){
            const payload = {visitor_id: cuid, email_id: contact_email, organization_id, contact_id, parameter};
            const session_url = config.base_url + '/visitor/' + ck, x = new XMLHttpRequest(); x.open("POST", session_url, !0); x.setRequestHeader("Content-Type", "application/json;charset=UTF-8"); x.send(JSON.stringify(payload));
            return c && c();
        }
        else if (!config.custom_url_parsing || config.custom_url_parsing == "false") {
            cm = {cuid: cuid, cm_flag: cm_flag, allow_cookie:Helper.cookie.get('cookieconsent_status')};
            initOptions.email_id && (cm.email_id = initOptions.email_id);
            var i=(config.if_url.indexOf('#') > 0) ? config.if_url.indexOf('#') : (config.if_url.length);
            config.if_url = config.if_url.substr(0,i);
            config.if_url = config.if_url + '#' + sr(cm);
            iframe = document.createElement('iframe');iframe.id="cm_iframe", iframe.height = "0", iframe.width = "0", iframe.style.display = "none", iframe.style.visibility = "hidden", iframe.src = config.if_url + "&i=0";
            document.body.appendChild(iframe);
            if (iframe.readyState) {
                iframe.onreadystatechange = function () { if (iframe.readyState == "loaded" || iframe.readyState == "complete") { iframe.onreadystatechange = null; return c && c(); } };
            } else {
                iframe.onload = function () { return c && c(); };
            }
        } else{
            return c && c();
        }
    }
    function onScriptReady(){
        typeof create_chat == "function" && create_chat(); 
        typeof triggerNotifyEngine == "function" && triggerNotifyEngine(); 
        q(); 
    }
    
    
   
    
    load_cm(onScriptReady);
})();
