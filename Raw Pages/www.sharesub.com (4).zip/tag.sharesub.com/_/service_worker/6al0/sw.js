'use strict';
var aa = {},
    k = function(a) {
        function b(c) {
            return a.next(c)
        }

        function d(c) {
            return a.throw(c)
        }
        return new Promise(function(c, e) {
            function g(f) {
                f.done ? c(f.value) : Promise.resolve(f.value).then(b, d).then(g, e)
            }
            g(a.next())
        })
    };
/*

 Copyright 2020 Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
function n(a) {
    var b = [],
        d = 0;
    for (let c = 0; c < a.length; c++) {
        let e = a.charCodeAt(c);
        b[d++] = e
    }
    new Uint8Array(b)
};
/*

 Copyright 2022 Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
A(1, 0);
A(2, 16);
A(2, 18);
A(2, 25722);
A(2, 1);
A(2, 3);
A(2, 1);
A(2, 2);
n("KEM");
n("HPKE");
n("HPKE-v1");

function A(a, b) {
    var d = new Uint8Array(a);
    for (let c = 0; c < a; c++) d[c] = b >> 8 * (a - c - 1) & 255
};
/*
 jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license.
*/
var F = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
    G = function(a) {
        var b;
        if (!(b = !a)) {
            var d;
            if (a == null) d = String(a);
            else {
                var c = F.exec(Object.prototype.toString.call(Object(a)));
                d = c ? c[1].toLowerCase() : "object"
            }
            b = d != "object"
        }
        if (b || a.nodeType || a == a.window) return !1;
        try {
            if (a.constructor && !Object.prototype.hasOwnProperty.call(Object(a), "constructor") && !Object.prototype.hasOwnProperty.call(Object(a.constructor.prototype), "isPrototypeOf")) return !1
        } catch (g) {
            return !1
        }
        for (var e in a);
        return e ===
            void 0 || Object.prototype.hasOwnProperty.call(Object(a), e)
    };

function H(a, b) {
    return a.length >= b.length && a.substring(0, b.length) === b
};
var K = function(a, b) {
        if (b) {
            var d = G(b.options) ? b.options : {};
            for (let c of Object.keys(b)) {
                let e = b[c];
                switch (c) {
                    case "send_pixel":
                        I(e, d, (g, f) => {
                            a.i({
                                url: g,
                                method: 0,
                                templates: a.templates,
                                processResponse: !1,
                                attributionReporting: f.attribution_reporting
                            }, J(a, f))
                        });
                        break;
                    case "fetch":
                        I(e, d, (g, f) => {
                            a.i({
                                url: g,
                                method: 0,
                                templates: a.templates,
                                processResponse: f.process_response || !1,
                                attributionReporting: f.attribution_reporting
                            }, J(a, f))
                        })
                }
            }
        }
    },
    N = function(a, b) {
        b = a.h + b;
        for (var d = b.indexOf("\n\n"); d !== -1;) {
            var c = K,
                e =
                a,
                g;
            a: {
                let [l, u] = b.substring(0, d).split("\n");
                if (H(l, "event: message") && H(u, "data: ")) {
                    var f = u.substring(6);
                    try {
                        g = JSON.parse(f);
                        break a
                    } catch (v) {}
                }
                g = void 0
            }
            c(e, g);
            b = b.substring(d + 2);
            d = b.indexOf("\n\n")
        }
        a.h = b
    },
    J = function(a, b) {
        return () => {
            var d = b.fallback_url,
                c = b.fallback_url_method;
            d && c && K(a, {
                [c]: [d],
                options: {}
            })
        }
    },
    I = function(a, b, d) {
        if (Array.isArray(a))
            for (let c of a) typeof c === "string" && d(c, b)
    },
    O = class {
        constructor() {
            this.h = ""
        }
    };
Object.freeze({
    attributionsrc: ""
});
var P = Object.freeze({
    eventSourceEligible: !1,
    triggerEligible: !0
});
const Q = /^[0-9A-Fa-f]{64}$/;

function R(a) {
    try {
        return (new TextEncoder).encode(a)
    } catch (b) {
        let d = [];
        for (let c = 0; c < a.length; c++) {
            let e = a.charCodeAt(c);
            e < 128 ? d.push(e) : e < 2048 ? d.push(192 | e >> 6, 128 | e & 63) : e < 55296 || e >= 57344 ? d.push(224 | e >> 12, 128 | e >> 6 & 63, 128 | e & 63) : (e = 65536 + ((e & 1023) << 10 | a.charCodeAt(++c) & 1023), d.push(240 | e >> 18, 128 | e >> 12 & 63, 128 | e >> 6 & 63, 128 | e & 63))
        }
        return new Uint8Array(d)
    }
}

function S(a, b) {
    if (a === "" || a === "e0") return Promise.resolve(a);
    var d;
    if ((d = b.crypto) == null ? 0 : d.subtle) {
        if (Q.test(a)) return Promise.resolve(a);
        try {
            let c = R(a);
            return b.crypto.subtle.digest("SHA-256", c).then(e => T(e, b)).catch(() => "e2")
        } catch (c) {
            return Promise.resolve("e2")
        }
    } else return Promise.resolve("e1")
}

function T(a, b) {
    var d = Array.from(new Uint8Array(a)).map(c => String.fromCharCode(c)).join("");
    return b.btoa(d).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
};
var U = {
    o: 0,
    u: 1,
    0: "GET",
    1: "POST"
};
var V = function(a, b) {
        var d = b.url,
            c = b.allowObfuscation;
        if (!d) return {
            failureType: 9,
            command: 0,
            data: "url required."
        };
        if (b.strict) try {
            let f = new URL(a.h.location.href),
                l = new URL(d, f.origin);
            if (l.origin !== f.origin) return {
                failureType: 18,
                command: 0,
                data: "Cross-origin command blocked"
            };
            let u = f.pathname,
                v = u.indexOf("/_/service_worker"),
                m = v !== -1 ? u.substring(0, v) : "";
            m.endsWith("/") && (m = m.slice(0, -1));
            let x = l.pathname.replace(/\/$/, "") === m;
            var e;
            if (e = c && x) {
                var g = b.body;
                e = g ? b.method === 1 && g.startsWith("/g/collect?") :
                    !1
            }
            if (!(l.pathname.startsWith("/g/collect") || l.pathname.startsWith("/_/") || m && l.pathname.startsWith(m) || e)) return {
                failureType: 18,
                command: 0,
                data: "Invalid command path blocked"
            }
        } catch (f) {
            return {
                failureType: 12,
                command: 0,
                data: "Invalid command URL: " + f.message
            }
        }
    },
    X = function(a, b, d) {
        return k(function*() {
            var c = yield W(a, b, d);
            if ("failureType" in c) return c;
            yield ba(a, c, b);
            return c
        }())
    },
    ca = function(a, b, d, c) {
        k(function*() {
            var e = b.commandType,
                g = b.params;
            if (e === 0) {
                let f = V(a, g);
                f ? c(f) : (X(a, g).catch(() => {}), d({
                    data: g.url
                }))
            } else c({
                failureType: 8,
                command: e,
                data: `Command with type ${e} unknown.`
            })
        }())
    },
    fa = function(a, b, d) {
        return k(function*() {
            return b.url ? yield X(a, b, d): {
                failureType: 9,
                command: 0,
                data: "url required."
            }
        }())
    },
    W = function(a, b, d) {
        return k(function*() {
            function c(h) {
                return k(function*() {
                    var [p, q] = h.split("|"), [B, y] = p.split("."), r = y, t = u[B];
                    t || (t = p, r = "");
                    var D = z => k(function*() {
                        try {
                            return yield da(q)(z)
                        } catch (C) {
                            throw new Y(C.message);
                        }
                    }());
                    if (!r) {
                        if (typeof t === "string") return yield D(t);
                        let z = t,
                            C = Object.keys(z).map(L => k(function*() {
                                var ea =
                                    yield D(z[L]);
                                return `${L}=${ea}`
                            }()));
                        return (yield Promise.all(C)).join("&")
                    }
                    return typeof t === "object" && t[r] ? yield D(t[r]): h
                }())
            }

            function e(h) {
                return k(function*() {
                    for (var p, q = ""; h.match(E) && q !== h;) {
                        q = h;
                        p = h.matchAll(E);
                        let B = [...p].map(r => c(r[1])),
                            y = yield Promise.all(B);
                        y.length !== 0 && (h = h.replace(E, r => y.shift() || r))
                    }
                    return h
                }())
            }
            var {
                url: g,
                body: f
            } = b, {
                attributionReporting: l,
                templates: u,
                processResponse: v,
                method: m = 0,
                referer: x,
                soReferrer: M
            } = b, E = RegExp("\\${([^${}]*?)}", "g"), da = h => {
                if (h == null) return q =>
                    k(function*() {
                        return q
                    }());
                var p = a.i[h];
                if (p == null) throw Error(`Unknown filter: ${h}`);
                return q => k(function*() {
                    return yield p(q, b)
                }())
            };
            try {
                g = yield e(g), f = f ? yield e(f): void 0
            } catch (h) {
                return d == null || d(), {
                    failureType: 9,
                    command: 0,
                    data: `Failed to inject template values: ${h}`
                }
            }
            var w = {
                method: U[m],
                credentials: "include",
                body: m === 1 ? f : void 0,
                keepalive: !0,
                redirect: "follow"
            };
            if (x) try {
                w.headers = {
                    ["X-Effective-Origin"]: (new URL(x)).origin,
                    ["X-Effective-Referer"]: x
                }
            } catch (h) {} else M && (w.referrer = M);
            v || (w.mode =
                "no-cors");
            l && (w.attributionReporting = P);
            try {
                let h = yield a.h.fetch(g, w);
                return w.mode === "no-cors" || h.ok ? {
                    data: v ? yield h.text(): g
                } : (d == null || d(), {
                    failureType: 9,
                    command: 0,
                    data: "Fetch failed"
                })
            } catch (h) {
                return d == null || d(), {
                    failureType: 9,
                    command: 0,
                    data: `Fetch failed: ${h}`
                }
            }
        }())
    },
    ba = function(a, b, d) {
        return k(function*() {
            if (d.processResponse) {
                var c = [];
                N(new ha(d.templates, (e, g) => {
                    c.push(fa(a, e, g))
                }), b.data);
                return Promise.all(c)
            }
        }())
    },
    ia = class {
        constructor(a) {
            this.h = a;
            this.i = {
                sha256: b => {
                    var d = this;
                    return k(function*() {
                        return yield S(b,
                            d.h)
                    }())
                },
                encode: b => k(function*() {
                    return encodeURIComponent(b)
                }()),
                encrypt_with_memo: () => k(function*() {
                    throw new Y("Encryption not supported.");
                }())
            }
        }
    };
class ha extends O {
    constructor(a, b) {
        super();
        this.templates = a;
        this.i = b
    }
}
class Y extends Error {
    constructor(a) {
        super(a)
    }
};
var ja = function(a, b, d) {
    a.h[b] == null && (a.h[b] = 0, a.i[b] = d, a.j++);
    a.h[b]++;
    return {
        targetId: a.id,
        clientCount: a.j,
        totalLifeMs: Math.round(d - a.m),
        heartbeatCount: a.h[b],
        clientLifeMs: Math.round(d - a.i[b])
    }
};
class ka {
    constructor(a) {
        this.m = a;
        this.h = {};
        this.i = {};
        this.j = 0;
        this.id = String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()))
    }
}

function Z(a) {
    return a.performance && a.performance.now() || Date.now()
}
var la = function(a, b) {
    class d {
        constructor(c, e) {
            this.i = c;
            this.h = e;
            this.j = new ka(Z(e))
        }
        l(c, e) {
            var g = c.clientId;
            if (c.type === 0) c.stats = ja(this.j, g, Z(this.h)), e(c);
            else if (c.type === 1) try {
                this.i(c.command, f => {
                    c.result = f;
                    e(c)
                }, f => {
                    c.failure = f;
                    e(c)
                })
            } catch (f) {
                c.failure = {
                    failureType: 11,
                    data: f.toString()
                }, e(c)
            }
        }
    }
    return new d(a, b)
};
(new class {
    constructor(a) {
        this.h = a;
        var b = new ia(a);
        this.i = la((d, c, e) => {
            ca(b, d, c, e)
        }, a)
    }
    init() {
        this.h.addEventListener("install", () => {
            this.h.skipWaiting()
        });
        this.h.addEventListener("activate", a => {
            a.waitUntil(this.h.clients.claim())
        });
        this.h.addEventListener("message", a => {
            var b = a.source;
            if (b) {
                var d = a.data,
                    c = new Promise(e => {
                        this.i.l(d, g => {
                            b.postMessage(g);
                            e(void 0)
                        })
                    });
                a.waitUntil(c)
            }
        })
    }
}(self)).init();